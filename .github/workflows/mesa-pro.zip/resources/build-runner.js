// Arma www/runners/check.js pegando calc.js + riesgo.js + alertas.js + resources/runner-body.js (así el chequeo en segundo plano usa las MISMAS reglas que la app).
// Uso: node resources/build-runner.js            (escribe el archivo)
//      node resources/build-runner.js --verificar (sale con error si el archivo no está al día)
const fs = require('fs'), path = require('path');
const raiz = path.join(__dirname, '..');
const leer = f => fs.readFileSync(path.join(raiz, f), 'utf8');
const salida = 'www/runners/check.js';
const contenido = [
  '/* ARCHIVO GENERADO por resources/build-runner.js. No lo edites: cambiá www/js/calc.js, www/js/riesgo.js, www/js/alertas.js o resources/runner-body.js y volvé a correr el script. */',
  'var window = (typeof globalThis !== "undefined") ? globalThis : this;',
  leer('www/js/calc.js'), leer('www/js/riesgo.js'), leer('www/js/alertas.js'), leer('resources/runner-body.js')
].join('\n');
if (process.argv.includes('--verificar')) {
  let actual = ''; try { actual = leer(salida); } catch (e) {}
  if (actual !== contenido) { console.error('www/runners/check.js no está al día: corré node resources/build-runner.js'); process.exit(1); }
  console.log('check.js al día'); process.exit(0);
}
fs.mkdirSync(path.join(raiz, 'www/runners'), { recursive: true });
fs.writeFileSync(path.join(raiz, salida), contenido);
console.log('Escrito ' + salida + ' (' + contenido.length + ' bytes)');
