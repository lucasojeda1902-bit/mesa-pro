// Arma mesa-web.json (actualización por aire) a partir de www/: marco.html + los css y js de www/manifiesto.json.
// Uso: node resources/build-web.js [--version 3.0.1] [--salida upload/mesa-web.json]
// Después subí mesa-web.json a la raíz de tu Drive (si ya existe, reemplazalo). La app lo baja con ?k=CLAVE&web=1.
// La cáscara del APK (index.html, js/arranque.js, fuentes, vendor/) NO viaja por aire.
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const RUTA_OK = /^(marco\.html|css\/[\w.-]+\.css|js\/[\w.-]+\.js)$/;
function armar(opt) {
  opt = opt || {};
  const www = opt.www || path.join(__dirname, '../www');
  const m = JSON.parse(fs.readFileSync(path.join(www, 'manifiesto.json'), 'utf8'));
  const version = opt.version || m.version;
  if (!/^\d+\.\d+\.\d+$/.test(version)) throw new Error('Versión inválida: ' + version);
  const lista = ['marco.html'].concat(m.css, m.js), archivos = {};
  lista.forEach(r => {
    if (!RUTA_OK.test(r) || r === 'js/arranque.js') throw new Error('Ruta no permitida en el paquete: ' + r);
    archivos[r] = (opt.reemplazos && opt.reemplazos[r] != null) ? opt.reemplazos[r] : fs.readFileSync(path.join(www, r), 'utf8');
  });
  const canon = lista.map(r => r + '\n' + archivos[r] + '\n').join('');
  return { formato: 1, app: 'ar.lucas.mesapro', version, requiere_apk: m.requiere_apk, generado: new Date().toISOString(), lista, css: m.css, js: m.js, archivos, sha256: crypto.createHash('sha256').update(canon, 'utf8').digest('hex') };
}
module.exports = { armar };
if (require.main === module) {
  const a = process.argv, val = k => { const i = a.indexOf(k); return i > -1 ? a[i + 1] : null; };
  const p = armar({ version: val('--version') });
  const salida = path.resolve(val('--salida') || path.join(__dirname, '../upload/mesa-web.json'));
  fs.mkdirSync(path.dirname(salida), { recursive: true });
  const txt = JSON.stringify(p);
  fs.writeFileSync(salida, txt);
  console.log('Escrito ' + salida + ' · versión ' + p.version + ' · ' + p.lista.length + ' archivos · ' + Math.round(txt.length / 1024) + ' KB · sha256 ' + p.sha256.slice(0, 12) + '…');
}
