/* ---- Chequeo en segundo plano de Mesa PRO (@capacitor/background-runner) ----
   Entorno restringido: sin DOM, sin async/await obligatorio; hay fetch, CapacitorKV y CapacitorNotifications.
   Eventos: check (lo dispara Android cada ~30 min), config (la app deja URL, clave y preferencias),
   estado (la app pregunta qué se avisó y cuándo corrió), marcar (la app dice qué ya avisó ella). */
var KV_CFG = "cfg", KV_AVISADAS = "notificadas", KV_ULTIMA = "ultima", KV_ERROR = "error";

function kvGet(k) { try { var r = CapacitorKV.get(k); return r && r.value != null ? r.value : null; } catch (e) { return null; } }
function kvSet(k, v) { try { CapacitorKV.set(k, v); } catch (e) {} }
function kvJSON(k, def) { try { var t = kvGet(k); var o = t ? JSON.parse(t) : null; return o && typeof o === "object" ? o : def; } catch (e) { return def; } }

addEventListener("config", function (resolve, reject, args) {
  try {
    var a = args || {};
    kvSet(KV_CFG, JSON.stringify({ url: String(a.url || ""), clave: String(a.clave || ""), prefs: a.prefs && typeof a.prefs === "object" ? a.prefs : {}, recordatorios: a.recordatorios === true, frenado: typeof a.frenado === "string" ? a.frenado : null }));
    resolve({ ok: true });
  } catch (e) { resolve({ ok: false }); }
});

addEventListener("marcar", function (resolve, reject, args) {
  try { if (args && args.mapa && typeof args.mapa === "object") kvSet(KV_AVISADAS, JSON.stringify(args.mapa)); } catch (e) {}
  resolve({ ok: true });
});

addEventListener("estado", function (resolve) {
  var cfg = kvJSON(KV_CFG, {});
  resolve({ notificadas: kvJSON(KV_AVISADAS, {}), ultima: kvGet(KV_ULTIMA), error: kvGet(KV_ERROR), configurado: !!(cfg.url && cfg.clave) });
});

/* GET con respaldo: el fetch del runner normalmente sigue el 302 de Apps Script solo; si no lo hiciera y se puede leer "Location", lo sigue a mano. */
function traer(url, n) {
  return fetch(url).then(function (r) {
    var st = r && r.status;
    if ((st === 301 || st === 302 || st === 303 || st === 307 || st === 308) && n < 3) {
      var loc = null;
      try { var h = r.headers; loc = h && (typeof h.get === "function" ? (h.get("location") || h.get("Location")) : (h.location || h.Location)); } catch (e) {}
      if (loc) return traer(String(loc), n + 1);
      throw new Error("redirect_sin_location");
    }
    return r.json();
  });
}

function chequear() {
  var cfg = kvJSON(KV_CFG, {});
  if (!cfg.url || !cfg.clave) return Promise.resolve({ ok: false, motivo: "sin_config" });
  var url = cfg.url + (cfg.url.indexOf("?") > -1 ? "&" : "?") + "k=" + encodeURIComponent(cfg.clave);
  return traer(url, 0).then(function (j) {
    if (!j || j.ok === false || !Array.isArray(j.cuentas)) throw new Error(j && j.error ? String(j.error) : "formato");
    var hoy = Mesa.hoy();
    var r = Mesa.resumen(j, hoy, false);
    var out = Mesa.alertasNuevas(r.alertas, kvJSON(KV_AVISADAS, {}), Mesa.iso(hoy), cfg.prefs || {}, { sinPagos: cfg.recordatorios === true, frenado: cfg.frenado === Mesa.iso(hoy) });
    if (out.nuevas.length) CapacitorNotifications.schedule(out.nuevas.map(function (n) { return { id: n.id, title: n.titulo, body: n.texto }; }));
    kvSet(KV_AVISADAS, JSON.stringify(out.mapa));
    kvSet(KV_ULTIMA, new Date().toISOString()); kvSet(KV_ERROR, "");
    return { ok: true, nuevas: out.nuevas.length };
  });
}

addEventListener("check", function (resolve) {
  chequear().then(function (r) { resolve(r); }, function (e) {
    kvSet(KV_ERROR, String((e && e.message) || e).replace(/([?&]k=)[^&\s"']*/g, "$1***").slice(0, 120));
    resolve({ ok: false, motivo: "error" });
  });
});
