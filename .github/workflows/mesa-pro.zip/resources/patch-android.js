// Ajustes al proyecto Android que genera `npx cap add android` (la carpeta android/ NO se guarda en el repo).
// Uso (desde la raíz del repo, después de `cap add android` y antes de `cap sync`): node resources/patch-android.js [carpeta-android]
// Es idempotente: se puede correr dos veces sin duplicar nada.
//  1) Permisos: avisos (POST_NOTIFICATIONS), alarmas exactas para los recordatorios (SCHEDULE_EXACT_ALARM), reinicio del celular.
//     Saca los permisos de ubicación que trae @capacitor/background-runner y que Mesa PRO no usa.
//  2) app/build.gradle: carpeta del motor JS de background-runner (lo pide su README) y versión 2.0.
//  3) Ícono chico de las notificaciones (res/drawable/ic_stat_mesa.xml).
const fs = require('fs'), path = require('path');
const AND = path.resolve(process.argv[2] || 'android');
const VERSION_NAME = '2.0';
const VERSION_CODE = String(parseInt(process.env.MESA_VERSION_CODE, 10) || 2);
const leer = f => fs.readFileSync(f, 'utf8');
function falta(msg) { console.error('patch-android: ' + msg); process.exit(1); }

/* 1) manifest */
const mf = path.join(AND, 'app/src/main/AndroidManifest.xml');
if (!fs.existsSync(mf)) falta('no encuentro ' + mf + '. ¿Corriste `npx cap add android`?');
let x = leer(mf);
if (!/xmlns:tools=/.test(x)) x = x.replace(/<manifest\b([^>]*)>/, (m, a) => '<manifest' + a + '\n    xmlns:tools="http://schemas.android.com/tools">');
const agregar = [];
['POST_NOTIFICATIONS', 'SCHEDULE_EXACT_ALARM', 'RECEIVE_BOOT_COMPLETED', 'WAKE_LOCK', 'ACCESS_NETWORK_STATE'].forEach(p => { if (x.indexOf('android.permission.' + p + '"') < 0) agregar.push('    <uses-permission android:name="android.permission.' + p + '" />'); });
['ACCESS_COARSE_LOCATION', 'ACCESS_FINE_LOCATION', 'ACCESS_BACKGROUND_LOCATION'].forEach(p => { if (!new RegExp('android.permission.' + p + '"[^>]*tools:node="remove"').test(x)) agregar.push('    <uses-permission android:name="android.permission.' + p + '" tools:node="remove" />'); });
if (agregar.length) {
  if (!/<\/manifest>/.test(x)) falta('manifest raro: no tiene </manifest>');
  x = x.replace('</manifest>', agregar.join('\n') + '\n</manifest>');
}
fs.writeFileSync(mf, x);

/* 2) build.gradle */
const bg = path.join(AND, 'app/build.gradle');
if (!fs.existsSync(bg)) falta('no encuentro ' + bg);
let g = leer(bg);
const LIBS = "dirs '../../node_modules/@capacitor/background-runner/android/src/main/libs', 'libs'";
if (g.indexOf('background-runner/android/src/main/libs') < 0) {
  const re = /(flatDir\s*\{[ \t]*\n)([ \t]*)(dirs[^\n]*)/;
  if (!re.test(g)) falta('no encuentro el bloque flatDir en app/build.gradle');
  g = g.replace(re, (m, a, sp, d) => a + sp + d + '\n' + sp + LIBS);
}
if (!/versionCode\s+\d+/.test(g) || !/versionName\s+"[^"]*"/.test(g)) falta('no encuentro versionCode/versionName en app/build.gradle');
g = g.replace(/versionCode\s+\d+/, 'versionCode ' + VERSION_CODE).replace(/versionName\s+"[^"]*"/, 'versionName "' + VERSION_NAME + '"');
fs.writeFileSync(bg, g);

/* 3) ícono de notificaciones */
const dr = path.join(AND, 'app/src/main/res/drawable');
fs.mkdirSync(dr, { recursive: true });
fs.writeFileSync(path.join(dr, 'ic_stat_mesa.xml'), `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="512" android:viewportHeight="512">
    <path android:pathData="M132,376L132,212L256,332L380,212L380,376" android:strokeColor="#FFFFFF" android:strokeWidth="56" android:strokeLineCap="round" android:strokeLineJoin="round"/>
</vector>
`);
console.log('patch-android: listo (versionName ' + VERSION_NAME + ', versionCode ' + VERSION_CODE + ')');
