// Ajustes al proyecto Android que genera `npx cap add android` (la carpeta android/ NO se guarda en el repo).
// Uso (desde la raíz del repo, después de `cap add android` y antes de `cap sync`): node resources/patch-android.js [carpeta-android]
// Es idempotente: se puede correr dos veces sin duplicar nada.
//  1) Permisos: avisos (POST_NOTIFICATIONS), alarmas exactas para los recordatorios (SCHEDULE_EXACT_ALARM), reinicio del celular.
//     Saca los permisos de ubicación que trae @capacitor/background-runner y que Mesa PRO no usa.
//  2) app/build.gradle: carpeta del motor JS de background-runner (lo pide su README) y versión 2.0.
//  3) Ícono chico de las notificaciones (res/drawable/ic_stat_mesa.xml).
//  4) v3: atajos al mantener apretado el ícono (res/xml/shortcuts.xml: Hoy, Killzone, Cargar gasto), enlaces mesapro://
//     para abrirlos (intent-filter) y splash animado de Android 12+ (drawable-v31/splash_animado.xml; en versiones viejas, estático).
const fs = require('fs'), path = require('path');
const AND = path.resolve(process.argv[2] || 'android');
const VERSION_NAME = '3.0';
const VERSION_CODE = String(parseInt(process.env.MESA_VERSION_CODE, 10) || 3000);
const leer = f => fs.readFileSync(f, 'utf8');
function falta(msg) { console.error('patch-android: ' + msg); process.exit(1); }

/* 1) manifest */
const mf = path.join(AND, 'app/src/main/AndroidManifest.xml');
if (!fs.existsSync(mf)) falta('no encuentro ' + mf + '. ¿Corriste `npx cap add android`?');
let x = leer(mf);
if (!/xmlns:tools=/.test(x)) x = x.replace(/<manifest\b([^>]*)>/, (m, a) => '<manifest' + a + '\n    xmlns:tools="http://schemas.android.com/tools">');
const agregar = [];
['POST_NOTIFICATIONS', 'SCHEDULE_EXACT_ALARM', 'RECEIVE_BOOT_COMPLETED', 'WAKE_LOCK', 'ACCESS_NETWORK_STATE'].forEach(p => { if (x.indexOf('android.permission.' + p + '"') < 0) agregar.push('    <uses-permission android:name="android.permission.' + p + '" />'); });
['ACCESS_COARSE_LOCATION', 'ACCESS_FINE_LOCATION', 'ACCESS_BACKGROUND_LOCATION'].forEach(p => { if (!new RegExp('android.permission.' + p + '"[^>]*tools:node="remove"').test(x)) agregar.push('    <uses-permission android:name="android.permission.' + p + '" tools:node="remove" />'); });
if (agregar.length) {
  if (!/<\/manifest>/.test(x)) falta('manifest raro: no tiene </manifest>');
  x = x.replace('</manifest>', agregar.join('\n') + '\n</manifest>');
}
fs.writeFileSync(mf, x);

/* 2) build.gradle */
const bg = path.join(AND, 'app/build.gradle');
if (!fs.existsSync(bg)) falta('no encuentro ' + bg);
let g = leer(bg);
const LIBS = "dirs '../../node_modules/@capacitor/background-runner/android/src/main/libs', 'libs'";
if (g.indexOf('background-runner/android/src/main/libs') < 0) {
  const re = /(flatDir\s*\{[ \t]*\n)([ \t]*)(dirs[^\n]*)/;
  if (!re.test(g)) falta('no encuentro el bloque flatDir en app/build.gradle');
  g = g.replace(re, (m, a, sp, d) => a + sp + d + '\n' + sp + LIBS);
}
if (!/versionCode\s+\d+/.test(g) || !/versionName\s+"[^"]*"/.test(g)) falta('no encuentro versionCode/versionName en app/build.gradle');
g = g.replace(/versionCode\s+\d+/, 'versionCode ' + VERSION_CODE).replace(/versionName\s+"[^"]*"/, 'versionName "' + VERSION_NAME + '"');
fs.writeFileSync(bg, g);

/* 3) ícono de notificaciones */
const dr = path.join(AND, 'app/src/main/res/drawable');
fs.mkdirSync(dr, { recursive: true });
fs.writeFileSync(path.join(dr, 'ic_stat_mesa.xml'), `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="512" android:viewportHeight="512">
    <path android:pathData="M132,376L132,212L256,332L380,212L380,376" android:strokeColor="#FFFFFF" android:strokeWidth="56" android:strokeLineCap="round" android:strokeLineJoin="round"/>
</vector>
`);
/* 4) atajos, enlaces mesapro:// y splash animado */
const RES = path.join(AND, 'app/src/main/res');
let m2 = leer(mf);
if (m2.indexOf('android:scheme="mesapro"') < 0) {
  const re = /(<activity\b[^>]*android:name="\.MainActivity"[\s\S]*?)(\n\s*<\/activity>)/;
  if (!re.test(m2)) falta('no encuentro la MainActivity en el manifest');
  m2 = m2.replace(re, (t, a, b) => a + `
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="mesapro" />
            </intent-filter>
            <meta-data android:name="android.app.shortcuts" android:resource="@xml/shortcuts" />` + b);
  fs.writeFileSync(mf, m2);
}
const escribir = (rel, txt) => { const f = path.join(RES, rel); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, txt); };
const PKG = 'ar.lucas.mesapro';
const atajo = (id, corto, largo, ruta, icono) => `    <shortcut android:shortcutId="${id}" android:enabled="true" android:icon="@drawable/${icono}" android:shortcutShortLabel="@string/${corto}" android:shortcutLongLabel="@string/${largo}">
        <intent android:action="android.intent.action.VIEW" android:data="mesapro://${ruta}" android:targetPackage="${PKG}" android:targetClass="${PKG}.MainActivity" />
    </shortcut>`;
escribir('xml/shortcuts.xml', `<?xml version="1.0" encoding="utf-8"?>
<shortcuts xmlns:android="http://schemas.android.com/apk/res/android">
${atajo('hoy', 'atajo_hoy', 'atajo_hoy_largo', 'hoy', 'ic_atajo_hoy')}
${atajo('killzone', 'atajo_kz', 'atajo_kz_largo', 'killzone', 'ic_atajo_kz')}
${atajo('gasto', 'atajo_gasto', 'atajo_gasto_largo', 'gasto', 'ic_atajo_gasto')}
</shortcuts>
`);
escribir('values/mesa_atajos.xml', `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="atajo_hoy">Hoy</string>
    <string name="atajo_hoy_largo">Tablero de hoy</string>
    <string name="atajo_kz">Killzone</string>
    <string name="atajo_kz_largo">Modo Killzone</string>
    <string name="atajo_gasto">Cargar gasto</string>
    <string name="atajo_gasto_largo">Cargar un gasto</string>
</resources>
`);
const icono = (nombre, paths) => escribir('drawable/' + nombre + '.xml', `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">
${paths.map(d => `    <path android:pathData="${d}" android:strokeColor="#2349C0" android:strokeWidth="2" android:strokeLineCap="round" android:strokeLineJoin="round" />`).join('\n')}
</vector>
`);
icono('ic_atajo_hoy', ['M12,5.5a7.5,7.5 0,1 1,0 15a7.5,7.5 0,1 1,0 -15z', 'M12,9.2L12,13L14.6,14.7', 'M9.5,2.8L14.5,2.8']);
icono('ic_atajo_kz', ['M12,3.5a8.5,8.5 0,1 1,0 17a8.5,8.5 0,1 1,0 -17z', 'M12,8.5a3.5,3.5 0,1 1,0 7a3.5,3.5 0,1 1,0 -7z', 'M12,1.5L12,5.5M12,18.5L12,22.5M1.5,12L5.5,12M18.5,12L22.5,12']);
icono('ic_atajo_gasto', ['M12,5L12,19', 'M5,12L19,12']);
/* splash: la "M" se dibuja y se enciende el punto verde (Android 12+). El estático va para Android 11 o menos. */
const M_PATH = 'M29.82,78.6L29.82,46.6L54,70L78.18,46.6L78.18,78.6', PUNTO = 'M72.52,31a5.27,5.27 0,1 0,10.54 0a5.27,5.27 0,1 0,-10.54 0z';
const vectorSplash = (anim) => `<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
        <path android:name="m" android:pathData="${M_PATH}" android:strokeColor="#7FA8FF" android:strokeWidth="10.9" android:strokeLineCap="round" android:strokeLineJoin="round"${anim ? ' android:trimPathEnd="0"' : ''} />
        <path android:name="punto" android:pathData="${PUNTO}" android:fillColor="#2FD27F"${anim ? ' android:fillAlpha="0"' : ''} />
    </vector>`;
escribir('drawable/splash_animado.xml', '<?xml version="1.0" encoding="utf-8"?>\n' + vectorSplash(false).replace('<vector ', '<vector ') + '\n');
escribir('drawable-v31/splash_animado.xml', `<?xml version="1.0" encoding="utf-8"?>
<animated-vector xmlns:android="http://schemas.android.com/apk/res/android" xmlns:aapt="http://schemas.android.com/aapt">
    <aapt:attr name="android:drawable">
    ${vectorSplash(true).replace(' xmlns:android="http://schemas.android.com/apk/res/android"', '')}
    </aapt:attr>
    <target android:name="m">
        <aapt:attr name="android:animation">
            <objectAnimator android:propertyName="trimPathEnd" android:valueFrom="0" android:valueTo="1" android:valueType="floatType" android:duration="700" android:interpolator="@android:interpolator/fast_out_slow_in" />
        </aapt:attr>
    </target>
    <target android:name="punto">
        <aapt:attr name="android:animation">
            <objectAnimator android:propertyName="fillAlpha" android:valueFrom="0" android:valueTo="1" android:valueType="floatType" android:startOffset="550" android:duration="300" />
        </aapt:attr>
    </target>
</animated-vector>
`);

console.log('patch-android: listo (versionName ' + VERSION_NAME + ', versionCode ' + VERSION_CODE + ')');
