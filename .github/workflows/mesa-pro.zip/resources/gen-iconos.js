// Genera los PNG del ícono y la pantalla de bienvenida a partir de icon.svg. Uso: node resources/gen-iconos.js
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path');
const svg = fs.readFileSync(path.join(__dirname, 'icon.svg'), 'utf8');
const dens = { mdpi: 48, hdpi: 72, xhdpi: 96, xxhdpi: 144, xxxhdpi: 192 };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage();
  async function shot(html, w, h, out, omit) {
    await p.setViewportSize({ width: w, height: h }); await p.setContent(`<style>html,body{margin:0;background:${omit ? 'transparent' : '#0A0F15'}}</style>${html}`);
    fs.mkdirSync(path.dirname(out), { recursive: true }); await p.screenshot({ path: out, omitBackground: !!omit });
  }
  const inline = (sz, extra = '') => `<div style="width:${sz}px;height:${sz}px;${extra}">${svg.replace('<svg ', `<svg width="${sz}" height="${sz}" `)}</div>`;
  for (const [d, sz] of Object.entries(dens)) {
    const dir = path.join(__dirname, 'android', 'mipmap-' + d);
    await shot(inline(sz), sz, sz, path.join(dir, 'ic_launcher.png'), true);
    await shot(inline(sz, 'border-radius:50%;overflow:hidden;background:#0A0F15'), sz, sz, path.join(dir, 'ic_launcher_round.png'), true);
  }
  // Primer plano del ícono adaptativo (lienzo de 108 dp; la marca queda en la zona segura central)
  const fg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108"><defs><linearGradient id="t" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#B4CCFF"/><stop offset="1" stop-color="#6C98FF"/></linearGradient></defs><g transform="translate(54 55) scale(.195) translate(-256 -255)"><path d="M132 376V212L256 332 380 212V376" fill="none" stroke="url(#t)" stroke-width="56" stroke-linecap="round" stroke-linejoin="round"/><circle cx="378" cy="132" r="27" fill="#2FD27F"/></g></svg>`;
  const fgd = { mdpi: 108, hdpi: 162, xhdpi: 216, xxhdpi: 324, xxxhdpi: 432 };
  for (const [d, sz] of Object.entries(fgd)) await shot(`<div style="width:${sz}px;height:${sz}px">${fg.replace('<svg ', `<svg width="${sz}" height="${sz}" `)}</div>`, sz, sz, path.join(__dirname, 'android', 'mipmap-' + d, 'ic_launcher_foreground.png'), true);
  await shot(inline(512), 512, 512, path.join(__dirname, 'icon-512.png'), true);
  const logo = (w, h, s) => `<div style="width:${w}px;height:${h}px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:${s * .22}px;background:#0A0F15"><div style="width:${s}px;height:${s}px">${svg.replace('<svg ', `<svg width="${s}" height="${s}" `)}</div><div style="font:800 ${s * .26}px Bricolage,system-ui,sans-serif;color:#EEF3F8;letter-spacing:-.01em">Mesa <span style="color:#7FA8FF">PRO</span></div></div>`;
  const font = `<style>@font-face{font-family:Bricolage;src:url(data:font/woff2;base64,${fs.readFileSync(path.resolve(__dirname, '../www/fonts/bricolage.woff2')).toString('base64')});font-weight:200 800}</style>`;
  await shot(font + logo(1080, 1920, 300), 1080, 1920, path.join(__dirname, 'android', 'splash-port.png'));
  await shot(font + logo(1920, 1080, 300), 1920, 1080, path.join(__dirname, 'android', 'splash-land.png'));
  await b.close();
})();
