# Mesa PRO v2: qué cambió

Versión 2.0 (versionName "2.0"). Rutas relativas a la raíz del repo. Todo lo de esta lista está en `v2-src/` (carpeta que se sube a GitHub como `src/`), salvo los tests.

## Cómo se publica

1. En GitHub, subí el **contenido** de `v2-src/` (sin la carpeta `v2-src` en sí) a una carpeta llamada `src/` en la raíz del repo (junto a `.github/`). Mantiene las mismas rutas: `src/www/js/app.js`, `src/resources/patch-android.js`, etc.
2. Reemplazá `.github/workflows/apk.yml` por el contenido de `apk-v2.yml` (también está en `v2-src/apk-v2.yml`). Ese archivo y `Datos.gs` también están sueltos en la raíz de `v2-src/` solo por comodidad (si quedan dentro de `src/` no molestan: el workflow copia `src/` encima del zip con `cp -r src/. .`).
3. En script.google.com pegá el `Datos.gs` nuevo y publicá **Nueva versión** de la implementación (la URL no cambia). Pasos en `apps-script/LEEME.md`, sección "Actualizar a la versión 2".
4. El APK nuevo se baja de Releases como siempre. En Ajustes, tocá **Activar avisos** y poné la batería de Mesa PRO en **Sin restricciones**.

## Archivos cambiados o agregados

Agregados (A) y modificados (M):

| Archivo | | Qué es |
|---|---|---|
| `apps-script/Datos.gs` | M | Reescrito: `doGet` (datos + ediciones aplicadas + `ediciones_version`, y `?solo=ediciones`) y `doPost` (guarda ediciones con candado). Lógica pura al final del archivo (`aplicarEdiciones_`, `unirEdiciones_`, `validarItems_`). |
| `apps-script/LEEME.md` | M | Pasos para actualizar el script y cómo funciona POST. |
| `LEEME.md` | M | Novedades de la v2. |
| `apk-v2.yml` | A | Workflow nuevo (copiar a `.github/workflows/apk.yml`). |
| `capacitor.config.json` | M | `plugins.BackgroundRunner` (label `ar.lucas.mesapro.check`, `runners/check.js`, evento `check`, cada 30 min, autoStart) y `LocalNotifications` (ícono `ic_stat_mesa`). |
| `package.json` / `package-lock.json` | M | Versión 2.0.0, dependencia `@capacitor/background-runner` **2.0.0** (la línea compatible con Capacitor 6; la 2.3.x es de Capacitor 7), scripts `runner` y `test`. |
| `resources/patch-android.js` | A | Después de `cap add android`: permisos (POST_NOTIFICATIONS, SCHEDULE_EXACT_ALARM, RECEIVE_BOOT_COMPLETED, WAKE_LOCK, ACCESS_NETWORK_STATE), saca los permisos de ubicación que trae background-runner, agrega su carpeta de libs a `app/build.gradle`, versionName "2.0" y versionCode (`MESA_VERSION_CODE` o 2), ícono de notificaciones. Idempotente. |
| `resources/build-runner.js` | A | Arma `www/runners/check.js` pegando `calc.js` + `alertas.js` + `runner-body.js` (mismas reglas que la app). `--verificar` falla si está desactualizado. |
| `resources/runner-body.js` | A | Código propio del chequeo en segundo plano (eventos `check`, `config`, `estado`, `marcar`). |
| `www/runners/check.js` | A | **Generado** por `build-runner.js` (también lo corre el workflow). No editar a mano. |
| `www/js/alertas.js` | A | Reglas de alertas (puras) y deduplicado de notificaciones. Compartido app + runner. |
| `www/js/ediciones.js` | A | Mezcla de ediciones (misma lógica que `Datos.gs`), cola de envío (outbox) y POST. |
| `www/js/calc.js` | M | `normalizar` conserva campos nuevos; `resumen` excluye suscripciones pausadas, agrega `vencimientos` y delega las alertas a `alertas.js`. |
| `www/js/avisos.js` | M | Reescrito: notificaciones sin repetir, preferencias por categoría, recordatorios 3d/1d/0d a las 10:00 con ids estables, puente al runner, botón de prueba. |
| `www/js/app.js` | M | Formularios en hojas (movimiento, suscripción, cuenta manual, nota), confirmar borrado, deshacer 5 s, pausar, botón +, chip "Sin sincronizar (N)", próximos vencimientos, Ajustes > Notificaciones. |
| `www/css/app.css` | M | Estilos nuevos al final (mismo lenguaje de diseño). |
| `www/index.html` | M | Scripts nuevos, botón +, toast con acción, diálogo de confirmación, chip de sincronización. |
| `www/data/demo.json` | M | Ejemplos de todos los campos nuevos (datos inventados, ids `DEMO-xxxx`). |
| `www/data/schema.md` | M | Documentación de los campos nuevos (leer primero). |
| `CAMBIOS-v2.md` | A | Este archivo. |

Solo en `test/` (no van en el overlay; `test/` está en `.gitignore`): `merge.test.js`, `alertas.test.js`, `e2e-v2.js`, `mock-appsscript.js`, y `unit.js` (ajustado para cargar `alertas.js`). Correr con `npm test` (los dos primeros) y `node test/e2e-v2.js` (con un servidor estático en el puerto 8765).

## Qué tiene que escribir el contador automático en `mesa-datos.json`

Todo es opcional (un archivo viejo sigue funcionando). Detalle completo en `www/data/schema.md`.

**`cuentas[]`**
- `origen`: `"auto"`. (Las cuentas `"manual"` las crea la app; el contador no las escribe ni las toca.)
- `payout`: `{ dias_ok, dias_req, minimo_dia, pct_retiro, max_retiro, elegible, bloqueo, solucion, proximo_ciclo }`:
  - `dias_ok` / `dias_req`: días de payout cumplidos / exigidos.
  - `minimo_dia`: ganancia mínima (US$) para que un día cuente. `pct_retiro`: % de la ganancia que se retira. `max_retiro`: máximo a retirar hoy (US$).
  - `elegible`: `true` solo si cumple TODO y puede pedir el retiro ya. Dispara **Listo para retirar**.
  - `bloqueo`: una frase con el motivo cuando NO puede retirar y tiene arreglo (consistencia > 40 %, KYC pendiente, mínimo de días…); `null` si no hay. `solucion`: qué hacer, con verbo (`operá varios días chicos…`). Con `elegible: false` y `bloqueo` con texto dispara **Retiro frenado, tiene arreglo**.
  - `proximo_ciclo`: fecha o `null`.
- `nota`: no la escribe el contador (es de Lucas); si regenera el archivo puede omitirla (las notas viven en `mesa-ediciones.json`).

**`alertas[]`**: además de `nivel` y `texto`, ahora `id` (estable; evita avisar dos veces), `codigo`, `cuenta_id`, `accion` (qué hacer, se agrega al final del texto).
- `codigo: "listo_retiro"` (cualquier nivel): notifica "Listo para retirar".
- `codigo: "retiro_bloqueado"`: `texto` = motivo, `accion` = solución.
- `retiro_cerca`, `margen_bajo`, `cuenta_perdida`, `datos_viejos`: se clasifican en su categoría. Cualquier otro código (o ninguno): categoría "Avisos del contador".
- Notifican las `bad` y `warn` y las `ok` con `listo_retiro`. Las demás `ok` solo se ven en pantalla.

**Reglas que la app calcula sola** (no hace falta que el contador las repita): margen < 25 % del colchón (rojo) / < 50 % (amarillo), cuenta perdida, objetivo alcanzado, muy cerca de retirar (`dias_ok >= dias_req - 1` o ganancia ≥ 85 % del objetivo), datos con más de 48 h, pagos a 3 días / mañana / hoy (solo suscripciones no pausadas).

El contador **no** debe escribir `ediciones_version`, `origen: "manual"/"editado"` ni `pausada` en movimientos/suscripciones: los pone el servidor al mezclar.

## Cómo funcionan ediciones, `doPost` y la mezcla

- Archivo `mesa-ediciones.json` (se crea solo en la raíz de Drive): `{ "version": n, "items": [ { "col": "movimientos"|"suscripciones"|"cuentas", "op": "upsert"|"delete", "id": "…", "data": {…}, "ts": "ISO" } ] }`.
- **Un item por (col, id)**: el de `ts` más nuevo. Dos `upsert` seguidos se suman campo a campo (la app manda solo los campos que cambió).
- **`doGet(?k=CLAVE)`**: `mesa-datos.json` (el más nuevo) con las ediciones aplicadas + `ediciones_version`. `upsert` sobre un elemento del servidor mezcla campos y deja `origen: "editado"`; con id nuevo crea el elemento (si tiene los mínimos: movimiento con `fecha` y `monto`, suscripción con `servicio`, cuenta con `saldo`) con `origen: "manual"`; `delete` lo saca. Las cuentas del servidor solo aceptan `nota`. Un `upsert` incompleto sobre un id que no existe se ignora. Lo creado a mano usa ids `man-…`.
- **`doGet(?k=CLAVE&solo=ediciones)`**: el archivo de ediciones crudo.
- **`doPost`**: cuerpo = texto JSON `{k, items:[…]}` con `Content-Type: text/plain` (así el navegador no hace "preflight" de CORS). Valida clave, tamaño (< 200 KB), hasta 200 items, `col` y `op` permitidos, `id` texto de hasta 80 caracteres, `data` objeto en los `upsert`. Si algo está mal rechaza TODO y no guarda nada (`{ok:false,error,indice}`). Toma un candado (`LockService`), une con lo existente (el `ts` del futuro o inválido se corrige a la hora del servidor), sube `version` en 1, guarda y responde `{ok:true,version}`.
- **App**: cada cambio se aplica enseguida en pantalla y se guarda en una cola en el celular (`mesa.outbox`). Se manda por POST ~1,2 s después (los borrados esperan 5,5 s por el "Deshacer"). Si no hay conexión o falla, queda en la cola y se reintenta en la próxima actualización (al abrir, cada 15 min, al tocar el chip o tirar hacia abajo); mientras tanto se ve el chip "Sin sincronizar (N)". Después de enviar, la app vuelve a pedir los datos y descarta lo ya confirmado. Sin URL configurada (modo ejemplo) los cambios quedan solo en el celular (`mesa.local`), con aviso en los formularios.

## Avisos con la app cerrada

- `@capacitor/background-runner` 2.0.0 corre `runners/check.js` cada ~30 min (Android puede atrasarlo). La app le deja URL, clave, categorías prendidas y si hay recordatorios programados (evento `config`, guardado en `CapacitorKV`). El runner pide los datos, calcula las alertas con **el mismo código que la app** y notifica solo las nuevas (`notificadas` en KV: clave → fecha; se limpia cuando la alerta desaparece). Los ids de notificación son un hash de la clave, así que si la app y el runner avisan lo mismo, una reemplaza a la otra.
- Recordatorios de pagos: notificaciones locales programadas a las 10:00, 3 días antes, 1 día antes y el mismo día, para el próximo vencimiento y el siguiente (ids negativos estables; se cancelan y se reprograman cada vez que cambian los datos). Si están programados, el runner no repite los avisos de pago.

## Riesgos conocidos

- **background-runner**: Android decide cuándo corre (mínimo 15 min, puede atrasarse con ahorro de batería o en celulares de marcas con restricciones fuertes: Xiaomi, Huawei, Samsung "dormir apps"). No se pudo probar en un celular ni compilar localmente (no hay SDK de Android acá): la compilación y el primer chequeo real quedan para el primer APK. El entorno del runner no tiene DOM y su `fetch` solo soporta `method`, `headers` y `body`: si no siguiera el redirect 302 de Apps Script (script.google.com → script.googleusercontent.com), el chequeo en segundo plano fallaría (se ve en Ajustes: "Último chequeo… Hubo un error"); los recordatorios de pago y los avisos con la app abierta no dependen de eso.
- Los APK de prueba (debug) se firman con una clave distinta en cada armado de GitHub, salvo que cargues el secreto `DEBUG_KEYSTORE_B64` (Settings > Secrets and variables > Actions): es un `debug.keystore` en base64 (alias `androiddebugkey`, claves `android`); el workflow lo instala en `~/.android/debug.keystore` y todos los APK quedan con la misma firma, así se instalan encima sin perder datos. Sin el secreto, puede hacer falta desinstalar la versión anterior (se pierde lo no sincronizado). La primera vez que pasás a una firma fija también hay que desinstalar una vez.
- `npm install` (en vez de `npm ci`) puede traer versiones de dependencias transitivas distintas a las del lock.
- Dos celulares editando lo mismo a la vez: gana el cambio con `ts` más nuevo; los campos distintos se suman.
