# Mesa PRO 3.0 · Etapa 1 · Entrega

Carpeta de trabajo: `/home/claude/mesa-v3` (copia de `mesa-app`, que no se tocó). Versión `3.0.0`, versionName `3.0`, versionCode `3000 + número de corrida` (la v2 usaba `1000 + corrida`, así que siempre es mayor).

## Qué hice

1. **Todo lo de la v2 sigue andando**: semáforo, cuentas, libro de plata, suscripciones, alta/edición/baja/pausa con cola y chip "Sin sincronizar", recordatorios, avisos locales y chequeo en segundo plano, modo sin conexión con caché y conexión con clave. Los tests de la v2 se adaptaron a la navegación nueva sin perder casos (ver "Pruebas").
2. **Navegación nueva**: Hoy / Cuentas / Diario / Plata (Movimientos | Suscripciones) / Más. Botón **+** en todas las pestañas (en Hoy, Cuentas y Más abre un menú: nota, gasto, suscripción, cuenta manual, Killzone). **Lupa** con búsqueda en movimientos, suscripciones, cuentas y diario (sin importar mayúsculas ni tildes).
3. **Diario**: notas por día con etiquetas (fijas + propias) y cuenta opcional, filtro por etiqueta, editar/borrar con "Deshacer". Viaja por la **misma cola de ediciones** (colección nueva `diario`, en `ediciones.js` y en `apps-script/Datos.gs`, con la misma validación en los dos).
4. **Hoy (tablero antes de la apertura)**, con funciones puras en `www/js/riesgo.js` (las usa también el chequeo en segundo plano):
   - cuenta regresiva a las 09:30 de Nueva York calculada con `Intl` y la zona `America/New_York` (sin números fijos: hoy da 11:30 en Argentina, en verano de EE. UU. 10:30), feriados de NYSE 2026–2027, sesión de los scripts hasta las 15:45 NY (17:45 AR) con barra de avance;
   - "cuánto podés perder hoy" = mín(margen hasta el piso, tope de 1.000 de los scripts), diciendo cuál manda;
   - "cuánto podés ganar sin romper la consistencia del 40 %" = máx(40 % del objetivo, 2/3 de lo ganado), con mejor día, consistencia actual y cuánto falta para destrabar;
   - calculadora de tamaño (MNQ 2, MYM 0,5, MES 5, NQ 20, YM 5, ES 50 US$/punto; comisión editable);
   - estado de la mesa: contrato vigente Dic 26 (Z26) hasta el roll 09–10/12 (calculado: tercer viernes − 8 días), alertas de TradingView 08/12 22:44 y 09/12, semana crítica 7–11/12, recordatorios y frescura de datos. Las alertas de TradingView y el roll avisan 3 días antes (categoría nueva "Infraestructura", también con la app cerrada).
   - Cada número derivado dice de qué corte de datos sale ("al cierre del 30/10 a las 18:42").
5. **Modo Killzone**: pantalla completa con reloj (falta para abrir o tiempo que queda de sesión), podés perder hoy, colchón, tope y techo de ganancia, checklist editable (se destilda solo al otro día) y **Frenar por hoy**: guarda la marca del día, la anota en el Diario y deja pasar solo avisos críticos (app y chequeo en segundo plano). Pantalla encendida con `navigator.wakeLock` si el WebView lo tiene (sin plugin nuevo; si no está, no hace nada).
6. **Visual "Cabina"**: tokens oscuro/claro nuevos, vidrio, tarjeta héroe 3D (en Hoy el semáforo-lámpara que respira; en Cuentas la cuenta principal) que se inclina con el **giroscopio** y con el **dedo**, con brillo especular, sombra que se corre y capas a distinta altura; fondo de 3 capas con paralaje; números con **rodillo** (solo giran los dígitos que cambian); anillo con luz y punta brillante; tarjetas que se hunden con resorte; sheet con cabecera de vidrio; chispas (canvas, 1,2 s). Ajustes **Automático / Máximo / Ahorro**: Automático mide los cuadros al abrir y baja los efectos solo si el p95 pasa 22 ms; `prefers-reduced-motion` apaga todo. Solo se anima transform/opacity.
7. **Gráficos analizables** (detalle de cuenta) con **Lightweight Charts 5.0.9** vendorizada en `www/vendor/` (se carga recién al abrir el detalle; logo de TradingView en el gráfico y atribución + licencia en Más > Acerca de): curva de saldo base 50.000 verde/rojo, piso (serie con arrastre si viene en `curva`, si no "piso hoy") y objetivo; cruz que muestra saldo, **margen sobre el piso**, resultado y operaciones del día; pellizco para zoom; rangos 7/14/30/Todo; drawdown sincronizado (rango y cruz) con línea de pérdida máxima; calendario por día en SVG con el mejor día marcado y navegación por mes. Lee `curva` (filas posicionales) y `historial_saldo` (v2). Con menos de 2 días: aviso explicativo, nunca inventa. `touch-action: pan-y` y el sheet no se arrastra desde el gráfico. En la tarjeta de la cuenta, una línea chica de la curva.
8. **Nativo (un solo APK)**: `@capacitor/status-bar` 6.0.3 (barra según tema), `@capacitor/app` 6.0.3 (enlaces `mesapro://`, volver de segundo plano), **atajos** del ícono (Hoy, Killzone, Cargar gasto) por `shortcuts.xml` escrito en `resources/patch-android.js`, **splash animado** en Android 12+ (la "M" se dibuja y se enciende el punto; en 11 o menos, el mismo ícono estático), **canales** de notificación Críticos / Recordatorios / Información y **botones** en los avisos ("Abrir Killzone", "Ver Hoy", "Ver suscripciones"), **huella opcional** apagada por defecto (`@aparajita/capacitor-biometric-auth` 9.0.0: es Java + AGP 8.2.2 + androidx.biometric 1.1.0, compatible con Capacitor 6, por eso la dejé), y pantalla tapada al pasar a segundo plano. Versiones exactas en `package.json` y `package-lock.json`.
9. **Actualización por aire con rescate**: `index.html` + `js/arranque.js` son la cáscara fija del APK; cargan `marco.html` + css + js (de fábrica o del paquete bajado). La app baja `mesa-web.json` del mismo Apps Script (`?k=CLAVE&web=1`), verifica forma, rutas permitidas y **SHA-256**, lo guarda (`@capacitor/filesystem`, en el navegador `localStorage`) y lo aplica al próximo arranque. Si la versión nueva **no confirma "arranqué bien" en 8 s** o **falla 2 veces**, vuelve sola a la de fábrica y la marca como mala. En Más: versión del APK, versión en uso, "Buscar actualización", "Aplicar ahora" y "Volver a la de fábrica". `resources/build-web.js` arma `upload/mesa-web.json` desde `www/`.
10. **Apps Script** `apps-script/Datos.gs`: colección `diario` en `COLS_` y en la validación, y acción `web=1`, sin cambiar `doGet`/`doPost` ni la clave. Documentado en `apps-script/LEEME.md`.

## Qué quedó afuera y por qué

- **Widget**: es Etapa 3 (pedido explícito).
- **Notificaciones con canal propio desde el chequeo en segundo plano**: el runner de Capacitor solo admite título y texto; esas siguen en el canal por defecto. Los avisos que manda la app (abierta) y los recordatorios sí usan los canales y los botones.
- **Alejar la pantalla de atrás al abrir un sheet** (efecto #12 de 02-visual): lo implementé y lo medí; con la CPU frenada 4 veces hacía perder cuadros al mover la cruz del gráfico, así que lo saqué (el velo oscuro ya da la profundidad). Por lo mismo cambié la sombra 3D con `filter: blur` por un degradé y el vidrio de la cabecera del sheet por un color sólido.
- **Transición compartida tarjeta → detalle** (View Transitions, efecto #6): no es de Etapa 1 y el plan la deja para el final.
- **El APK no se compiló acá** (no hay SDK de Android en el contenedor). `patch-android.js` se probó sobre la plantilla real de Capacitor 6.2.2 (`android-template.tar.gz`): corre dos veces sin duplicar y los 18 XML resultantes validan con un parser. El primer error posible aparece recién en GitHub Actions.
- El `ic_launcher_background` sigue en `#0A0F15` (el fondo nuevo es `#070B11`; la diferencia no se ve en el ícono).

## Cómo probar en el celular

1. GitHub (desde la PC): subí `upload/mesa-pro.zip` y `upload/apk.yml` a `.github/workflows/` (el zip con ese nombre exacto) y **Commit changes**. El workflow viejo copiaba la carpeta `src/` de la v2: el nuevo ya no la usa (podés borrarla).
2. Verificá que exista el secreto `DEBUG_KEYSTORE_B64` (si falta, el workflow avisa y el APK no se instala encima). La primera vez que pasás a esta firma, desinstalá la v2.
3. Bajá `app-debug.apk` de Releases (Mesa PRO 3.0) e instalalo.
4. En Apps Script pegá el `Datos.gs` nuevo y publicá **Nueva versión** (la URL no cambia).
5. Checklist corto: abrir en frío; Hoy dice "11:30 en Argentina"; inclinar el celular (la tarjeta se mueve); abrir una cuenta y tocar/pellizcar la curva; Killzone y "Frenar por hoy"; mantener apretado el ícono (3 atajos); Más > Probar rendimiento; Más > Probar notificación (y botones del aviso); Más > Privacidad > Pedir huella; Más > Buscar actualización (con un `mesa-web.json` de versión mayor en Drive). **Pendiente de probar en el aparato**: giroscopio, huella, atajos, splash animado, canales/botones y pantalla encendida en Killzone.

## Archivos

Nuevos: `www/js/riesgo.js`, `www/js/arranque.js`, `www/js/ota.js`, `www/js/fx.js`, `www/js/graficos.js`, `www/marco.html`, `www/manifiesto.json`, `www/css/fuentes.css`, `www/vendor/lightweight-charts.js`, `www/vendor/LICENSE-lightweight-charts.txt`, `resources/build-web.js`, `test/riesgo.test.js`, `test/e2e-v3.js`, `test/gestos-v3.js`, `test/ota.e2e.js`, `test/perf-v3.js`, `test/shots-v3.js`, `test/capturas-v3/` (46 capturas), `upload/mesa-pro.zip`, `upload/apk.yml`, `upload/mesa-web.json` (3.0.0, solo de muestra), `ENTREGA-v3.md`.

Cambiados: `www/index.html` (ahora es la cáscara), `www/js/app.js`, `www/js/calc.js` (`M.ahora`, `diario`, cuenta principal), `www/js/alertas.js` (categoría Infraestructura, "frenado"), `www/js/avisos.js` (canales, botones, frenado), `www/js/ediciones.js` (`diario`), `www/css/app.css`, `www/data/demo.json` (curva, historial y diario de ejemplo), `www/data/schema.md`, `www/runners/check.js` (regenerado), `resources/runner-body.js`, `resources/build-runner.js`, `resources/patch-android.js`, `resources/android/values/styles.xml`, `apps-script/Datos.gs`, `apps-script/LEEME.md`, `LEEME.md`, `package.json`, `package-lock.json`, `capacitor.config.json`, `test/merge.test.js`, `test/alertas.test.js`, `test/mock-appsscript.js`.

Reemplazados (cobertura pasada a los nuevos): `test/e2e-v2.js` → `e2e-v3.js`; `test/interact.js`, `test/escenarios.js`, `test/shots.js` → `gestos-v3.js` y `shots-v3.js` (con verificaciones en vez de solo capturas).

## Pruebas (con servidor estático en el puerto 8766 desde la raíz)

| Prueba | Resultado |
|---|---|
| `node --check` de todo el JS (26 archivos, incluido `Datos.gs`) | OK |
| `npm test`: merge (app = Apps Script, diario, web=1) / alertas + runner sin DOM / riesgo (NY, DST, feriados, perder/ganar, curva, tamaño, contrato) | 28 / 24 / 17 OK |
| `test/e2e-v3.js`: v2 completa (claro y oscuro, ejemplo y Apps Script simulado, offline) + Diario, búsqueda, Killzone, calculadora, gráficos (carga diferida, cruz contra el dato, rango, mejor día, atribución, destrucción, vacío), escapado de `<img onerror>`, atajos y reduced-motion | 116 OK, 0 fallas |
| `test/gestos-v3.js`: deslizar pestañas, arrastre en el gráfico, cerrar sheet, tirar para actualizar, tooltip, filtros, CSV, skeleton, error, vacío, mal formado, URL mala, HTML | 28 OK, 0 fallas |
| `test/ota.e2e.js`: baja + verifica + aplica al reabrir, hash dañado, ruta prohibida, APK nuevo requerido, 2 fallas → fábrica, sin confirmar en 8 s → fábrica, "Volver a la de fábrica" | 23 OK, 0 fallas |
| `resources/build-runner.js --verificar`, YAML del workflow, JSON de configuración, `patch-android.js` ×2 sobre la plantilla real + 18 XML válidos | OK |
| Búsqueda de secretos en el código | sin hallazgos |

## Rendimiento (CPU frenada ×4 por CDP, 390×844, DPR 2, efectos en Máximo)

`node test/perf-v3.js` (frame = tiempo entre `requestAnimationFrame`; 16,7 ms = 60 fps):

| Escena | p95 |
|---|---|
| Scroll de Hoy | 16,8 ms |
| Cambio de pestaña (8 veces) | 16,8 ms |
| Tarjeta 3D con el dedo | 16,8 ms |
| Abrir detalle (incluye la carga única de la librería de gráficos, 182 KB) | 16,8–33,3 ms |
| Cruz (crosshair) sobre la curva | **16,8 ms en 4 de 7 corridas, 33,3 ms en las otras 3** (promedio 17–19 ms: ~5 % de cuadros dobles) |
| Cerrar detalle | 16,8 ms |
| **p95 global** | **16,8 ms** |

Lectura honesta: todo queda en 60 fps salvo la cruz del gráfico, que está justo en el borde del umbral de 20 ms en este Chromium sin GPU (pierde 1 de cada ~20 cuadros). Ya saqué lo que la empeoraba (sombra con `filter: blur`, alejar la pantalla de atrás, vidrios con `backdrop-filter` detrás del sheet: con eso pasó de 33 ms fijos a esto). En el celular el canvas va por GPU; confirmarlo con Más > Probar rendimiento. Si en tu celular se nota, el modo Ahorro lo resuelve.

## Capturas

`test/capturas-v3/`: cada pestaña en claro y oscuro (Hoy en 4 alturas, Cuentas, Diario, Plata, Suscripciones, Más en 3 alturas), detalle de cuenta con curva, cruz y calendario, Killzone (con checklist), búsqueda, menú del +, tarjeta 3D inclinada, y Hoy/cuenta con `vacio.json`, `rojo.json` y `rico.json`. Las miré y corregí: marco cuadrado detrás del héroe, tarjetas del Diario y del menú que no quedaban en fila, ícono de suscripción, hora sin "p. m." en Más, pastilla "Antes de abrir" partida en dos líneas, línea de "quema" del drawdown.
