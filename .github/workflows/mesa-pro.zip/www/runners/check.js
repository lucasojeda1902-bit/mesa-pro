/* ARCHIVO GENERADO por resources/build-runner.js. No lo edites: cambiá www/js/calc.js, www/js/riesgo.js, www/js/alertas.js o resources/runner-body.js y volvé a correr el script. */
var window = (typeof globalThis !== "undefined") ? globalThis : this;
/* Mesa PRO - formato y cuentas. Sin dependencias. */
(function (g) {
  var M = g.Mesa = g.Mesa || {};
  var CAT_CUENTAS = "Cuentas de fondeo";
  var MESES = ["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];
  var DIAS = ["domingo","lunes","martes","miércoles","jueves","viernes","sábado"];
  var FREC = { semanal: 12 / 52, mensual: 1, bimestral: 2, trimestral: 3, semestral: 6, anual: 12 };
  var FREC_TXT = { semanal: "por semana", mensual: "por mes", bimestral: "cada 2 meses", trimestral: "cada 3 meses", semestral: "cada 6 meses", anual: "por año" };
  M.CAT_CUENTAS = CAT_CUENTAS; M.MESES = MESES; M.FREC_TXT = FREC_TXT;

  function parseISO(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || "");
    return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
  }
  function iso(d) { return d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate()); }
  function p2(n) { return (n < 10 ? "0" : "") + n; }
  M.parseISO = parseISO; M.iso = iso;
  function param(k) { try { if (!(g.Capacitor && g.Capacitor.isNativePlatform && g.Capacitor.isNativePlatform()) && g.location) return new URLSearchParams(location.search).get(k); } catch (e) {} return null; }
  /* ?ahora=ISO (solo en el navegador, para pruebas) fija el reloj; ?hoy=AAAA-MM-DD fija solo el día. */
  var desfase = 0; (function () { var a = param("ahora"), t = a ? new Date(a).getTime() : NaN; if (isFinite(t)) desfase = t - Date.now(); })();
  M.ahora = function () { return new Date(Date.now() + desfase); };
  M.hoy = function () {
    var q = param("hoy"), d = q ? parseISO(q) : null;
    if (d) return d;
    var n = M.ahora(); return new Date(n.getFullYear(), n.getMonth(), n.getDate());
  };
  M.fecha = function (s) { var d = typeof s === "string" ? parseISO(s) : s; return d ? p2(d.getDate()) + "/" + p2(d.getMonth() + 1) + "/" + d.getFullYear() : "—"; };
  M.fechaCorta = function (s) { var d = parseISO(s); if (!d) return "—"; return d.getDate() + " " + MESES[d.getMonth()].slice(0, 3) + (d.getFullYear() !== M.hoy().getFullYear() ? " " + d.getFullYear() : ""); };
  M.fechaLarga = function (d) { return DIAS[d.getDay()] + " " + d.getDate() + " de " + MESES[d.getMonth()]; };
  M.diasEntre = function (a, b) { return Math.round((b - a) / 864e5); };
  M.enDias = function (n) { return n === 0 ? "hoy" : n === 1 ? "mañana" : n > 1 ? "en " + n + " días" : "hace " + (-n) + (n === -1 ? " día" : " días"); };

  M.num = function (n, dec) {
    if (n == null || isNaN(n)) return "—";
    dec = dec == null ? 2 : dec;
    var neg = n < 0 && Math.round(Math.abs(n) * Math.pow(10, dec)) > 0;
    var s = Math.abs(n).toFixed(dec).split(".");
    s[0] = s[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    return (neg ? "−" : "") + s.join(",");
  };
  M.usd = function (n, dec) { if (n == null || isNaN(n)) return "—"; var t = M.num(Math.abs(n), dec); return (n < 0 && t !== M.num(0, dec) ? "−" : "") + "US$ " + t; };
  M.usdSigno = function (n) { return (n > 0 ? "+" : "") + M.usd(n); };
  M.pct = function (n, dec) { return M.num(n, dec == null ? 0 : dec) + "%"; };
  M.esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  M.clamp = function (x, a, b) { return Math.max(a, Math.min(b, x)); };

  M.esManual = function (e) { return !!e && (e.origen === "manual" || /^man-/.test(String(e.id || ""))); };
  M.ESTADOS = { evaluacion: "En evaluación", fondeada: "Fondeada", aprobada: "Aprobada", perdida: "Perdida", pausada: "Pausada" };

  M.cuenta = function (c) {
    var inicial = c.saldo_inicial != null ? c.saldo_inicial : (c.objetivo_saldo != null && c.objetivo_ganancia != null ? c.objetivo_saldo - c.objetivo_ganancia : c.saldo);
    var objSaldo = c.objetivo_saldo != null ? c.objetivo_saldo : (c.objetivo_ganancia != null ? inicial + c.objetivo_ganancia : null);
    var objGan = c.objetivo_ganancia != null ? c.objetivo_ganancia : (objSaldo != null ? objSaldo - inicial : null);
    var perdidaMax = c.piso != null ? inicial - c.piso : null;
    var margen = c.piso != null ? c.saldo - c.piso : null;
    var pctMargen = perdidaMax > 0 ? M.clamp(margen / perdidaMax, 0, 1) : null;
    var resultado = c.saldo - inicial;
    var progreso = objGan > 0 ? M.clamp(resultado / objGan, 0, 1) : 0;
    var activa = c.estado === "evaluacion" || c.estado === "fondeada" || c.estado === "aprobada" || !c.estado;
    var nivel = "ok";
    if (c.estado === "perdida" || (margen != null && margen <= 0)) nivel = "bad";
    else if (pctMargen != null && activa) nivel = pctMargen < 0.25 ? "bad" : pctMargen < 0.5 ? "warn" : "ok";
    return {
      raw: c, id: c.id, nombre: c.nombre || c.tipo || "Cuenta", tipo: c.tipo || c.nombre, login: c.id, inicial: inicial, objSaldo: objSaldo, objGan: objGan,
      perdidaMax: perdidaMax, margen: margen, pctMargen: pctMargen, resultado: resultado, progreso: progreso,
      falta: objSaldo != null ? Math.max(0, objSaldo - c.saldo) : null,
      llegoObjetivo: objSaldo != null && c.saldo >= objSaldo, activa: activa, nivel: nivel,
      retirable: c.retirable > 0 ? c.retirable : 0, estado: c.estado || "evaluacion",
      manual: M.esManual(c), nota: c.nota || "", payout: c.payout && typeof c.payout === "object" ? c.payout : null
    };
  };

  function ultimoDia(y, m) { return new Date(y, m + 1, 0).getDate(); }
  /* Próxima fecha >= hoy, siempre calculada desde la fecha ancla (sin arrastrar el corrimiento de fin de mes). */
  M.proximoPago = function (s, hoy) {
    var a = parseISO(s.proximo_pago);
    if (!a) return null;
    if (a >= hoy) return a;
    if (s.frecuencia === "semanal") return new Date(a.getFullYear(), a.getMonth(), a.getDate() + 7 * Math.ceil(M.diasEntre(a, hoy) / 7));
    var paso = FREC[s.frecuencia] || 1, dif = (hoy.getFullYear() - a.getFullYear()) * 12 + (hoy.getMonth() - a.getMonth());
    var k = Math.max(1, Math.floor(dif / paso)), guard = 0;
    function cand(n) { var t = new Date(a.getFullYear(), a.getMonth() + n * paso, 1); return new Date(t.getFullYear(), t.getMonth(), Math.min(a.getDate(), ultimoDia(t.getFullYear(), t.getMonth()))); }
    while (cand(k) < hoy && guard++ < 600) k++;
    return cand(k);
  };
  M.mensual = function (s) { return s.monto == null ? null : s.monto / (FREC[s.frecuencia] || 1); };

  function numero(x) { if (typeof x === "string" && x.trim() !== "") x = Number(x.replace(",", ".")); return typeof x === "number" && isFinite(x) ? x : null; }
  /* Descarta lo que no se puede mostrar y cuenta cuánto se descartó, para avisarlo. */
  M.normalizar = function (data) {
    var malos = 0, o = data && typeof data === "object" ? data : {};
    function lista(x) { return Array.isArray(x) ? x.filter(function (e) { return e && typeof e === "object"; }) : []; }
    var cuentas = lista(o.cuentas).map(function (c) { var n = Object.assign({}, c); n.saldo = numero(c.saldo); ["saldo_inicial", "piso", "objetivo_ganancia", "objetivo_saldo", "retirable"].forEach(function (k) { n[k] = numero(c[k]); }); n.id = String(c.id == null ? "" : c.id); return n; })
      .filter(function (c) { if (c.saldo == null) { malos++; return false; } return true; });
    var movs = lista(o.movimientos).map(function (m) { var n = Object.assign({}, m); n.monto = numero(m.monto); n.tipo = m.tipo === "cobro" ? "cobro" : "gasto"; n.id = String(m.id == null ? m.fecha + "|" + m.descripcion : m.id); n.descripcion = m.descripcion == null ? "Sin descripción" : String(m.descripcion); n.detalle = m.detalle && typeof m.detalle === "object" ? m.detalle : {}; return n; })
      .filter(function (m) { if (!parseISO(m.fecha) || m.monto == null) { malos++; return false; } m.fecha = String(m.fecha).slice(0, 10); return true; });
    var subs = lista(o.suscripciones).map(function (s) { var n = Object.assign({}, s); n.monto = numero(s.monto); n.servicio = s.servicio == null ? "" : String(s.servicio); n.id = String(s.id == null ? s.servicio : s.id); n.pausada = s.pausada === true || s.pausada === "true"; return n; })
      .filter(function (s) { if (!s.servicio) { malos++; return false; } return true; });
    var alertas = lista(o.alertas).filter(function (a) { return typeof a.texto === "string" && a.texto; }).map(function (a) { var o = { nivel: a.nivel === "bad" || a.nivel === "ok" ? a.nivel : "warn", texto: a.texto }; ["id", "codigo", "cuenta_id", "accion"].forEach(function (k) { if (a[k] != null && a[k] !== "") o[k] = String(a[k]); }); return o; });
    var diario = lista(o.diario).map(function (x) { var n = Object.assign({}, x); n.id = String(x.id == null ? "" : x.id); n.texto = x.texto == null ? "" : String(x.texto); n.etiquetas = Array.isArray(x.etiquetas) ? x.etiquetas.filter(function (e) { return typeof e === "string" && e; }).slice(0, 12) : []; return n; })
      .filter(function (x) { if (!x.id || !parseISO(x.fecha) || !x.texto) { malos++; return false; } x.fecha = String(x.fecha).slice(0, 10); return true; });
    return { generado: o.generado, cuentas: cuentas, movimientos: movs, suscripciones: subs, alertas: alertas, diario: diario, infra: o.infra && typeof o.infra === "object" ? o.infra : null, malos: malos };
  };

  M.resumen = function (data, hoy, esDemo) {
    data = M.normalizar(data);
    var cuentas = data.cuentas.map(M.cuenta);
    var movs = data.movimientos.slice().sort(function (a, b) { return a.fecha < b.fecha ? 1 : a.fecha > b.fecha ? -1 : 0; });
    var puesto = 0, cobrado = 0, cuotas = 0;
    movs.forEach(function (m) {
      if (m.tipo === "cobro") cobrado += m.monto || 0;
      else { puesto += m.monto || 0; if (m.categoria === CAT_CUENTAS) cuotas += m.monto || 0; }
    });
    var subs = (data.suscripciones || []).map(function (s) {
      var prox = M.proximoPago(s, hoy), pausada = s.pausada === true;
      return { raw: s, id: s.id, servicio: s.servicio, monto: s.monto, frecuencia: s.frecuencia || "mensual", para_que: s.para_que, prox: prox, dias: prox ? M.diasEntre(hoy, prox) : null, mensual: M.mensual(s), pausada: pausada, manual: M.esManual(s) };
    });
    var subsActivas = subs.filter(function (s) { return !s.pausada; });
    var gastoMes = 0, sinMonto = [];
    subsActivas.forEach(function (s) { if (s.mensual == null) sinMonto.push(s); else gastoMes += s.mensual; });
    var proximo = subsActivas.filter(function (s) { return s.prox; }).sort(function (a, b) { return a.prox - b.prox; })[0] || null;
    var vencimientos = subsActivas.filter(function (s) { return s.prox && s.dias >= 0 && s.dias <= 30; }).sort(function (a, b) { return a.prox - b.prox; });
    var retirable = cuentas.reduce(function (a, c) { return a + c.retirable; }, 0);

    var al = M.construirAlertas({ data: data, cuentas: cuentas, subs: subsActivas, hoy: hoy, esDemo: esDemo });
    var orden = { bad: 0, warn: 1, ok: 2 };
    al.sort(function (a, b) { return (orden[a.nivel] - orden[b.nivel]) || (a.prio - b.prio); });
    var peor = "ok";
    al.forEach(function (a) { if (orden[a.nivel] < orden[peor]) peor = a.nivel; });
    var principal = al[0] || null;
    var frase = principal && (principal.nivel !== "ok" || principal.accion) ? principal.texto : "Todo en orden. No hace falta que hagas nada.";
    var activas = cuentas.filter(function (c) { return c.activa && c.margen != null; });
    var tight = activas.slice().sort(function (a, b) { return a.pctMargen - b.pctMargen; })[0] || null;
    var enEval = cuentas.filter(function (c) { return c.estado === "evaluacion" && !c.llegoObjetivo && c.falta != null; }).sort(function (a, b) { return a.falta - b.falta; })[0] || null;
    return {
      cuentas: cuentas, movs: movs, subs: subs, puesto: puesto, cobrado: cobrado, neto: cobrado - puesto, cuotas: cuotas,
      gastoMes: gastoMes, sinMonto: sinMonto, proximo: proximo, vencimientos: vencimientos, pausadas: subs.length - subsActivas.length, retirable: retirable, alertas: al, nivel: peor, frase: frase, masAlertas: Math.max(0, al.filter(function (a) { return a.nivel !== "ok" || a.accion; }).length - 1),
      tight: tight, enEval: enEval, principal: cuentaPrincipal(cuentas, tight), diario: data.diario.slice().sort(function (a, b) { return a.fecha < b.fecha ? 1 : a.fecha > b.fecha ? -1 : String(b.ts || b.id) < String(a.ts || a.id) ? -1 : 1; }), generado: data.generado
    };
  };

  /* Cuenta que manda en "Hoy": la de evaluación activa (la que se está jugando), si no la de menos colchón. */
  function cuentaPrincipal(cuentas, tight) {
    var act = cuentas.filter(function (c) { return c.activa && c.margen != null && c.estado !== "pausada"; });
    var ev = act.filter(function (c) { return c.estado === "evaluacion" && !c.manual; })[0] || act.filter(function (c) { return c.estado === "evaluacion"; })[0];
    return ev || tight || null;
  }

  /* agrupaciones para Plata */
  M.porMes = function (movs) {
    var o = {};
    movs.forEach(function (m) {
      var k = m.fecha.slice(0, 7); o[k] = o[k] || { k: k, cobro: 0, gasto: 0 };
      o[k][m.tipo === "cobro" ? "cobro" : "gasto"] += m.monto || 0;
    });
    return Object.keys(o).sort().reverse().map(function (k) { return o[k]; });
  };
  M.porCategoria = function (movs, tipo) {
    var o = {};
    movs.filter(function (m) { return (m.tipo === "cobro") === (tipo === "cobro"); }).forEach(function (m) {
      var k = m.categoria || "Sin categoría"; o[k] = (o[k] || 0) + (m.monto || 0);
    });
    return Object.keys(o).map(function (k) { return { cat: k, total: o[k] }; }).sort(function (a, b) { return b.total - a.total; });
  };
  M.mesTxt = function (k, corto) { var p = k.split("-"); var n = MESES[+p[1] - 1]; return corto ? n.slice(0, 3) : n.charAt(0).toUpperCase() + n.slice(1) + " " + p[0]; };

  /* CSV simple: separador ; y coma decimal (abre bien en Excel y Sheets en espanol) */
  M.csv = function (movs, cuentas) {
    var nom = {}; (cuentas || []).forEach(function (c) { nom[c.id] = c.nombre; });
    function n(x) { return x == null ? "" : String(x.toFixed ? x.toFixed(2) : x).replace(".", ","); }
    function fx(s) { s = s == null ? "" : String(s); return /^[=+\-@\t\r]/.test(s) ? "'" + s : s; }
    function q(s) { s = s == null ? "" : String(s); return /[;"\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }
    var rows = [["Fecha", "Tipo", "Categoría", "Descripción", "Cuenta", "Monto USD", "Precio de lista USD", "Descuento USD", "Medio de pago", "Nota"]];
    movs.forEach(function (m) {
      var d = m.detalle || {};
      rows.push([M.fecha(m.fecha), m.tipo === "cobro" ? "Cobro" : "Gasto", fx(m.categoria), fx(m.descripcion), fx(nom[m.cuenta_id] || m.cuenta_id),
        n(m.tipo === "cobro" ? m.monto : -m.monto), n(d.precio_lista), n(d.descuento), fx(d.medio_pago), fx(d.nota)]);
    });
    return "﻿" + rows.map(function (r) { return r.map(q).join(";"); }).join("\r\n");
  };
})(window);

/* Mesa PRO - riesgo, horario de Nueva York, curva e infraestructura. Funciones puras, sin DOM ni red.
   Las usan la app y el chequeo en segundo plano (runners/check.js, armado con resources/build-runner.js).
   Si cambiás algo acá, corré `node resources/build-runner.js` y `node test/riesgo.test.js`. */
(function (g) {
  var M = g.Mesa = g.Mesa || {};
  var R = M.R = {};
  var NY = "America/New_York", AR = "America/Argentina/Buenos_Aires";

  /* Valor del punto en US$ por contrato, tamaño del tick y comisión por defecto (ida y vuelta, por contrato).
     La comisión de los micros sale de la operación real del 27/10 (−10 puntos MNQ = −20,00 y salió −21,90).
     La de los minis es una estimación: se puede cambiar en la calculadora. */
  R.INSTR = {
    MNQ: { punto: 2, tick: 0.25, com: 1.9, nombre: "Micro Nasdaq" },
    MYM: { punto: 0.5, tick: 1, com: 1.9, nombre: "Micro Dow" },
    MES: { punto: 5, tick: 0.25, com: 1.9, nombre: "Micro S&P" },
    NQ: { punto: 20, tick: 0.25, com: 4.5, nombre: "Nasdaq mini" },
    YM: { punto: 5, tick: 1, com: 4.5, nombre: "Dow mini" },
    ES: { punto: 50, tick: 0.25, com: 4.5, nombre: "S&P mini" }
  };
  R.TOPE_SCRIPTS = 1000;          /* tope de GANANCIA diaria de cada script en COHETE 50K (no limita pérdidas) */
  R.APERTURA = [9, 30];           /* 09:30 hora de Nueva York */
  R.FIN_SCRIPTS = [15, 45];       /* los scripts operan hasta las 15:45 de Nueva York */
  R.KILLZONE_ANTES = 30;          /* minutos antes de la apertura que cuentan como "previa" */
  /* Feriados de la bolsa de Nueva York (sin sesión normal). Lista corta y fija: revisarla cada año. */
  R.FERIADOS = ["2026-11-26", "2026-12-25", "2027-01-01", "2027-01-18", "2027-02-15", "2027-03-26", "2027-05-31", "2027-06-18", "2027-07-05", "2027-09-06", "2027-11-25", "2027-12-24"];
  /* Medias jornadas: la bolsa cierra 13:00 NY, los scripts terminan 12:45. Revisar las dos listas cada año (vencen fin de 2027). */
  R.MEDIAS = { "2026-11-27": [12, 45], "2026-12-24": [12, 45], "2027-11-26": [12, 45] };
  R.FERIADOS_HASTA = 2027;
  /* Vencimientos que se conocen hoy (los cambia Lucas desde la app o el archivo de datos con infra.alertas_tv). */
  R.ALERTAS_TV = [
    { id: "tv-1", nombre: "Alertas de TradingView (primer lote)", vence: "2026-12-08T22:44" },
    { id: "tv-2", nombre: "Alertas de TradingView (segundo lote)", vence: "2026-12-09T23:59" }
  ];

  function p2(n) { return (n < 10 ? "0" : "") + n; }
  function isoDia(y, m, d) { return y + "-" + p2(m) + "-" + p2(d); }

  /* ---------- zonas horarias (con Intl; en el runner puede no existir y se devuelve null) ---------- */
  var fmtCache = {};
  function partes(fecha, tz) {
    try {
      var f = fmtCache[tz] || (fmtCache[tz] = new Intl.DateTimeFormat("en-US", { timeZone: tz, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", weekday: "short" }));
      var o = {};
      f.formatToParts(fecha).forEach(function (p) { o[p.type] = p.value; });
      var dias = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
      return { y: +o.year, m: +o.month, d: +o.day, h: +o.hour % 24, mi: +o.minute, s: +o.second, dow: dias[o.weekday] };
    } catch (e) { return null; }
  }
  R.partes = partes;
  R.hayZonas = function () { var p = partes(new Date(Date.UTC(2026, 6, 1, 16)), NY); return !!p && p.h === 12; };
  /* minutos que la zona está adelantada respecto de UTC en ese instante (NY en invierno: −300) */
  function offset(fecha, tz) {
    var p = partes(fecha, tz); if (!p) return null;
    return Math.round((Date.UTC(p.y, p.m - 1, p.d, p.h, p.mi, p.s) - Math.floor(fecha.getTime() / 1000) * 1000) / 60000);
  }
  /* El instante (Date) en que en la zona tz son las h:mi del día y-m-d. Correcto en los cambios de horario. */
  R.instante = function (tz, y, m, d, h, mi) {
    var base = Date.UTC(y, m - 1, d, h, mi), t = base, i, off;
    for (i = 0; i < 3; i++) { off = offset(new Date(t), tz); if (off == null) return null; t = base - off * 60000; }
    return new Date(t);
  };
  R.horaEn = function (fecha, tz) { var p = partes(fecha, tz || AR); return p ? p2(p.h) + ":" + p2(p.mi) : "—"; };
  R.diaEn = function (fecha, tz) { var p = partes(fecha, tz || AR); return p ? isoDia(p.y, p.m, p.d) : null; };

  function esFeriado(iso) { return R.FERIADOS.indexOf(iso) > -1; }
  function habil(p) { return p.dow >= 1 && p.dow <= 5 && !esFeriado(isoDia(p.y, p.m, p.d)); }
  function sumarDias(y, m, d, n) { var t = new Date(Date.UTC(y, m - 1, d + n)); return { y: t.getUTCFullYear(), m: t.getUTCMonth() + 1, d: t.getUTCDate(), dow: t.getUTCDay() }; }

  /* Estado de la sesión de Nueva York.
     estado: "antes" (día hábil, falta más de 30 min), "previa" (30 min antes), "sesion" (09:30 a 15:45), "cerrado" (después o día no hábil).
     Devuelve también la próxima apertura y el cierre de scripts, en Date (instantes reales). */
  R.sesion = function (ahora) {
    ahora = ahora || new Date();
    var p = partes(ahora, NY); if (!p) return null;
    var hoyHabil = habil(p);
    function finDe(y, m, d) { var x = R.MEDIAS[isoDia(y, m, d)] || R.FIN_SCRIPTS; return R.instante(NY, y, m, d, x[0], x[1]); }
    var ap = R.instante(NY, p.y, p.m, p.d, R.APERTURA[0], R.APERTURA[1]), fin = finDe(p.y, p.m, p.d);
    var t = ahora.getTime(), estado, prox = ap, cierre = fin;
    if (hoyHabil && t < ap.getTime()) estado = (ap.getTime() - t) <= R.KILLZONE_ANTES * 60000 ? "previa" : "antes";
    else if (hoyHabil && t < fin.getTime()) estado = "sesion";
    else {
      estado = "cerrado";
      var q = { y: p.y, m: p.m, d: p.d }, n = 0, dd;
      do { n++; dd = sumarDias(q.y, q.m, q.d, n); } while ((dd.dow === 0 || dd.dow === 6 || esFeriado(isoDia(dd.y, dd.m, dd.d))) && n < 10);
      prox = R.instante(NY, dd.y, dd.m, dd.d, R.APERTURA[0], R.APERTURA[1]);
      cierre = finDe(dd.y, dd.m, dd.d);
    }
    var motivo = !hoyHabil ? (p.dow === 0 || p.dow === 6 ? "fin de semana" : "feriado en Nueva York") : null;
    return {
      estado: estado, motivo: motivo, apertura: prox, cierre: cierre,
      faltaMs: Math.max(0, prox.getTime() - t), transcurridoMs: estado === "sesion" ? t - ap.getTime() : 0, quedaMs: estado === "sesion" ? fin.getTime() - t : 0,
      aperturaAR: R.horaEn(prox, AR), cierreAR: R.horaEn(cierre, AR), aperturaNY: "09:30", cierreNY: R.horaEn(cierre, NY), mediaJornada: !!R.MEDIAS[R.diaEn(cierre, NY)], listaVencida: p.y > R.FERIADOS_HASTA,
      diaApertura: R.diaEn(prox, AR), offsetNY: offset(prox, NY)
    };
  };
  /* "1 h 12 min", "12 min", "45 s" */
  R.duracion = function (ms) {
    var s = Math.max(0, Math.round(ms / 1000)), h = Math.floor(s / 3600), mi = Math.floor((s % 3600) / 60);
    if (h >= 24) { var dd = Math.floor(h / 24); return dd + (dd === 1 ? " día " : " días ") + (h % 24) + " h"; }
    if (h) return h + " h " + mi + " min";
    if (mi) return mi + " min";
    return s + " s";
  };
  /* "01:12:05" para el reloj grande */
  R.reloj = function (ms) { var s = Math.max(0, Math.floor(ms / 1000)); return p2(Math.floor(s / 3600)) + ":" + p2(Math.floor((s % 3600) / 60)) + ":" + p2(s % 60); };

  /* ---------- curva diaria ---------- */
  /* Une los dos formatos: cuentas[].curva = [[fecha, saldo, piso, resultado_dia, ops_dia], ...]
     y cuentas[].historial_saldo = [{fecha, saldo}]. Un punto por día (si hay dos, queda el último).
     r = resultado del día: el que viene, o la diferencia con el cierre anterior (estimado: true). */
  R.curva = function (c) {
    var raw = c && (c.raw || c), filas = [];
    if (Array.isArray(raw.curva)) raw.curva.forEach(function (x) {
      if (Array.isArray(x)) filas.push({ fecha: x[0], saldo: x[1], piso: x[2], r: x[3], ops: x[4] });
      else if (x && typeof x === "object") filas.push({ fecha: x.fecha, saldo: x.saldo, piso: x.piso, r: x.resultado_dia != null ? x.resultado_dia : x.r, ops: x.ops_dia != null ? x.ops_dia : x.ops });
    });
    else if (Array.isArray(raw.historial_saldo)) raw.historial_saldo.forEach(function (x) { if (x && typeof x === "object") filas.push({ fecha: x.fecha, saldo: x.saldo, piso: x.piso }); });
    function n(v) { if (typeof v === "string" && v.trim() !== "") v = Number(v.replace(",", ".")); return typeof v === "number" && isFinite(v) ? v : null; }
    var porDia = {};
    filas.forEach(function (f) {
      var d = /^\d{4}-\d{2}-\d{2}/.exec(String(f.fecha || "")); if (!d) return;
      var s = n(f.saldo); if (s == null) return;
      porDia[d[0]] = { fecha: d[0], saldo: s, piso: n(f.piso), r: n(f.r), ops: n(f.ops), estimado: false };
    });
    var l = Object.keys(porDia).sort().map(function (k) { return porDia[k]; });
    var ini = n(raw.saldo_inicial);
    l.forEach(function (p, i) {
      if (p.r == null) { var prev = i ? l[i - 1].saldo : null; if (prev != null) { p.r = Math.round((p.saldo - prev) * 100) / 100; p.estimado = true; } }
    });
    if (l.length && l[0].r == null && ini != null && l[0].saldo !== ini) { l[0].r = Math.round((l[0].saldo - ini) * 100) / 100; l[0].estimado = true; }
    var max = ini != null ? ini : -Infinity;
    l.forEach(function (p) { max = Math.max(max, p.saldo); p.max = max; p.dd = Math.round((p.saldo - max) * 100) / 100; });
    return l;
  };
  /* Mejor día (ganancia) de la curva: {fecha, r, estimado} o null */
  R.mejorDia = function (curva) {
    var b = null;
    (curva || []).forEach(function (p) { if (p.r != null && p.r > 0 && (!b || p.r > b.r)) b = p; });
    return b ? { fecha: b.fecha, r: b.r, estimado: b.estimado } : null;
  };
  R.ddMax = function (curva) { var m = 0; (curva || []).forEach(function (p) { if (p.dd < m) m = p.dd; }); return m; };

  /* ---------- cuánto puedo perder hoy ---------- */
  /* Solo manda el margen hasta el piso (pérdida máxima con arrastre, cuenta lo abierto). Flex no tiene límite de pérdida diaria
     y el tope de 1.000 de los scripts es de GANANCIA, así que no recorta la pérdida. El 2º parámetro se ignora (compatibilidad). */
  R.puedoPerder = function (c) {
    if (!c || c.margen == null) return null;
    var margen = Math.max(0, c.margen), manda = margen <= 0 ? "perdida" : "piso";
    var texto = manda === "perdida" ? "Ya tocaste el piso: la cuenta no tiene margen." :
      "Es todo el margen hasta el piso: si las pérdidas del día (también las de posiciones abiertas) llegan a " + M.usd(margen) + ", se pierde la cuenta. La firma no tiene límite de pérdida diaria aparte y el tope de " + M.usd(R.TOPE_SCRIPTS, 0) + " de los scripts es de ganancia, no frena pérdidas.";
    return { valor: margen, margen: margen, tope: null, manda: manda, texto: texto, pct: null };
  };

  /* ---------- cuánto puedo ganar hoy sin romper la consistencia ---------- */
  /* Regla: ningún día puede pasar el pct% (40) de la ganancia total al momento de aprobar/retirar.
     G = ganancia acumulada, b = mejor día hasta ahora, O = objetivo de ganancia.
     Si hoy ganás g, al aprobar el total es al menos max(O, G+g) y el mejor día max(b, g).
     Techo de hoy = max(pct·O, g*) con g* = pct/(1−pct)·G (con 40%: 2/3 de lo ganado). */
  R.puedoGanar = function (c, curva) {
    if (!c) return null;
    var raw = c.raw || {}, pct = (raw.consistencia_max_pct != null ? +raw.consistencia_max_pct : 40) / 100;
    if (!(pct > 0 && pct < 1)) pct = 0.4;
    var G = Math.round((c.resultado || 0) * 100) / 100, O = c.objGan > 0 ? c.objGan : null;
    var md = R.mejorDia(curva), b = md ? md.r : null, fuente = md ? (md.estimado ? "estimado con los cierres diarios" : "de la curva diaria") : null;
    if (b == null && raw.mejor_dia_pct != null && G > 0) { b = Math.round(G * raw.mejor_dia_pct) / 100; fuente = "del porcentaje que informa la firma"; }
    var porGanado = G > 0 ? pct / (1 - pct) * G : 0, porObjetivo = O ? pct * O : 0;
    var techo = Math.max(porGanado, porObjetivo);
    var actual = G > 0 && b != null ? b / G : null;
    var manda = porObjetivo >= porGanado ? "objetivo" : "ganado";
    var texto = manda === "objetivo" && O ? "Con la regla del " + Math.round(pct * 100) + "%, un día de hasta " + M.usd(techo) + " (el " + Math.round(pct * 100) + "% del objetivo de " + M.usd(O, 0) + ") no te traba al aprobar." :
      "Llevás " + M.usd(G) + " ganados: un día de hasta " + M.usd(techo) + " sigue siendo como mucho el " + Math.round(pct * 100) + "% del total.";
    texto += " Cada script corta solo al llegar a " + M.usd(R.TOPE_SCRIPTS, 0) + " de ganancia en el día.";
    return { techo: Math.round(techo * 100) / 100, G: G, b: b, fuenteB: fuente, pct: pct, actual: actual, cumple: actual == null ? null : actual <= pct + 1e-9, manda: manda, texto: texto,
      necesario: b != null && b > 0 ? Math.round(b / pct * 100) / 100 : null };
  };

  /* ---------- calculadora de tamaño ---------- */
  /* o: { instr, stop (puntos), riesgo (US$), com (opcional) } */
  R.tamano = function (o) {
    var ins = R.INSTR[o.instr] || R.INSTR.MNQ, stop = +o.stop, riesgo = +o.riesgo, com = o.com != null && o.com !== "" && isFinite(+o.com) ? +o.com : ins.com;
    if (!(stop > 0) || !(riesgo > 0)) return { ok: false, motivo: !(stop > 0) ? "Poné la distancia al stop en puntos." : "Poné cuánto querés arriesgar." };
    var porContrato = stop * ins.punto + com, n = Math.floor(riesgo / porContrato + 1e-9);
    return { ok: true, contratos: n, porContrato: Math.round(porContrato * 100) / 100, perdida: Math.round(n * porContrato * 100) / 100, ticks: Math.round(stop / ins.tick),
      objetivo2: stop * 2, ganancia2: Math.round((n * stop * 2 * ins.punto - n * com) * 100) / 100, com: com, punto: ins.punto };
  };

  /* ---------- infraestructura ---------- */
  var LETRA = { 3: "H", 6: "M", 9: "U", 12: "Z" }, MES_C = { 3: "Mar", 6: "Jun", 9: "Sep", 12: "Dic" };
  function tercerViernes(y, m) { var d1 = new Date(Date.UTC(y, m - 1, 1)).getUTCDay(), primero = 1 + ((5 - d1 + 7) % 7); return primero + 14; }
  /* Contrato trimestral vigente: vence el tercer viernes de mar/jun/sep/dic; el cambio (roll) se hace ~8 días antes (jueves). */
  R.contrato = function (hoyISO) {
    var y = +hoyISO.slice(0, 4), m = +hoyISO.slice(5, 7), i, cand = [];
    for (i = 0; i < 6; i++) { var mm = 3 * Math.ceil(m / 3) + 3 * i, yy = y + Math.floor((mm - 1) / 12); mm = ((mm - 1) % 12) + 1; cand.push({ y: yy, m: mm }); }
    function info(q) {
      var vto = isoDia(q.y, q.m, tercerViernes(q.y, q.m)), r = sumarDias(q.y, q.m, tercerViernes(q.y, q.m), -8), r0 = sumarDias(q.y, q.m, tercerViernes(q.y, q.m), -9);
      return { codigo: LETRA[q.m] + String(q.y).slice(2), nombre: MES_C[q.m] + " " + String(q.y).slice(2), vence: vto, roll: isoDia(r.y, r.m, r.d), rollDesde: isoDia(r0.y, r0.m, r0.d) };
    }
    for (i = 0; i < cand.length; i++) { var a = info(cand[i]); if (hoyISO <= a.roll) return { vigente: a, siguiente: info(cand[i + 1]) }; }
    return null;
  };
  function diasHasta(desdeISO, hastaISO) { return Math.round((Date.UTC(+hastaISO.slice(0, 4), +hastaISO.slice(5, 7) - 1, +hastaISO.slice(8, 10)) - Date.UTC(+desdeISO.slice(0, 4), +desdeISO.slice(5, 7) - 1, +desdeISO.slice(8, 10))) / 864e5); }
  R.diasHasta = diasHasta;
  /* Lista de ítems {id, titulo, valor, detalle, nivel, dias}. o: { hoy: "AAAA-MM-DD", alertasTv, recordatorios: {activos, proximos}, generado, ahora } */
  R.infra = function (o) {
    var hoy = o.hoy, items = [], c = R.contrato(hoy);
    if (c) {
      var dr = diasHasta(hoy, c.vigente.roll);
      items.push({ id: "contrato", titulo: "Contrato vigente", valor: c.vigente.nombre + " (" + c.vigente.codigo + ")", dias: dr,
        detalle: "Vence el " + M.fecha(c.vigente.vence) + ". El cambio al " + c.siguiente.nombre + " (" + c.siguiente.codigo + ") se hace el " + M.fecha(c.vigente.rollDesde).slice(0, 5) + "–" + M.fecha(c.vigente.roll).slice(0, 5) + (dr >= 0 ? " (" + M.enDias(dr) + ")." : "."),
        nivel: dr <= 3 ? "bad" : dr <= 14 ? "warn" : "ok" });
    }
    (o.alertasTv && o.alertasTv.length ? o.alertasTv : R.ALERTAS_TV).forEach(function (a) {
      var dia = String(a.vence || "").slice(0, 10); if (!/^\d{4}-\d{2}-\d{2}$/.test(dia)) return;
      var d = diasHasta(hoy, dia), hora = String(a.vence).slice(11, 16);
      items.push({ id: "tv|" + (a.id || dia), titulo: a.nombre || "Alertas de TradingView", valor: d < 0 ? "Vencidas" : "Vencen " + M.enDias(d), dias: d,
        detalle: "El " + M.fecha(dia) + (hora && hora !== "23:59" ? " a las " + hora : "") + ". Renovalas antes desde TradingView.", nivel: d < 0 || d <= 2 ? "bad" : d <= 10 ? "warn" : "ok" });
    });
    var sc = c && diasHasta(hoy, "2026-12-07");
    if (c && sc != null && sc >= 0 && sc <= 10) items.push({ id: "semana", titulo: "Semana crítica 7 al 11/12", valor: "Empieza " + M.enDias(sc), dias: sc, detalle: "Se juntan el vencimiento de las alertas y el cambio de contrato. Dejá todo listo antes.", nivel: "warn" });
    if (o.recordatorios) {
      var r = o.recordatorios;
      items.push({ id: "rec", titulo: "Recordatorios de pagos", valor: r.activos ? "Programados" : "Apagados", detalle: r.proximos ? r.proximos + (r.proximos === 1 ? " pago" : " pagos") + " en los próximos 7 días." : "Ningún pago en los próximos 7 días.", nivel: r.activos ? "ok" : "warn" });
    }
    if (o.generado) {
      var horas = (o.ahora - new Date(o.generado).getTime()) / 36e5;
      if (isFinite(horas)) items.push({ id: "datos", titulo: "Datos del contador", valor: horas < 1 ? "Recién" : horas < 48 ? "Hace " + Math.round(horas) + " h" : "Hace " + Math.round(horas / 24) + " días", detalle: "Corte de datos: " + M.fecha(String(o.generado).slice(0, 10)) + " " + String(o.generado).slice(11, 16) + ".", nivel: horas > 48 ? "bad" : horas > 26 ? "warn" : "ok" });
    }
    return items;
  };
})(typeof window !== "undefined" ? window : this);

/* Mesa PRO - reglas de alertas. Funciones puras, sin DOM.
   Las usan la app (js/app.js) y el chequeo en segundo plano (runners/check.js, que se arma con resources/build-runner.js
   pegando calc.js + este archivo). Si cambiás una regla acá, corré `node resources/build-runner.js`. */
(function (g) {
  var M = g.Mesa = g.Mesa || {};

  /* Categorías que se pueden prender o apagar en Ajustes */
  M.CATS_AVISO = [
    { id: "retiro", t: "Retiros", d: "Listo para retirar, muy cerca de retirar o retiro frenado por algo que se arregla." },
    { id: "riesgo", t: "Riesgo de la cuenta", d: "Poco margen para perder o cuenta perdida." },
    { id: "objetivo", t: "Objetivo alcanzado", d: "Llegaste al objetivo o estás por llegar." },
    { id: "pagos", t: "Pagos que vencen", d: "3 días antes, el día anterior y el mismo día." },
    { id: "datos", t: "Datos desactualizados", d: "Hace más de 2 días que no se actualizan." },
    { id: "infra", t: "Infraestructura", d: "Vencimiento de las alertas de TradingView y cambio de contrato (3 días antes)." },
    { id: "servidor", t: "Avisos del contador", d: "Avisos importantes que deja el proceso automático." }
  ];
  var CAT_POR_CODIGO = { listo_retiro: "retiro", retiro_bloqueado: "retiro", retiro_cerca: "retiro", margen_bajo: "riesgo", cuenta_perdida: "riesgo", objetivo: "objetivo", datos_viejos: "datos", pago: "pagos" };

  /* número entero positivo estable (sirve de id de notificación y de clave corta) */
  M.hash = function (s) { s = String(s); var h = 7; for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 2000000000; return h + 1; };

  function cap(s) { s = String(s || ""); return s.charAt(0).toUpperCase() + s.slice(1); }
  function unir(a, b) { a = String(a || "").trim(); b = String(b || "").trim(); if (!b || a.indexOf(b) > -1) return a; return a + (/[.!?]$/.test(a) ? " " : ". ") + b; }

  /* Texto de un aviso de pago a "dias" días del vencimiento (0 = hoy). etapa: 0 hoy, 1 mañana, 3 faltan 2 o 3 días. */
  M.pagoAviso = function (s, dias) {
    var cuando = dias === 0 ? "hoy" : dias === 1 ? "mañana" : "en " + dias + " días";
    return { etapa: dias === 0 ? 0 : dias === 1 ? 1 : 3,
      titulo: dias === 0 ? "Hoy se paga " + s.servicio : dias === 1 ? "Mañana se paga " + s.servicio : "Se viene un pago",
      texto: s.servicio + (s.monto != null ? " (" + M.usd(s.monto) + ")" : "") + " vence " + cuando + ", el " + M.fecha(s.prox) + ". Dejá saldo disponible en la tarjeta." };
  };

  /* ctx: { data (normalizado), cuentas (M.cuenta), subs (solo activas, con prox y dias), hoy, esDemo } */
  M.construirAlertas = function (ctx) {
    var data = ctx.data, cuentas = ctx.cuentas, subs = ctx.subs, hoy = ctx.hoy, esDemo = ctx.esDemo;
    var al = [], claves = {};
    function add(a) { if (a.key && claves[a.key]) return; if (a.key) claves[a.key] = 1; if (a.notif == null) a.notif = true; al.push(a); }

    if (!cuentas.length) add({ key: "vacio", cat: "datos", nivel: "warn", titulo: "Sin cuentas", texto: "Todavía no hay cuentas cargadas. Revisá que el archivo de Drive se esté actualizando.", prio: 0, notif: false });
    if (data.malos) add({ key: "malos", cat: "datos", nivel: "warn", titulo: "Datos mal formados", texto: "Se ignoraron " + data.malos + (data.malos === 1 ? " dato mal formado" : " datos mal formados") + " del archivo. Revisá el proceso que lo genera.", prio: 6, notif: false });

    /* por cuenta */
    cuentas.forEach(function (c) {
      var n = c.nombre, p = c.payout, id = c.id;
      if (c.estado === "perdida") add({ key: "riesgo|" + id + "|perdida", cat: "riesgo", nivel: "bad", titulo: "Cuenta perdida", texto: n + " está perdida. Revisá en FundedNext si podés reiniciarla.", prio: 1 });
      else if (c.activa && c.nivel === "bad") add({ key: "riesgo|" + id + "|bad", cat: "riesgo", nivel: "bad", titulo: "Hacé esto ahora", texto: "Te quedan " + M.usd(Math.max(0, c.margen)) + " antes de perder " + n + ". Cerrá las posiciones y no operes más hoy.", prio: 1 });
      else if (c.activa && c.nivel === "warn") add({ key: "riesgo|" + id + "|warn", cat: "riesgo", nivel: "warn", titulo: "Poco margen", texto: "Te quedan " + M.usd(c.margen) + " en " + n + ". Operá con menos contratos hasta recuperar colchón.", prio: 2 });

      var elegible = p && p.elegible === true;
      if (c.retirable > 0 || elegible) {
        var monto = c.retirable > 0 ? c.retirable : (p && p.max_retiro > 0 ? p.max_retiro : null);
        add({ key: "retiro|" + id, cat: "retiro", nivel: "ok", accion: true, titulo: "Listo para retirar", prio: 3,
          texto: monto != null ? "Podés retirar " + M.usd(monto) + " de " + n + ". Pedí el retiro en FundedNext." : "Ya cumpliste las condiciones de retiro de " + n + ". Pedí el retiro en FundedNext." });
      } else if (p && p.bloqueo) {
        add({ key: "bloqueo|" + id + "|" + M.hash(p.bloqueo), cat: "retiro", nivel: "warn", titulo: "Retiro frenado, tiene arreglo", prio: 3,
          texto: "El retiro de " + n + " está frenado: " + String(p.bloqueo).replace(/[.\s]+$/, "") + ". " + (p.solucion ? cap(String(p.solucion).replace(/[.\s]+$/, "")) + "." : "Revisalo en FundedNext.") });
      } else if (c.activa && c.estado !== "evaluacion") {
        var faltaDia = p && p.dias_req >= 2 && p.dias_ok != null && p.dias_ok >= p.dias_req - 1 && p.dias_ok < p.dias_req;
        var casi = c.objGan > 0 && c.resultado >= 0.85 * c.objGan && !c.llegoObjetivo;
        if (faltaDia || casi) add({ key: "cerca|" + id, cat: "retiro", nivel: "ok", titulo: "Muy cerca de retirar", prio: 5,
          texto: faltaDia ? "Te falta " + (p.dias_req - p.dias_ok) + " día de payout en " + n + " (" + p.dias_ok + " de " + p.dias_req + "). Operá con cuidado y no rompas la regla de consistencia."
            : "Llevás el " + M.pct(c.resultado / c.objGan * 100, 0) + " del objetivo de " + n + ": faltan " + M.usd(c.falta) + ". Cuidá el colchón y no fuerces operaciones." });
      }
      if (c.estado === "evaluacion" && c.llegoObjetivo) add({ key: "objetivo|" + id, cat: "objetivo", nivel: "ok", accion: true, titulo: "Objetivo alcanzado", prio: 3, texto: "Llegaste al objetivo de " + n + ". Pedí la aprobación en FundedNext." });
      else if (c.estado === "evaluacion" && c.activa && c.objGan > 0 && c.resultado >= 0.85 * c.objGan && c.nivel !== "bad") add({ key: "cerca|" + id, cat: "objetivo", nivel: "ok", titulo: "Muy cerca de aprobar", prio: 5, texto: "Llevás el " + M.pct(c.resultado / c.objGan * 100, 0) + " del objetivo de " + n + ": faltan " + M.usd(c.falta) + ". Cuidá el colchón y no fuerces operaciones." });
    });

    /* avisos que deja el proceso automático (el contador) */
    (data.alertas || []).forEach(function (a) {
      var cod = a.codigo || "", cat = CAT_POR_CODIGO[cod] || "servidor";
      if (cod === "listo_retiro" && a.cuenta_id && claves["retiro|" + a.cuenta_id]) return;
      if (cod === "retiro_bloqueado" && a.cuenta_id && al.some(function (x) { return x.key.indexOf("bloqueo|" + a.cuenta_id + "|") === 0; })) return;
      var ok = a.nivel === "ok", importante = a.nivel !== "ok" || cod === "listo_retiro";
      add({ key: "srv|" + (a.id || M.hash(a.texto)), cat: cat, nivel: a.nivel, accion: cod === "listo_retiro" || undefined, notif: importante,
        titulo: cod === "listo_retiro" ? "Listo para retirar" : cod === "retiro_bloqueado" ? "Retiro frenado, tiene arreglo" : a.nivel === "bad" ? "Mesa PRO: hacé esto ahora" : ok ? "Mesa PRO" : "Mesa PRO: mirá esto",
        texto: unir(a.texto, a.accion), prio: 5 });
    });

    /* pagos (solo suscripciones activas) */
    subs.forEach(function (s) {
      if (s.dias == null || s.dias < 0 || s.dias > 3) return;
      var pa = M.pagoAviso(s, s.dias);
      add({ key: "pago|" + s.id + "|" + M.iso(s.prox) + "|" + pa.etapa, cat: "pagos", nivel: "warn", titulo: pa.titulo, texto: pa.texto, prio: 4 });
    });

    /* infraestructura (calculada en el celular con riesgo.js): alertas de TradingView y cambio de contrato a 3 días o menos */
    if (M.R && M.R.infra) {
      var tv = data.infra && Array.isArray(data.infra.alertas_tv) ? data.infra.alertas_tv : null;
      M.R.infra({ hoy: M.iso(hoy), alertasTv: tv }).forEach(function (it) {
        if ((it.id !== "contrato" && it.id.indexOf("tv|") !== 0) || it.dias == null || it.dias < 0 || it.dias > 3) return;
        add({ key: "infra|" + it.id + "|" + it.dias, cat: "infra", nivel: "warn", prio: 4,
          titulo: it.id === "contrato" ? "Se viene el cambio de contrato" : "Vencen alertas de TradingView",
          texto: it.id === "contrato" ? it.valor + ": " + it.detalle : it.titulo + " " + it.valor.toLowerCase() + ". " + it.detalle });
      });
    }

    if (!esDemo && data.generado) {
      var gen = new Date(data.generado);
      if (!isNaN(gen) && (Date.now() - gen.getTime()) > 48 * 36e5) add({ key: "datos|" + M.iso(gen), cat: "datos", nivel: "warn", titulo: "Datos viejos", prio: 4, texto: "Los datos tienen más de dos días. Revisá que el proceso automático de Drive siga andando." });
    }
    return al;
  };

  /* Decide qué alertas son nuevas (para notificar una sola vez).
     alertas: las de construirAlertas; previo: { clave: "AAAA-MM-DD" } ya notificadas; prefs: { categoria: false } apaga una categoría.
     opt.sinPagos: no notificar pagos (los cubren los recordatorios programados).
     Devuelve { nuevas: [{ id, key, titulo, texto, nivel }], mapa } donde mapa es el nuevo "ya avisadas" (solo lo que sigue vigente). */
  M.alertasNuevas = function (alertas, previo, hoyISO, prefs, opt) {
    prefs = prefs || {}; opt = opt || {}; previo = previo || {};
    var nuevas = [], mapa = {};
    alertas.forEach(function (a) {
      if (!a.notif || prefs[a.cat] === false) return;
      if (opt.sinPagos && a.cat === "pagos") return;
      if (opt.frenado && a.nivel !== "bad") return; /* "Frenar por hoy": solo pasan los críticos */
      if (previo[a.key]) { mapa[a.key] = previo[a.key]; return; }
      mapa[a.key] = hoyISO;
      nuevas.push({ id: M.hash(a.key), key: a.key, titulo: a.titulo, texto: a.texto, nivel: a.nivel, cat: a.cat });
    });
    return { nuevas: nuevas, mapa: mapa };
  };
})(typeof window !== "undefined" ? window : this);

/* ---- Chequeo en segundo plano de Mesa PRO (@capacitor/background-runner) ----
   Entorno restringido: sin DOM, sin async/await obligatorio; hay fetch, CapacitorKV y CapacitorNotifications.
   Eventos: check (lo dispara Android cada ~30 min), config (la app deja URL, clave y preferencias),
   estado (la app pregunta qué se avisó y cuándo corrió), marcar (la app dice qué ya avisó ella). */
var KV_CFG = "cfg", KV_AVISADAS = "notificadas", KV_ULTIMA = "ultima", KV_ERROR = "error";

function kvGet(k) { try { var r = CapacitorKV.get(k); return r && r.value != null ? r.value : null; } catch (e) { return null; } }
function kvSet(k, v) { try { CapacitorKV.set(k, v); } catch (e) {} }
function kvJSON(k, def) { try { var t = kvGet(k); var o = t ? JSON.parse(t) : null; return o && typeof o === "object" ? o : def; } catch (e) { return def; } }

addEventListener("config", function (resolve, reject, args) {
  try {
    var a = args || {};
    kvSet(KV_CFG, JSON.stringify({ url: String(a.url || ""), clave: String(a.clave || ""), prefs: a.prefs && typeof a.prefs === "object" ? a.prefs : {}, recordatorios: a.recordatorios === true, frenado: typeof a.frenado === "string" ? a.frenado : null }));
    resolve({ ok: true });
  } catch (e) { resolve({ ok: false }); }
});

addEventListener("marcar", function (resolve, reject, args) {
  try { if (args && args.mapa && typeof args.mapa === "object") kvSet(KV_AVISADAS, JSON.stringify(args.mapa)); } catch (e) {}
  resolve({ ok: true });
});

addEventListener("estado", function (resolve) {
  var cfg = kvJSON(KV_CFG, {});
  resolve({ notificadas: kvJSON(KV_AVISADAS, {}), ultima: kvGet(KV_ULTIMA), error: kvGet(KV_ERROR), configurado: !!(cfg.url && cfg.clave) });
});

/* GET con respaldo: el fetch del runner normalmente sigue el 302 de Apps Script solo; si no lo hiciera y se puede leer "Location", lo sigue a mano. */
function traer(url, n) {
  return fetch(url).then(function (r) {
    var st = r && r.status;
    if ((st === 301 || st === 302 || st === 303 || st === 307 || st === 308) && n < 3) {
      var loc = null;
      try { var h = r.headers; loc = h && (typeof h.get === "function" ? (h.get("location") || h.get("Location")) : (h.location || h.Location)); } catch (e) {}
      if (loc) return traer(String(loc), n + 1);
      throw new Error("redirect_sin_location");
    }
    return r.json();
  });
}

function chequear() {
  var cfg = kvJSON(KV_CFG, {});
  if (!cfg.url || !cfg.clave) return Promise.resolve({ ok: false, motivo: "sin_config" });
  var url = cfg.url + (cfg.url.indexOf("?") > -1 ? "&" : "?") + "k=" + encodeURIComponent(cfg.clave);
  return traer(url, 0).then(function (j) {
    if (!j || j.ok === false || !Array.isArray(j.cuentas)) throw new Error(j && j.error ? String(j.error) : "formato");
    var hoy = Mesa.hoy();
    var r = Mesa.resumen(j, hoy, false);
    var out = Mesa.alertasNuevas(r.alertas, kvJSON(KV_AVISADAS, {}), Mesa.iso(hoy), cfg.prefs || {}, { sinPagos: cfg.recordatorios === true, frenado: cfg.frenado === Mesa.iso(hoy) });
    if (out.nuevas.length) CapacitorNotifications.schedule(out.nuevas.map(function (n) { return { id: n.id, title: n.titulo, body: n.texto }; }));
    kvSet(KV_AVISADAS, JSON.stringify(out.mapa));
    kvSet(KV_ULTIMA, new Date().toISOString()); kvSet(KV_ERROR, "");
    return { ok: true, nuevas: out.nuevas.length };
  });
}

addEventListener("check", function (resolve) {
  chequear().then(function (r) { resolve(r); }, function (e) {
    kvSet(KV_ERROR, String((e && e.message) || e).replace(/([?&]k=)[^&\s"']*/g, "$1***").slice(0, 120));
    resolve({ ok: false, motivo: "error" });
  });
});
