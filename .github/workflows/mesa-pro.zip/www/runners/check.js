/* ARCHIVO GENERADO por resources/build-runner.js. No lo edites: cambiá www/js/calc.js, www/js/alertas.js o resources/runner-body.js y volvé a correr el script. */
var window = (typeof globalThis !== "undefined") ? globalThis : this;
/* Mesa PRO - formato y cuentas. Sin dependencias. */
(function (g) {
  var M = g.Mesa = g.Mesa || {};
  var CAT_CUENTAS = "Cuentas de fondeo";
  var MESES = ["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];
  var DIAS = ["domingo","lunes","martes","miércoles","jueves","viernes","sábado"];
  var FREC = { semanal: 12 / 52, mensual: 1, bimestral: 2, trimestral: 3, semestral: 6, anual: 12 };
  var FREC_TXT = { semanal: "por semana", mensual: "por mes", bimestral: "cada 2 meses", trimestral: "cada 3 meses", semestral: "cada 6 meses", anual: "por año" };
  M.CAT_CUENTAS = CAT_CUENTAS; M.MESES = MESES; M.FREC_TXT = FREC_TXT;

  function parseISO(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || "");
    return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
  }
  function iso(d) { return d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate()); }
  function p2(n) { return (n < 10 ? "0" : "") + n; }
  M.parseISO = parseISO; M.iso = iso;
  M.hoy = function () {
    var q = null;
    try { if (!(g.Capacitor && g.Capacitor.isNativePlatform && g.Capacitor.isNativePlatform())) q = new URLSearchParams(location.search).get("hoy"); } catch (e) {}
    var d = q ? parseISO(q) : null;
    if (d) return d;
    var n = new Date(); return new Date(n.getFullYear(), n.getMonth(), n.getDate());
  };
  M.fecha = function (s) { var d = typeof s === "string" ? parseISO(s) : s; return d ? p2(d.getDate()) + "/" + p2(d.getMonth() + 1) + "/" + d.getFullYear() : "—"; };
  M.fechaCorta = function (s) { var d = parseISO(s); if (!d) return "—"; return d.getDate() + " " + MESES[d.getMonth()].slice(0, 3) + (d.getFullYear() !== M.hoy().getFullYear() ? " " + d.getFullYear() : ""); };
  M.fechaLarga = function (d) { return DIAS[d.getDay()] + " " + d.getDate() + " de " + MESES[d.getMonth()]; };
  M.diasEntre = function (a, b) { return Math.round((b - a) / 864e5); };
  M.enDias = function (n) { return n === 0 ? "hoy" : n === 1 ? "mañana" : n > 1 ? "en " + n + " días" : "hace " + (-n) + (n === -1 ? " día" : " días"); };

  M.num = function (n, dec) {
    if (n == null || isNaN(n)) return "—";
    dec = dec == null ? 2 : dec;
    var neg = n < 0 && Math.round(Math.abs(n) * Math.pow(10, dec)) > 0;
    var s = Math.abs(n).toFixed(dec).split(".");
    s[0] = s[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    return (neg ? "−" : "") + s.join(",");
  };
  M.usd = function (n, dec) { if (n == null || isNaN(n)) return "—"; var t = M.num(Math.abs(n), dec); return (n < 0 && t !== M.num(0, dec) ? "−" : "") + "US$ " + t; };
  M.usdSigno = function (n) { return (n > 0 ? "+" : "") + M.usd(n); };
  M.pct = function (n, dec) { return M.num(n, dec == null ? 0 : dec) + "%"; };
  M.esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  M.clamp = function (x, a, b) { return Math.max(a, Math.min(b, x)); };

  M.esManual = function (e) { return !!e && (e.origen === "manual" || /^man-/.test(String(e.id || ""))); };
  M.ESTADOS = { evaluacion: "En evaluación", fondeada: "Fondeada", aprobada: "Aprobada", perdida: "Perdida", pausada: "Pausada" };

  M.cuenta = function (c) {
    var inicial = c.saldo_inicial != null ? c.saldo_inicial : (c.objetivo_saldo != null && c.objetivo_ganancia != null ? c.objetivo_saldo - c.objetivo_ganancia : c.saldo);
    var objSaldo = c.objetivo_saldo != null ? c.objetivo_saldo : (c.objetivo_ganancia != null ? inicial + c.objetivo_ganancia : null);
    var objGan = c.objetivo_ganancia != null ? c.objetivo_ganancia : (objSaldo != null ? objSaldo - inicial : null);
    var perdidaMax = c.piso != null ? inicial - c.piso : null;
    var margen = c.piso != null ? c.saldo - c.piso : null;
    var pctMargen = perdidaMax > 0 ? M.clamp(margen / perdidaMax, 0, 1) : null;
    var resultado = c.saldo - inicial;
    var progreso = objGan > 0 ? M.clamp(resultado / objGan, 0, 1) : 0;
    var activa = c.estado === "evaluacion" || c.estado === "fondeada" || c.estado === "aprobada" || !c.estado;
    var nivel = "ok";
    if (c.estado === "perdida" || (margen != null && margen <= 0)) nivel = "bad";
    else if (pctMargen != null && activa) nivel = pctMargen < 0.25 ? "bad" : pctMargen < 0.5 ? "warn" : "ok";
    return {
      raw: c, id: c.id, nombre: c.nombre || c.tipo || "Cuenta", tipo: c.tipo || c.nombre, login: c.id, inicial: inicial, objSaldo: objSaldo, objGan: objGan,
      perdidaMax: perdidaMax, margen: margen, pctMargen: pctMargen, resultado: resultado, progreso: progreso,
      falta: objSaldo != null ? Math.max(0, objSaldo - c.saldo) : null,
      llegoObjetivo: objSaldo != null && c.saldo >= objSaldo, activa: activa, nivel: nivel,
      retirable: c.retirable > 0 ? c.retirable : 0, estado: c.estado || "evaluacion",
      manual: M.esManual(c), nota: c.nota || "", payout: c.payout && typeof c.payout === "object" ? c.payout : null
    };
  };

  function ultimoDia(y, m) { return new Date(y, m + 1, 0).getDate(); }
  /* Próxima fecha >= hoy, siempre calculada desde la fecha ancla (sin arrastrar el corrimiento de fin de mes). */
  M.proximoPago = function (s, hoy) {
    var a = parseISO(s.proximo_pago);
    if (!a) return null;
    if (a >= hoy) return a;
    if (s.frecuencia === "semanal") return new Date(a.getFullYear(), a.getMonth(), a.getDate() + 7 * Math.ceil(M.diasEntre(a, hoy) / 7));
    var paso = FREC[s.frecuencia] || 1, dif = (hoy.getFullYear() - a.getFullYear()) * 12 + (hoy.getMonth() - a.getMonth());
    var k = Math.max(1, Math.floor(dif / paso)), guard = 0;
    function cand(n) { var t = new Date(a.getFullYear(), a.getMonth() + n * paso, 1); return new Date(t.getFullYear(), t.getMonth(), Math.min(a.getDate(), ultimoDia(t.getFullYear(), t.getMonth()))); }
    while (cand(k) < hoy && guard++ < 600) k++;
    return cand(k);
  };
  M.mensual = function (s) { return s.monto == null ? null : s.monto / (FREC[s.frecuencia] || 1); };

  function numero(x) { if (typeof x === "string" && x.trim() !== "") x = Number(x.replace(",", ".")); return typeof x === "number" && isFinite(x) ? x : null; }
  /* Descarta lo que no se puede mostrar y cuenta cuánto se descartó, para avisarlo. */
  M.normalizar = function (data) {
    var malos = 0, o = data && typeof data === "object" ? data : {};
    function lista(x) { return Array.isArray(x) ? x.filter(function (e) { return e && typeof e === "object"; }) : []; }
    var cuentas = lista(o.cuentas).map(function (c) { var n = Object.assign({}, c); n.saldo = numero(c.saldo); ["saldo_inicial", "piso", "objetivo_ganancia", "objetivo_saldo", "retirable"].forEach(function (k) { n[k] = numero(c[k]); }); n.id = String(c.id == null ? "" : c.id); return n; })
      .filter(function (c) { if (c.saldo == null) { malos++; return false; } return true; });
    var movs = lista(o.movimientos).map(function (m) { var n = Object.assign({}, m); n.monto = numero(m.monto); n.tipo = m.tipo === "cobro" ? "cobro" : "gasto"; n.id = String(m.id == null ? m.fecha + "|" + m.descripcion : m.id); n.descripcion = m.descripcion == null ? "Sin descripción" : String(m.descripcion); n.detalle = m.detalle && typeof m.detalle === "object" ? m.detalle : {}; return n; })
      .filter(function (m) { if (!parseISO(m.fecha) || m.monto == null) { malos++; return false; } m.fecha = String(m.fecha).slice(0, 10); return true; });
    var subs = lista(o.suscripciones).map(function (s) { var n = Object.assign({}, s); n.monto = numero(s.monto); n.servicio = s.servicio == null ? "" : String(s.servicio); n.id = String(s.id == null ? s.servicio : s.id); n.pausada = s.pausada === true || s.pausada === "true"; return n; })
      .filter(function (s) { if (!s.servicio) { malos++; return false; } return true; });
    var alertas = lista(o.alertas).filter(function (a) { return typeof a.texto === "string" && a.texto; }).map(function (a) { var o = { nivel: a.nivel === "bad" || a.nivel === "ok" ? a.nivel : "warn", texto: a.texto }; ["id", "codigo", "cuenta_id", "accion"].forEach(function (k) { if (a[k] != null && a[k] !== "") o[k] = String(a[k]); }); return o; });
    return { generado: o.generado, cuentas: cuentas, movimientos: movs, suscripciones: subs, alertas: alertas, malos: malos };
  };

  M.resumen = function (data, hoy, esDemo) {
    data = M.normalizar(data);
    var cuentas = data.cuentas.map(M.cuenta);
    var movs = data.movimientos.slice().sort(function (a, b) { return a.fecha < b.fecha ? 1 : a.fecha > b.fecha ? -1 : 0; });
    var puesto = 0, cobrado = 0, cuotas = 0;
    movs.forEach(function (m) {
      if (m.tipo === "cobro") cobrado += m.monto || 0;
      else { puesto += m.monto || 0; if (m.categoria === CAT_CUENTAS) cuotas += m.monto || 0; }
    });
    var subs = (data.suscripciones || []).map(function (s) {
      var prox = M.proximoPago(s, hoy), pausada = s.pausada === true;
      return { raw: s, id: s.id, servicio: s.servicio, monto: s.monto, frecuencia: s.frecuencia || "mensual", para_que: s.para_que, prox: prox, dias: prox ? M.diasEntre(hoy, prox) : null, mensual: M.mensual(s), pausada: pausada, manual: M.esManual(s) };
    });
    var subsActivas = subs.filter(function (s) { return !s.pausada; });
    var gastoMes = 0, sinMonto = [];
    subsActivas.forEach(function (s) { if (s.mensual == null) sinMonto.push(s); else gastoMes += s.mensual; });
    var proximo = subsActivas.filter(function (s) { return s.prox; }).sort(function (a, b) { return a.prox - b.prox; })[0] || null;
    var vencimientos = subsActivas.filter(function (s) { return s.prox && s.dias >= 0 && s.dias <= 30; }).sort(function (a, b) { return a.prox - b.prox; });
    var retirable = cuentas.reduce(function (a, c) { return a + c.retirable; }, 0);

    var al = M.construirAlertas({ data: data, cuentas: cuentas, subs: subsActivas, hoy: hoy, esDemo: esDemo });
    var orden = { bad: 0, warn: 1, ok: 2 };
    al.sort(function (a, b) { return (orden[a.nivel] - orden[b.nivel]) || (a.prio - b.prio); });
    var peor = "ok";
    al.forEach(function (a) { if (orden[a.nivel] < orden[peor]) peor = a.nivel; });
    var principal = al[0] || null;
    var frase = principal && (principal.nivel !== "ok" || principal.accion) ? principal.texto : "Todo en orden. No hace falta que hagas nada.";
    var activas = cuentas.filter(function (c) { return c.activa && c.margen != null; });
    var tight = activas.slice().sort(function (a, b) { return a.pctMargen - b.pctMargen; })[0] || null;
    var enEval = cuentas.filter(function (c) { return c.estado === "evaluacion" && !c.llegoObjetivo && c.falta != null; }).sort(function (a, b) { return a.falta - b.falta; })[0] || null;
    return {
      cuentas: cuentas, movs: movs, subs: subs, puesto: puesto, cobrado: cobrado, neto: cobrado - puesto, cuotas: cuotas,
      gastoMes: gastoMes, sinMonto: sinMonto, proximo: proximo, vencimientos: vencimientos, pausadas: subs.length - subsActivas.length, retirable: retirable, alertas: al, nivel: peor, frase: frase, masAlertas: Math.max(0, al.filter(function (a) { return a.nivel !== "ok" || a.accion; }).length - 1),
      tight: tight, enEval: enEval
    };
  };

  /* agrupaciones para Plata */
  M.porMes = function (movs) {
    var o = {};
    movs.forEach(function (m) {
      var k = m.fecha.slice(0, 7); o[k] = o[k] || { k: k, cobro: 0, gasto: 0 };
      o[k][m.tipo === "cobro" ? "cobro" : "gasto"] += m.monto || 0;
    });
    return Object.keys(o).sort().reverse().map(function (k) { return o[k]; });
  };
  M.porCategoria = function (movs, tipo) {
    var o = {};
    movs.filter(function (m) { return (m.tipo === "cobro") === (tipo === "cobro"); }).forEach(function (m) {
      var k = m.categoria || "Sin categoría"; o[k] = (o[k] || 0) + (m.monto || 0);
    });
    return Object.keys(o).map(function (k) { return { cat: k, total: o[k] }; }).sort(function (a, b) { return b.total - a.total; });
  };
  M.mesTxt = function (k, corto) { var p = k.split("-"); var n = MESES[+p[1] - 1]; return corto ? n.slice(0, 3) : n.charAt(0).toUpperCase() + n.slice(1) + " " + p[0]; };

  /* CSV simple: separador ; y coma decimal (abre bien en Excel y Sheets en espanol) */
  M.csv = function (movs, cuentas) {
    var nom = {}; (cuentas || []).forEach(function (c) { nom[c.id] = c.nombre; });
    function n(x) { return x == null ? "" : String(x.toFixed ? x.toFixed(2) : x).replace(".", ","); }
    function fx(s) { s = s == null ? "" : String(s); return /^[=+\-@\t\r]/.test(s) ? "'" + s : s; }
    function q(s) { s = s == null ? "" : String(s); return /[;"\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }
    var rows = [["Fecha", "Tipo", "Categoría", "Descripción", "Cuenta", "Monto USD", "Precio de lista USD", "Descuento USD", "Medio de pago", "Nota"]];
    movs.forEach(function (m) {
      var d = m.detalle || {};
      rows.push([M.fecha(m.fecha), m.tipo === "cobro" ? "Cobro" : "Gasto", fx(m.categoria), fx(m.descripcion), fx(nom[m.cuenta_id] || m.cuenta_id),
        n(m.tipo === "cobro" ? m.monto : -m.monto), n(d.precio_lista), n(d.descuento), fx(d.medio_pago), fx(d.nota)]);
    });
    return "﻿" + rows.map(function (r) { return r.map(q).join(";"); }).join("\r\n");
  };
})(window);

/* Mesa PRO - reglas de alertas. Funciones puras, sin DOM.
   Las usan la app (js/app.js) y el chequeo en segundo plano (runners/check.js, que se arma con resources/build-runner.js
   pegando calc.js + este archivo). Si cambiás una regla acá, corré `node resources/build-runner.js`. */
(function (g) {
  var M = g.Mesa = g.Mesa || {};

  /* Categorías que se pueden prender o apagar en Ajustes */
  M.CATS_AVISO = [
    { id: "retiro", t: "Retiros", d: "Listo para retirar, muy cerca de retirar o retiro frenado por algo que se arregla." },
    { id: "riesgo", t: "Riesgo de la cuenta", d: "Poco margen para perder o cuenta perdida." },
    { id: "objetivo", t: "Objetivo alcanzado", d: "Llegaste al objetivo o estás por llegar." },
    { id: "pagos", t: "Pagos que vencen", d: "3 días antes, el día anterior y el mismo día." },
    { id: "datos", t: "Datos desactualizados", d: "Hace más de 2 días que no se actualizan." },
    { id: "servidor", t: "Avisos del contador", d: "Avisos importantes que deja el proceso automático." }
  ];
  var CAT_POR_CODIGO = { listo_retiro: "retiro", retiro_bloqueado: "retiro", retiro_cerca: "retiro", margen_bajo: "riesgo", cuenta_perdida: "riesgo", objetivo: "objetivo", datos_viejos: "datos", pago: "pagos" };

  /* número entero positivo estable (sirve de id de notificación y de clave corta) */
  M.hash = function (s) { s = String(s); var h = 7; for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 2000000000; return h + 1; };

  function cap(s) { s = String(s || ""); return s.charAt(0).toUpperCase() + s.slice(1); }
  function unir(a, b) { a = String(a || "").trim(); b = String(b || "").trim(); if (!b || a.indexOf(b) > -1) return a; return a + (/[.!?]$/.test(a) ? " " : ". ") + b; }

  /* Texto de un aviso de pago a "dias" días del vencimiento (0 = hoy). etapa: 0 hoy, 1 mañana, 3 faltan 2 o 3 días. */
  M.pagoAviso = function (s, dias) {
    var cuando = dias === 0 ? "hoy" : dias === 1 ? "mañana" : "en " + dias + " días";
    return { etapa: dias === 0 ? 0 : dias === 1 ? 1 : 3,
      titulo: dias === 0 ? "Hoy se paga " + s.servicio : dias === 1 ? "Mañana se paga " + s.servicio : "Se viene un pago",
      texto: s.servicio + (s.monto != null ? " (" + M.usd(s.monto) + ")" : "") + " vence " + cuando + ", el " + M.fecha(s.prox) + ". Dejá saldo disponible en la tarjeta." };
  };

  /* ctx: { data (normalizado), cuentas (M.cuenta), subs (solo activas, con prox y dias), hoy, esDemo } */
  M.construirAlertas = function (ctx) {
    var data = ctx.data, cuentas = ctx.cuentas, subs = ctx.subs, hoy = ctx.hoy, esDemo = ctx.esDemo;
    var al = [], claves = {};
    function add(a) { if (a.key && claves[a.key]) return; if (a.key) claves[a.key] = 1; if (a.notif == null) a.notif = true; al.push(a); }

    if (!cuentas.length) add({ key: "vacio", cat: "datos", nivel: "warn", titulo: "Sin cuentas", texto: "Todavía no hay cuentas cargadas. Revisá que el archivo de Drive se esté actualizando.", prio: 0, notif: false });
    if (data.malos) add({ key: "malos", cat: "datos", nivel: "warn", titulo: "Datos mal formados", texto: "Se ignoraron " + data.malos + (data.malos === 1 ? " dato mal formado" : " datos mal formados") + " del archivo. Revisá el proceso que lo genera.", prio: 6, notif: false });

    /* por cuenta */
    cuentas.forEach(function (c) {
      var n = c.nombre, p = c.payout, id = c.id;
      if (c.estado === "perdida") add({ key: "riesgo|" + id + "|perdida", cat: "riesgo", nivel: "bad", titulo: "Cuenta perdida", texto: n + " está perdida. Revisá en FundedNext si podés reiniciarla.", prio: 1 });
      else if (c.activa && c.nivel === "bad") add({ key: "riesgo|" + id + "|bad", cat: "riesgo", nivel: "bad", titulo: "Hacé esto ahora", texto: "Te quedan " + M.usd(Math.max(0, c.margen)) + " antes de perder " + n + ". Cerrá las posiciones y no operes más hoy.", prio: 1 });
      else if (c.activa && c.nivel === "warn") add({ key: "riesgo|" + id + "|warn", cat: "riesgo", nivel: "warn", titulo: "Poco margen", texto: "Te quedan " + M.usd(c.margen) + " en " + n + ". Operá con menos contratos hasta recuperar colchón.", prio: 2 });

      var elegible = p && p.elegible === true;
      if (c.retirable > 0 || elegible) {
        var monto = c.retirable > 0 ? c.retirable : (p && p.max_retiro > 0 ? p.max_retiro : null);
        add({ key: "retiro|" + id, cat: "retiro", nivel: "ok", accion: true, titulo: "Listo para retirar", prio: 3,
          texto: monto != null ? "Podés retirar " + M.usd(monto) + " de " + n + ". Pedí el retiro en FundedNext." : "Ya cumpliste las condiciones de retiro de " + n + ". Pedí el retiro en FundedNext." });
      } else if (p && p.bloqueo) {
        add({ key: "bloqueo|" + id + "|" + M.hash(p.bloqueo), cat: "retiro", nivel: "warn", titulo: "Retiro frenado, tiene arreglo", prio: 3,
          texto: "El retiro de " + n + " está frenado: " + String(p.bloqueo).replace(/[.\s]+$/, "") + ". " + (p.solucion ? cap(String(p.solucion).replace(/[.\s]+$/, "")) + "." : "Revisalo en FundedNext.") });
      } else if (c.activa && c.estado !== "evaluacion") {
        var faltaDia = p && p.dias_req >= 2 && p.dias_ok != null && p.dias_ok >= p.dias_req - 1 && p.dias_ok < p.dias_req;
        var casi = c.objGan > 0 && c.resultado >= 0.85 * c.objGan && !c.llegoObjetivo;
        if (faltaDia || casi) add({ key: "cerca|" + id, cat: "retiro", nivel: "ok", titulo: "Muy cerca de retirar", prio: 5,
          texto: faltaDia ? "Te falta " + (p.dias_req - p.dias_ok) + " día de payout en " + n + " (" + p.dias_ok + " de " + p.dias_req + "). Operá con cuidado y no rompas la regla de consistencia."
            : "Llevás el " + M.pct(c.resultado / c.objGan * 100, 0) + " del objetivo de " + n + ": faltan " + M.usd(c.falta) + ". Cuidá el colchón y no fuerces operaciones." });
      }
      if (c.estado === "evaluacion" && c.llegoObjetivo) add({ key: "objetivo|" + id, cat: "objetivo", nivel: "ok", accion: true, titulo: "Objetivo alcanzado", prio: 3, texto: "Llegaste al objetivo de " + n + ". Pedí la aprobación en FundedNext." });
      else if (c.estado === "evaluacion" && c.activa && c.objGan > 0 && c.resultado >= 0.85 * c.objGan && c.nivel !== "bad") add({ key: "cerca|" + id, cat: "objetivo", nivel: "ok", titulo: "Muy cerca de aprobar", prio: 5, texto: "Llevás el " + M.pct(c.resultado / c.objGan * 100, 0) + " del objetivo de " + n + ": faltan " + M.usd(c.falta) + ". Cuidá el colchón y no fuerces operaciones." });
    });

    /* avisos que deja el proceso automático (el contador) */
    (data.alertas || []).forEach(function (a) {
      var cod = a.codigo || "", cat = CAT_POR_CODIGO[cod] || "servidor";
      if (cod === "listo_retiro" && a.cuenta_id && claves["retiro|" + a.cuenta_id]) return;
      if (cod === "retiro_bloqueado" && a.cuenta_id && al.some(function (x) { return x.key.indexOf("bloqueo|" + a.cuenta_id + "|") === 0; })) return;
      var ok = a.nivel === "ok", importante = a.nivel !== "ok" || cod === "listo_retiro";
      add({ key: "srv|" + (a.id || M.hash(a.texto)), cat: cat, nivel: a.nivel, accion: cod === "listo_retiro" || undefined, notif: importante,
        titulo: cod === "listo_retiro" ? "Listo para retirar" : cod === "retiro_bloqueado" ? "Retiro frenado, tiene arreglo" : a.nivel === "bad" ? "Mesa PRO: hacé esto ahora" : ok ? "Mesa PRO" : "Mesa PRO: mirá esto",
        texto: unir(a.texto, a.accion), prio: 5 });
    });

    /* pagos (solo suscripciones activas) */
    subs.forEach(function (s) {
      if (s.dias == null || s.dias < 0 || s.dias > 3) return;
      var pa = M.pagoAviso(s, s.dias);
      add({ key: "pago|" + s.id + "|" + M.iso(s.prox) + "|" + pa.etapa, cat: "pagos", nivel: "warn", titulo: pa.titulo, texto: pa.texto, prio: 4 });
    });

    if (!esDemo && data.generado) {
      var gen = new Date(data.generado);
      if (!isNaN(gen) && (Date.now() - gen.getTime()) > 48 * 36e5) add({ key: "datos|" + M.iso(gen), cat: "datos", nivel: "warn", titulo: "Datos viejos", prio: 4, texto: "Los datos tienen más de dos días. Revisá que el proceso automático de Drive siga andando." });
    }
    return al;
  };

  /* Decide qué alertas son nuevas (para notificar una sola vez).
     alertas: las de construirAlertas; previo: { clave: "AAAA-MM-DD" } ya notificadas; prefs: { categoria: false } apaga una categoría.
     opt.sinPagos: no notificar pagos (los cubren los recordatorios programados).
     Devuelve { nuevas: [{ id, key, titulo, texto, nivel }], mapa } donde mapa es el nuevo "ya avisadas" (solo lo que sigue vigente). */
  M.alertasNuevas = function (alertas, previo, hoyISO, prefs, opt) {
    prefs = prefs || {}; opt = opt || {}; previo = previo || {};
    var nuevas = [], mapa = {};
    alertas.forEach(function (a) {
      if (!a.notif || prefs[a.cat] === false) return;
      if (opt.sinPagos && a.cat === "pagos") return;
      if (previo[a.key]) { mapa[a.key] = previo[a.key]; return; }
      mapa[a.key] = hoyISO;
      nuevas.push({ id: M.hash(a.key), key: a.key, titulo: a.titulo, texto: a.texto, nivel: a.nivel });
    });
    return { nuevas: nuevas, mapa: mapa };
  };
})(typeof window !== "undefined" ? window : this);

/* ---- Chequeo en segundo plano de Mesa PRO (@capacitor/background-runner) ----
   Entorno restringido: sin DOM, sin async/await obligatorio; hay fetch, CapacitorKV y CapacitorNotifications.
   Eventos: check (lo dispara Android cada ~30 min), config (la app deja URL, clave y preferencias),
   estado (la app pregunta qué se avisó y cuándo corrió), marcar (la app dice qué ya avisó ella). */
var KV_CFG = "cfg", KV_AVISADAS = "notificadas", KV_ULTIMA = "ultima", KV_ERROR = "error";

function kvGet(k) { try { var r = CapacitorKV.get(k); return r && r.value != null ? r.value : null; } catch (e) { return null; } }
function kvSet(k, v) { try { CapacitorKV.set(k, v); } catch (e) {} }
function kvJSON(k, def) { try { var t = kvGet(k); var o = t ? JSON.parse(t) : null; return o && typeof o === "object" ? o : def; } catch (e) { return def; } }

addEventListener("config", function (resolve, reject, args) {
  try {
    var a = args || {};
    kvSet(KV_CFG, JSON.stringify({ url: String(a.url || ""), clave: String(a.clave || ""), prefs: a.prefs && typeof a.prefs === "object" ? a.prefs : {}, recordatorios: a.recordatorios === true }));
    resolve({ ok: true });
  } catch (e) { resolve({ ok: false }); }
});

addEventListener("marcar", function (resolve, reject, args) {
  try { if (args && args.mapa && typeof args.mapa === "object") kvSet(KV_AVISADAS, JSON.stringify(args.mapa)); } catch (e) {}
  resolve({ ok: true });
});

addEventListener("estado", function (resolve) {
  var cfg = kvJSON(KV_CFG, {});
  resolve({ notificadas: kvJSON(KV_AVISADAS, {}), ultima: kvGet(KV_ULTIMA), error: kvGet(KV_ERROR), configurado: !!(cfg.url && cfg.clave) });
});

/* GET con respaldo: el fetch del runner normalmente sigue el 302 de Apps Script solo; si no lo hiciera y se puede leer "Location", lo sigue a mano. */
function traer(url, n) {
  return fetch(url).then(function (r) {
    var st = r && r.status;
    if ((st === 301 || st === 302 || st === 303 || st === 307 || st === 308) && n < 3) {
      var loc = null;
      try { var h = r.headers; loc = h && (typeof h.get === "function" ? (h.get("location") || h.get("Location")) : (h.location || h.Location)); } catch (e) {}
      if (loc) return traer(String(loc), n + 1);
      throw new Error("redirect_sin_location");
    }
    return r.json();
  });
}

function chequear() {
  var cfg = kvJSON(KV_CFG, {});
  if (!cfg.url || !cfg.clave) return Promise.resolve({ ok: false, motivo: "sin_config" });
  var url = cfg.url + (cfg.url.indexOf("?") > -1 ? "&" : "?") + "k=" + encodeURIComponent(cfg.clave);
  return traer(url, 0).then(function (j) {
    if (!j || j.ok === false || !Array.isArray(j.cuentas)) throw new Error(j && j.error ? String(j.error) : "formato");
    var hoy = Mesa.hoy();
    var r = Mesa.resumen(j, hoy, false);
    var out = Mesa.alertasNuevas(r.alertas, kvJSON(KV_AVISADAS, {}), Mesa.iso(hoy), cfg.prefs || {}, { sinPagos: cfg.recordatorios === true });
    if (out.nuevas.length) CapacitorNotifications.schedule(out.nuevas.map(function (n) { return { id: n.id, title: n.titulo, body: n.texto }; }));
    kvSet(KV_AVISADAS, JSON.stringify(out.mapa));
    kvSet(KV_ULTIMA, new Date().toISOString()); kvSet(KV_ERROR, "");
    return { ok: true, nuevas: out.nuevas.length };
  });
}

addEventListener("check", function (resolve) {
  chequear().then(function (r) { resolve(r); }, function (e) {
    kvSet(KV_ERROR, String((e && e.message) || e).replace(/([?&]k=)[^&\s"']*/g, "$1***").slice(0, 120));
    resolve({ ok: false, motivo: "error" });
  });
});
