/* Mesa PRO - riesgo, horario de Nueva York, curva e infraestructura. Funciones puras, sin DOM ni red.
   Las usan la app y el chequeo en segundo plano (runners/check.js, armado con resources/build-runner.js).
   Si cambiás algo acá, corré `node resources/build-runner.js` y `node test/riesgo.test.js`. */
(function (g) {
  var M = g.Mesa = g.Mesa || {};
  var R = M.R = {};
  var NY = "America/New_York", AR = "America/Argentina/Buenos_Aires";

  /* Valor del punto en US$ por contrato, tamaño del tick y comisión por defecto (ida y vuelta, por contrato).
     La comisión de los micros sale de la operación real del 27/10 (−10 puntos MNQ = −20,00 y salió −21,90).
     La de los minis es una estimación: se puede cambiar en la calculadora. */
  R.INSTR = {
    MNQ: { punto: 2, tick: 0.25, com: 1.9, nombre: "Micro Nasdaq" },
    MYM: { punto: 0.5, tick: 1, com: 1.9, nombre: "Micro Dow" },
    MES: { punto: 5, tick: 0.25, com: 1.9, nombre: "Micro S&P" },
    NQ: { punto: 20, tick: 0.25, com: 4.5, nombre: "Nasdaq mini" },
    YM: { punto: 5, tick: 1, com: 4.5, nombre: "Dow mini" },
    ES: { punto: 50, tick: 0.25, com: 4.5, nombre: "S&P mini" }
  };
  R.TOPE_SCRIPTS = 1000;          /* tope de GANANCIA diaria de cada script en COHETE 50K (no limita pérdidas) */
  R.APERTURA = [9, 30];           /* 09:30 hora de Nueva York */
  R.FIN_SCRIPTS = [15, 45];       /* los scripts operan hasta las 15:45 de Nueva York */
  R.KILLZONE_ANTES = 30;          /* minutos antes de la apertura que cuentan como "previa" */
  /* Feriados de la bolsa de Nueva York (sin sesión normal). Lista corta y fija: revisarla cada año. */
  R.FERIADOS = ["2026-11-26", "2026-12-25", "2027-01-01", "2027-01-18", "2027-02-15", "2027-03-26", "2027-05-31", "2027-06-18", "2027-07-05", "2027-09-06", "2027-11-25", "2027-12-24"];
  /* Medias jornadas: la bolsa cierra 13:00 NY, los scripts terminan 12:45. Revisar las dos listas cada año (vencen fin de 2027). */
  R.MEDIAS = { "2026-11-27": [12, 45], "2026-12-24": [12, 45], "2027-11-26": [12, 45] };
  R.FERIADOS_HASTA = 2027;
  /* Vencimientos que se conocen hoy (los cambia Lucas desde la app o el archivo de datos con infra.alertas_tv). */
  R.ALERTAS_TV = [
    { id: "tv-1", nombre: "Alertas de TradingView (primer lote)", vence: "2026-12-08T22:44" },
    { id: "tv-2", nombre: "Alertas de TradingView (segundo lote)", vence: "2026-12-09T23:59" }
  ];

  function p2(n) { return (n < 10 ? "0" : "") + n; }
  function isoDia(y, m, d) { return y + "-" + p2(m) + "-" + p2(d); }

  /* ---------- zonas horarias (con Intl; en el runner puede no existir y se devuelve null) ---------- */
  var fmtCache = {};
  function partes(fecha, tz) {
    try {
      var f = fmtCache[tz] || (fmtCache[tz] = new Intl.DateTimeFormat("en-US", { timeZone: tz, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", weekday: "short" }));
      var o = {};
      f.formatToParts(fecha).forEach(function (p) { o[p.type] = p.value; });
      var dias = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
      return { y: +o.year, m: +o.month, d: +o.day, h: +o.hour % 24, mi: +o.minute, s: +o.second, dow: dias[o.weekday] };
    } catch (e) { return null; }
  }
  R.partes = partes;
  R.hayZonas = function () { var p = partes(new Date(Date.UTC(2026, 6, 1, 16)), NY); return !!p && p.h === 12; };
  /* minutos que la zona está adelantada respecto de UTC en ese instante (NY en invierno: −300) */
  function offset(fecha, tz) {
    var p = partes(fecha, tz); if (!p) return null;
    return Math.round((Date.UTC(p.y, p.m - 1, p.d, p.h, p.mi, p.s) - Math.floor(fecha.getTime() / 1000) * 1000) / 60000);
  }
  /* El instante (Date) en que en la zona tz son las h:mi del día y-m-d. Correcto en los cambios de horario. */
  R.instante = function (tz, y, m, d, h, mi) {
    var base = Date.UTC(y, m - 1, d, h, mi), t = base, i, off;
    for (i = 0; i < 3; i++) { off = offset(new Date(t), tz); if (off == null) return null; t = base - off * 60000; }
    return new Date(t);
  };
  R.horaEn = function (fecha, tz) { var p = partes(fecha, tz || AR); return p ? p2(p.h) + ":" + p2(p.mi) : "—"; };
  R.diaEn = function (fecha, tz) { var p = partes(fecha, tz || AR); return p ? isoDia(p.y, p.m, p.d) : null; };

  function esFeriado(iso) { return R.FERIADOS.indexOf(iso) > -1; }
  function habil(p) { return p.dow >= 1 && p.dow <= 5 && !esFeriado(isoDia(p.y, p.m, p.d)); }
  function sumarDias(y, m, d, n) { var t = new Date(Date.UTC(y, m - 1, d + n)); return { y: t.getUTCFullYear(), m: t.getUTCMonth() + 1, d: t.getUTCDate(), dow: t.getUTCDay() }; }

  /* Estado de la sesión de Nueva York.
     estado: "antes" (día hábil, falta más de 30 min), "previa" (30 min antes), "sesion" (09:30 a 15:45), "cerrado" (después o día no hábil).
     Devuelve también la próxima apertura y el cierre de scripts, en Date (instantes reales). */
  R.sesion = function (ahora) {
    ahora = ahora || new Date();
    var p = partes(ahora, NY); if (!p) return null;
    var hoyHabil = habil(p);
    function finDe(y, m, d) { var x = R.MEDIAS[isoDia(y, m, d)] || R.FIN_SCRIPTS; return R.instante(NY, y, m, d, x[0], x[1]); }
    var ap = R.instante(NY, p.y, p.m, p.d, R.APERTURA[0], R.APERTURA[1]), fin = finDe(p.y, p.m, p.d);
    var t = ahora.getTime(), estado, prox = ap, cierre = fin;
    if (hoyHabil && t < ap.getTime()) estado = (ap.getTime() - t) <= R.KILLZONE_ANTES * 60000 ? "previa" : "antes";
    else if (hoyHabil && t < fin.getTime()) estado = "sesion";
    else {
      estado = "cerrado";
      var q = { y: p.y, m: p.m, d: p.d }, n = 0, dd;
      do { n++; dd = sumarDias(q.y, q.m, q.d, n); } while ((dd.dow === 0 || dd.dow === 6 || esFeriado(isoDia(dd.y, dd.m, dd.d))) && n < 10);
      prox = R.instante(NY, dd.y, dd.m, dd.d, R.APERTURA[0], R.APERTURA[1]);
      cierre = finDe(dd.y, dd.m, dd.d);
    }
    var motivo = !hoyHabil ? (p.dow === 0 || p.dow === 6 ? "fin de semana" : "feriado en Nueva York") : null;
    return {
      estado: estado, motivo: motivo, apertura: prox, cierre: cierre,
      faltaMs: Math.max(0, prox.getTime() - t), transcurridoMs: estado === "sesion" ? t - ap.getTime() : 0, quedaMs: estado === "sesion" ? fin.getTime() - t : 0,
      aperturaAR: R.horaEn(prox, AR), cierreAR: R.horaEn(cierre, AR), aperturaNY: "09:30", cierreNY: R.horaEn(cierre, NY), mediaJornada: !!R.MEDIAS[R.diaEn(cierre, NY)], listaVencida: p.y > R.FERIADOS_HASTA,
      diaApertura: R.diaEn(prox, AR), offsetNY: offset(prox, NY)
    };
  };
  /* "1 h 12 min", "12 min", "45 s" */
  R.duracion = function (ms) {
    var s = Math.max(0, Math.round(ms / 1000)), h = Math.floor(s / 3600), mi = Math.floor((s % 3600) / 60);
    if (h >= 24) { var dd = Math.floor(h / 24); return dd + (dd === 1 ? " día " : " días ") + (h % 24) + " h"; }
    if (h) return h + " h " + mi + " min";
    if (mi) return mi + " min";
    return s + " s";
  };
  /* "01:12:05" para el reloj grande */
  R.reloj = function (ms) { var s = Math.max(0, Math.floor(ms / 1000)); return p2(Math.floor(s / 3600)) + ":" + p2(Math.floor((s % 3600) / 60)) + ":" + p2(s % 60); };

  /* ---------- curva diaria ---------- */
  /* Une los dos formatos: cuentas[].curva = [[fecha, saldo, piso, resultado_dia, ops_dia], ...]
     y cuentas[].historial_saldo = [{fecha, saldo}]. Un punto por día (si hay dos, queda el último).
     r = resultado del día: el que viene, o la diferencia con el cierre anterior (estimado: true). */
  R.curva = function (c) {
    var raw = c && (c.raw || c), filas = [];
    if (Array.isArray(raw.curva)) raw.curva.forEach(function (x) {
      if (Array.isArray(x)) filas.push({ fecha: x[0], saldo: x[1], piso: x[2], r: x[3], ops: x[4] });
      else if (x && typeof x === "object") filas.push({ fecha: x.fecha, saldo: x.saldo, piso: x.piso, r: x.resultado_dia != null ? x.resultado_dia : x.r, ops: x.ops_dia != null ? x.ops_dia : x.ops });
    });
    else if (Array.isArray(raw.historial_saldo)) raw.historial_saldo.forEach(function (x) { if (x && typeof x === "object") filas.push({ fecha: x.fecha, saldo: x.saldo, piso: x.piso }); });
    function n(v) { if (typeof v === "string" && v.trim() !== "") v = Number(v.replace(",", ".")); return typeof v === "number" && isFinite(v) ? v : null; }
    var porDia = {};
    filas.forEach(function (f) {
      var d = /^\d{4}-\d{2}-\d{2}/.exec(String(f.fecha || "")); if (!d) return;
      var s = n(f.saldo); if (s == null) return;
      porDia[d[0]] = { fecha: d[0], saldo: s, piso: n(f.piso), r: n(f.r), ops: n(f.ops), estimado: false };
    });
    var l = Object.keys(porDia).sort().map(function (k) { return porDia[k]; });
    var ini = n(raw.saldo_inicial);
    l.forEach(function (p, i) {
      if (p.r == null) { var prev = i ? l[i - 1].saldo : null; if (prev != null) { p.r = Math.round((p.saldo - prev) * 100) / 100; p.estimado = true; } }
    });
    if (l.length && l[0].r == null && ini != null && l[0].saldo !== ini) { l[0].r = Math.round((l[0].saldo - ini) * 100) / 100; l[0].estimado = true; }
    var max = ini != null ? ini : -Infinity;
    l.forEach(function (p) { max = Math.max(max, p.saldo); p.max = max; p.dd = Math.round((p.saldo - max) * 100) / 100; });
    return l;
  };
  /* Mejor día (ganancia) de la curva: {fecha, r, estimado} o null */
  R.mejorDia = function (curva) {
    var b = null;
    (curva || []).forEach(function (p) { if (p.r != null && p.r > 0 && (!b || p.r > b.r)) b = p; });
    return b ? { fecha: b.fecha, r: b.r, estimado: b.estimado } : null;
  };
  R.ddMax = function (curva) { var m = 0; (curva || []).forEach(function (p) { if (p.dd < m) m = p.dd; }); return m; };

  /* ---------- cuánto puedo perder hoy ---------- */
  /* Solo manda el margen hasta el piso (pérdida máxima con arrastre, cuenta lo abierto). Flex no tiene límite de pérdida diaria
     y el tope de 1.000 de los scripts es de GANANCIA, así que no recorta la pérdida. El 2º parámetro se ignora (compatibilidad). */
  R.puedoPerder = function (c) {
    if (!c || c.margen == null) return null;
    var margen = Math.max(0, c.margen), manda = margen <= 0 ? "perdida" : "piso";
    var texto = manda === "perdida" ? "Ya tocaste el piso: la cuenta no tiene margen." :
      "Es todo el margen hasta el piso: si las pérdidas del día (también las de posiciones abiertas) llegan a " + M.usd(margen) + ", se pierde la cuenta. La firma no tiene límite de pérdida diaria aparte y el tope de " + M.usd(R.TOPE_SCRIPTS, 0) + " de los scripts es de ganancia, no frena pérdidas.";
    return { valor: margen, margen: margen, tope: null, manda: manda, texto: texto, pct: null };
  };

  /* ---------- cuánto puedo ganar hoy sin romper la consistencia ---------- */
  /* Regla: ningún día puede pasar el pct% (40) de la ganancia total al momento de aprobar/retirar.
     G = ganancia acumulada, b = mejor día hasta ahora, O = objetivo de ganancia.
     Si hoy ganás g, al aprobar el total es al menos max(O, G+g) y el mejor día max(b, g).
     Techo de hoy = max(pct·O, g*) con g* = pct/(1−pct)·G (con 40%: 2/3 de lo ganado). */
  R.puedoGanar = function (c, curva) {
    if (!c) return null;
    var raw = c.raw || {}, pct = (raw.consistencia_max_pct != null ? +raw.consistencia_max_pct : 40) / 100;
    if (!(pct > 0 && pct < 1)) pct = 0.4;
    var G = Math.round((c.resultado || 0) * 100) / 100, O = c.objGan > 0 ? c.objGan : null;
    var md = R.mejorDia(curva), b = md ? md.r : null, fuente = md ? (md.estimado ? "estimado con los cierres diarios" : "de la curva diaria") : null;
    if (b == null && raw.mejor_dia_pct != null && G > 0) { b = Math.round(G * raw.mejor_dia_pct) / 100; fuente = "del porcentaje que informa la firma"; }
    var porGanado = G > 0 ? pct / (1 - pct) * G : 0, porObjetivo = O ? pct * O : 0;
    var techo = Math.max(porGanado, porObjetivo);
    var actual = G > 0 && b != null ? b / G : null;
    var manda = porObjetivo >= porGanado ? "objetivo" : "ganado";
    var texto = manda === "objetivo" && O ? "Con la regla del " + Math.round(pct * 100) + "%, un día de hasta " + M.usd(techo) + " (el " + Math.round(pct * 100) + "% del objetivo de " + M.usd(O, 0) + ") no te traba al aprobar." :
      "Llevás " + M.usd(G) + " ganados: un día de hasta " + M.usd(techo) + " sigue siendo como mucho el " + Math.round(pct * 100) + "% del total.";
    texto += " Cada script corta solo al llegar a " + M.usd(R.TOPE_SCRIPTS, 0) + " de ganancia en el día.";
    return { techo: Math.round(techo * 100) / 100, G: G, b: b, fuenteB: fuente, pct: pct, actual: actual, cumple: actual == null ? null : actual <= pct + 1e-9, manda: manda, texto: texto,
      necesario: b != null && b > 0 ? Math.round(b / pct * 100) / 100 : null };
  };

  /* ---------- calculadora de tamaño ---------- */
  /* o: { instr, stop (puntos), riesgo (US$), com (opcional) } */
  R.tamano = function (o) {
    var ins = R.INSTR[o.instr] || R.INSTR.MNQ, stop = +o.stop, riesgo = +o.riesgo, com = o.com != null && o.com !== "" && isFinite(+o.com) ? +o.com : ins.com;
    if (!(stop > 0) || !(riesgo > 0)) return { ok: false, motivo: !(stop > 0) ? "Poné la distancia al stop en puntos." : "Poné cuánto querés arriesgar." };
    var porContrato = stop * ins.punto + com, n = Math.floor(riesgo / porContrato + 1e-9);
    return { ok: true, contratos: n, porContrato: Math.round(porContrato * 100) / 100, perdida: Math.round(n * porContrato * 100) / 100, ticks: Math.round(stop / ins.tick),
      objetivo2: stop * 2, ganancia2: Math.round((n * stop * 2 * ins.punto - n * com) * 100) / 100, com: com, punto: ins.punto };
  };

  /* ---------- infraestructura ---------- */
  var LETRA = { 3: "H", 6: "M", 9: "U", 12: "Z" }, MES_C = { 3: "Mar", 6: "Jun", 9: "Sep", 12: "Dic" };
  function tercerViernes(y, m) { var d1 = new Date(Date.UTC(y, m - 1, 1)).getUTCDay(), primero = 1 + ((5 - d1 + 7) % 7); return primero + 14; }
  /* Contrato trimestral vigente: vence el tercer viernes de mar/jun/sep/dic; el cambio (roll) se hace ~8 días antes (jueves). */
  R.contrato = function (hoyISO) {
    var y = +hoyISO.slice(0, 4), m = +hoyISO.slice(5, 7), i, cand = [];
    for (i = 0; i < 6; i++) { var mm = 3 * Math.ceil(m / 3) + 3 * i, yy = y + Math.floor((mm - 1) / 12); mm = ((mm - 1) % 12) + 1; cand.push({ y: yy, m: mm }); }
    function info(q) {
      var vto = isoDia(q.y, q.m, tercerViernes(q.y, q.m)), r = sumarDias(q.y, q.m, tercerViernes(q.y, q.m), -8), r0 = sumarDias(q.y, q.m, tercerViernes(q.y, q.m), -9);
      return { codigo: LETRA[q.m] + String(q.y).slice(2), nombre: MES_C[q.m] + " " + String(q.y).slice(2), vence: vto, roll: isoDia(r.y, r.m, r.d), rollDesde: isoDia(r0.y, r0.m, r0.d) };
    }
    for (i = 0; i < cand.length; i++) { var a = info(cand[i]); if (hoyISO <= a.roll) return { vigente: a, siguiente: info(cand[i + 1]) }; }
    return null;
  };
  function diasHasta(desdeISO, hastaISO) { return Math.round((Date.UTC(+hastaISO.slice(0, 4), +hastaISO.slice(5, 7) - 1, +hastaISO.slice(8, 10)) - Date.UTC(+desdeISO.slice(0, 4), +desdeISO.slice(5, 7) - 1, +desdeISO.slice(8, 10))) / 864e5); }
  R.diasHasta = diasHasta;
  /* Lista de ítems {id, titulo, valor, detalle, nivel, dias}. o: { hoy: "AAAA-MM-DD", alertasTv, recordatorios: {activos, proximos}, generado, ahora } */
  R.infra = function (o) {
    var hoy = o.hoy, items = [], c = R.contrato(hoy);
    if (c) {
      var dr = diasHasta(hoy, c.vigente.roll);
      items.push({ id: "contrato", titulo: "Contrato vigente", valor: c.vigente.nombre + " (" + c.vigente.codigo + ")", dias: dr,
        detalle: "Vence el " + M.fecha(c.vigente.vence) + ". El cambio al " + c.siguiente.nombre + " (" + c.siguiente.codigo + ") se hace el " + M.fecha(c.vigente.rollDesde).slice(0, 5) + "–" + M.fecha(c.vigente.roll).slice(0, 5) + (dr >= 0 ? " (" + M.enDias(dr) + ")." : "."),
        nivel: dr <= 3 ? "bad" : dr <= 14 ? "warn" : "ok" });
    }
    (o.alertasTv && o.alertasTv.length ? o.alertasTv : R.ALERTAS_TV).forEach(function (a) {
      var dia = String(a.vence || "").slice(0, 10); if (!/^\d{4}-\d{2}-\d{2}$/.test(dia)) return;
      var d = diasHasta(hoy, dia), hora = String(a.vence).slice(11, 16);
      items.push({ id: "tv|" + (a.id || dia), titulo: a.nombre || "Alertas de TradingView", valor: d < 0 ? "Vencidas" : "Vencen " + M.enDias(d), dias: d,
        detalle: "El " + M.fecha(dia) + (hora && hora !== "23:59" ? " a las " + hora : "") + ". Renovalas antes desde TradingView.", nivel: d < 0 || d <= 2 ? "bad" : d <= 10 ? "warn" : "ok" });
    });
    var sc = c && diasHasta(hoy, "2026-12-07");
    if (c && sc != null && sc >= 0 && sc <= 10) items.push({ id: "semana", titulo: "Semana crítica 7 al 11/12", valor: "Empieza " + M.enDias(sc), dias: sc, detalle: "Se juntan el vencimiento de las alertas y el cambio de contrato. Dejá todo listo antes.", nivel: "warn" });
    if (o.recordatorios) {
      var r = o.recordatorios;
      items.push({ id: "rec", titulo: "Recordatorios de pagos", valor: r.activos ? "Programados" : "Apagados", detalle: r.proximos ? r.proximos + (r.proximos === 1 ? " pago" : " pagos") + " en los próximos 7 días." : "Ningún pago en los próximos 7 días.", nivel: r.activos ? "ok" : "warn" });
    }
    if (o.generado) {
      var horas = (o.ahora - new Date(o.generado).getTime()) / 36e5;
      if (isFinite(horas)) items.push({ id: "datos", titulo: "Datos del contador", valor: horas < 1 ? "Recién" : horas < 48 ? "Hace " + Math.round(horas) + " h" : "Hace " + Math.round(horas / 24) + " días", detalle: "Corte de datos: " + M.fecha(String(o.generado).slice(0, 10)) + " " + String(o.generado).slice(11, 16) + ".", nivel: horas > 48 ? "bad" : horas > 26 ? "warn" : "ok" });
    }
    return items;
  };
})(typeof window !== "undefined" ? window : this);
