/* Mesa PRO - efectos "Cabina": tarjeta 3D (giroscopio + dedo), paralaje del fondo, números con rodillo,
   chispas y perfilador de fps que baja los efectos solo. Todo anima transform/opacity. */
(function (g) {
  var M = g.Mesa = g.Mesa || {};
  var raiz = document.documentElement;
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) {} return null; }
  var reducido = g.matchMedia && g.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var fx = M.fx = { reducido: reducido };

  /* ---------- nivel de efectos: "max" (todo), "bajo" (sin blur/brillo, 3D solo al tocar), "ahorro" (nada) ---------- */
  fx.modo = function () { var m = ls("mesa.fx"); return m === "max" || m === "ahorro" ? m : "auto"; };
  fx.nivel = function () {
    var m = fx.modo();
    if (reducido || m === "ahorro") return "ahorro";
    if (m === "max") return "max";
    return ls("mesa.fx.auto") === "bajo" ? "bajo" : "max";
  };
  fx.aplicar = function () { raiz.setAttribute("data-fx", fx.nivel()); fx.revisarSensor(); };
  fx.setModo = function (m) { ls("mesa.fx", m); if (m !== "auto") ls("mesa.fx.auto", ""); fx.aplicar(); };

  /* ---------- perfilador: mide el tiempo entre cuadros con requestAnimationFrame ---------- */
  fx.perfilar = function (ms) {
    return new Promise(function (ok) {
      var t = [], t0 = null, prev = null;
      function f(now) {
        if (t0 == null) t0 = now; else t.push(now - prev);
        prev = now;
        if (now - t0 < ms) requestAnimationFrame(f);
        else {
          var s = t.slice().sort(function (a, b) { return a - b; }), p95 = s.length ? s[Math.min(s.length - 1, Math.floor(s.length * 0.95))] : 0, prom = t.reduce(function (a, b) { return a + b; }, 0) / (t.length || 1);
          ok({ fps: Math.round(1000 / (prom || 16.7)), p95: Math.round(p95 * 10) / 10, cuadros: t.length });
        }
      }
      requestAnimationFrame(f);
    });
  };
  /* En "Auto": si el celular no llega (p95 > 22 ms), baja a "bajo" solo. */
  fx.autoMedir = function () {
    if (fx.modo() !== "auto" || reducido) return Promise.resolve(null);
    return fx.perfilar(1500).then(function (r) {
      ls("mesa.fx.medido", JSON.stringify({ fps: r.fps, p95: r.p95, cuando: Date.now() }));
      if (r.cuadros > 20 && r.p95 > 22) { ls("mesa.fx.auto", "bajo"); fx.aplicar(); }
      return r;
    });
  };

  /* ---------- inclinación 3D (una sola tarjeta viva por pantalla) ---------- */
  var obj = null, tx = 0, ty = 0, ox = 0, oy = 0, raf = 0, base = null, tocando = false, gyroOn = false, ultimoGyro = 0;
  var fondo = null;
  function pinta() {
    raf = 0; ox += (tx - ox) * 0.16; oy += (ty - oy) * 0.16;
    if (obj) { obj.style.setProperty("--tx", ox.toFixed(3)); obj.style.setProperty("--ty", oy.toFixed(3)); }
    if (fondo || (fondo = document.getElementById("fondo"))) fondo.style.transform = "translate3d(" + (ox * -10).toFixed(1) + "px," + (oy * -10).toFixed(1) + "px,0)";
    if (Math.abs(tx - ox) > 0.002 || Math.abs(ty - oy) > 0.002) raf = requestAnimationFrame(pinta);
  }
  function pide() { if (!raf && fx.nivel() !== "ahorro") raf = requestAnimationFrame(pinta); }
  function gyro(e) {
    if (e.beta == null || tocando || !obj) return;
    if (!base) base = { b: e.beta, g: e.gamma };
    ty = Math.max(-1, Math.min(1, (e.beta - base.b) / 25));
    tx = Math.max(-1, Math.min(1, (e.gamma - base.g) / 25));
    base.b += (e.beta - base.b) * 0.004; base.g += (e.gamma - base.g) * 0.004; /* se re-centra solo */
    ultimoGyro = Date.now(); pide();
  }
  fx.revisarSensor = function () {
    var quiere = !!obj && fx.nivel() === "max" && !document.hidden && "DeviceOrientationEvent" in g;
    if (quiere && !gyroOn) { g.addEventListener("deviceorientation", gyro, { passive: true }); gyroOn = true; base = null; }
    else if (!quiere && gyroOn) { g.removeEventListener("deviceorientation", gyro); gyroOn = false; }
  };
  function punto(e) { var r = obj.getBoundingClientRect(); tx = Math.max(-1, Math.min(1, ((e.clientX - r.left) / r.width - 0.5) * 2)); ty = Math.max(-1, Math.min(1, ((e.clientY - r.top) / r.height - 0.5) * 2)); pide(); }
  function down(e) { if (fx.nivel() === "ahorro") return; tocando = true; obj.classList.add("tocando"); punto(e); }
  function move(e) { if (tocando) punto(e); }
  function up() { if (!tocando) return; tocando = false; if (obj) obj.classList.remove("tocando"); if (Date.now() - ultimoGyro > 400) { tx = ty = 0; pide(); } }
  /* Elige qué tarjeta se inclina (o ninguna). */
  fx.activar = function (el) {
    if (el === obj) return;
    if (obj) { obj.removeEventListener("pointerdown", down); obj.removeEventListener("pointermove", move); obj.style.removeProperty("--tx"); obj.style.removeProperty("--ty"); }
    obj = el || null; tx = ty = ox = oy = 0;
    if (obj) { obj.addEventListener("pointerdown", down, { passive: true }); obj.addEventListener("pointermove", move, { passive: true }); }
    fx.revisarSensor();
  };
  g.addEventListener("pointerup", up, { passive: true }); g.addEventListener("pointercancel", up, { passive: true });
  document.addEventListener("visibilitychange", fx.revisarSensor);

  /* ---------- números con rodillo (odómetro): solo cambian los dígitos que cambian ---------- */
  var COL = "<b>0</b><b>1</b><b>2</b><b>3</b><b>4</b><b>5</b><b>6</b><b>7</b><b>8</b><b>9</b>";
  fx.rodillo = function (el, texto, animar) {
    texto = String(texto);
    if (fx.nivel() === "ahorro" || !el) { if (el) { el.textContent = texto; el.setAttribute("aria-label", texto); } return; }
    var viejo = el.getAttribute("data-rod");
    el.setAttribute("aria-label", texto); el.setAttribute("data-rod", texto);
    var cols = el.querySelectorAll(".d i");
    var mismaForma = viejo != null && viejo.replace(/\d/g, "0") === texto.replace(/\d/g, "0") && cols.length;
    if (mismaForma) { var k = 0; texto.split("").forEach(function (c) { if (/\d/.test(c)) cols[k++].style.transform = "translateY(" + (-c * 10) + "%)"; }); return; }
    el.innerHTML = '<span class="rod" aria-hidden="true">' + texto.split("").map(function (c) { return /\d/.test(c) ? '<span class="d"><i data-n="' + c + '" style="transform:translateY(' + (animar ? 0 : -c * 10) + '%)">' + COL + "</i></span>" : "<span>" + c + "</span>"; }).join("") + "</span>";
    if (animar) requestAnimationFrame(function () { requestAnimationFrame(function () { Array.prototype.forEach.call(el.querySelectorAll(".d i"), function (i) { i.style.transform = "translateY(" + (-i.getAttribute("data-n") * 10) + "%)"; }); }); });
  };

  /* ---------- chispas (canvas 2D, 1,2 s, se destruye) ---------- */
  fx.chispas = function (x, y, color) {
    if (fx.nivel() !== "max") return;
    var c = document.createElement("canvas"), dpr = Math.min(2, g.devicePixelRatio || 1), w = g.innerWidth, h = g.innerHeight;
    c.width = w * dpr; c.height = h * dpr; c.className = "chispas"; document.body.appendChild(c);
    var ctx = c.getContext("2d"); ctx.scale(dpr, dpr);
    var P = []; for (var i = 0; i < 36; i++) P.push({ x: x, y: y, vx: (Math.random() - 0.5) * 7, vy: -Math.random() * 8 - 2, a: 1, r: Math.random() < 0.5 });
    (function f() {
      ctx.clearRect(0, 0, w, h); ctx.fillStyle = color || "#2FD27F";
      P.forEach(function (p) { p.x += p.vx; p.y += p.vy; p.vy += 0.28; p.a -= 0.016; ctx.globalAlpha = Math.max(0, p.a); if (p.r) { ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(0.785); ctx.fillRect(-2, -2, 4, 4); ctx.restore(); } else ctx.fillRect(p.x, p.y, 3, 3); });
      if (P[0].a > 0) requestAnimationFrame(f); else c.remove();
    })();
  };
})(window);
