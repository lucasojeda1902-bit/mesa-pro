/* Mesa PRO - cáscara de arranque (va SOLO en el APK; no se actualiza por aire).
   Decide si arranca la versión de fábrica (la que vino en el APK) o una actualización bajada por aire,
   la carga (marco.html + css + js) y la vigila: si la versión nueva no avisa "arranqué bien" (MesaArranque.ok())
   en N segundos, o falla 2 veces, vuelve sola a la de fábrica y la marca como mala para no repetirla.
   Las actualizaciones se guardan con @capacitor/filesystem (en el navegador, en localStorage). */
(function (g) {
  "use strict";
  var SHELL = 3;              /* versión de la cáscara: un paquete que pide requiere_apk > SHELL no se instala */
  var ESPERA_OK = 8000;       /* ms para que la versión nueva confirme */
  var KEY = "mesa.ota", PREF = "mesa.ota.paquete.";
  var RUTA_OK = /^(marco\.html|css\/[\w.-]+\.css|js\/[\w.-]+\.js)$/;
  var PROHIBIDOS = ["js/arranque.js"];

  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { if (v == null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) {} }
  function leerEstado() { var o = null; try { o = JSON.parse(lsGet(KEY)); } catch (e) {} o = o && typeof o === "object" ? o : {}; if (!Array.isArray(o.malas)) o.malas = []; o.sinOk = o.sinOk | 0; o.fallos = o.fallos | 0; return o; }
  function guardar(o) { lsSet(KEY, JSON.stringify(o)); }
  function fs() { try { var P = g.Capacitor && g.Capacitor.Plugins; return P && P.Filesystem && g.Capacitor.isNativePlatform && g.Capacitor.isNativePlatform() ? P.Filesystem : null; } catch (e) { return null; } }

  /* ---------- almacén de paquetes (uno por versión) ---------- */
  var almacen = {
    guardar: function (ver, texto) {
      var F = fs();
      if (F) return F.writeFile({ path: "ota/" + ver + ".json", data: texto, directory: "DATA", encoding: "utf8", recursive: true }).then(function () { return true; });
      try { localStorage.setItem(PREF + ver, texto); return Promise.resolve(true); } catch (e) { return Promise.reject(new Error("No hay lugar para guardar la actualización.")); }
    },
    leer: function (ver) {
      var F = fs();
      if (F) return F.readFile({ path: "ota/" + ver + ".json", directory: "DATA", encoding: "utf8" }).then(function (r) { return r.data; });
      var t = lsGet(PREF + ver); return t ? Promise.resolve(t) : Promise.reject(new Error("no_esta"));
    },
    borrar: function (ver) {
      var F = fs();
      if (F) return F.deleteFile({ path: "ota/" + ver + ".json", directory: "DATA" }).catch(function () {});
      lsSet(PREF + ver, null); return Promise.resolve();
    },
    /* deja solo las versiones indicadas */
    limpiar: function (dejar) {
      var F = fs();
      if (F) return F.readdir({ path: "ota", directory: "DATA" }).then(function (r) {
        return Promise.all((r.files || []).map(function (f) { var n = typeof f === "string" ? f : f.name, v = n.replace(/\.json$/, ""); return dejar.indexOf(v) < 0 ? almacen.borrar(v) : null; }));
      }).catch(function () {});
      try { for (var i = localStorage.length - 1; i >= 0; i--) { var k = localStorage.key(i); if (k && k.indexOf(PREF) === 0 && dejar.indexOf(k.slice(PREF.length)) < 0) localStorage.removeItem(k); } } catch (e) {}
      return Promise.resolve();
    }
  };

  /* ---------- verificación (SHA-256 sobre "ruta\ncontenido\n" de cada archivo, en el orden de "lista") ---------- */
  function canonico(p) { return p.lista.map(function (r) { return r + "\n" + p.archivos[r] + "\n"; }).join(""); }
  function sha256(texto) {
    var sub = g.crypto && g.crypto.subtle;
    if (!sub) return Promise.reject(new Error("Este celular no puede verificar la actualización."));
    return sub.digest("SHA-256", new TextEncoder().encode(texto)).then(function (b) { return Array.prototype.map.call(new Uint8Array(b), function (x) { return (x < 16 ? "0" : "") + x.toString(16); }).join(""); });
  }
  function cmpVer(a, b) { var x = String(a || "0").split("."), y = String(b || "0").split("."); for (var i = 0; i < 3; i++) { var d = (+x[i] || 0) - (+y[i] || 0); if (d) return d > 0 ? 1 : -1; } return 0; }
  /* Revisa forma, rutas y hash. Devuelve una promesa con el paquete o rechaza con el motivo. */
  function validar(p) {
    if (!p || typeof p !== "object" || p.formato !== 1 || !/^\d+\.\d+\.\d+$/.test(String(p.version || ""))) return Promise.reject(new Error("El archivo de actualización no tiene el formato esperado."));
    if ((+p.requiere_apk || 0) > SHELL) return Promise.reject(new Error("Esta actualización necesita instalar un APK nuevo."));
    if (!Array.isArray(p.lista) || !p.archivos || typeof p.archivos !== "object" || !Array.isArray(p.js) || !Array.isArray(p.css)) return Promise.reject(new Error("Faltan archivos en la actualización."));
    var malas = p.lista.filter(function (r) { return !RUTA_OK.test(r) || PROHIBIDOS.indexOf(r) > -1 || typeof p.archivos[r] !== "string"; });
    if (malas.length || p.lista.indexOf("marco.html") < 0 || p.js.concat(p.css).some(function (r) { return p.lista.indexOf(r) < 0; })) return Promise.reject(new Error("La actualización trae archivos no permitidos."));
    return sha256(canonico(p)).then(function (h) { if (h !== String(p.sha256 || "").toLowerCase()) throw new Error("La actualización llegó dañada (no coincide la huella SHA-256)."); return p; });
  }

  /* ---------- cargar una versión ---------- */
  function traerFabrica() {
    function txt(r) { return fetch(r, { cache: "no-store" }).then(function (x) { if (!x.ok) throw new Error(r); return x.text(); }); }
    return txt("manifiesto.json").then(function (t) {
      var m = JSON.parse(t), lista = ["marco.html"].concat(m.css, m.js), archivos = {};
      return Promise.all(lista.map(function (r) { return txt(r).then(function (c) { archivos[r] = c; }); })).then(function () { return { formato: 1, version: m.version, css: m.css, js: m.js, lista: lista, archivos: archivos }; });
    });
  }
  function montar(p, origen) {
    var d = document;
    p.css.forEach(function (r) { var s = d.createElement("style"); s.setAttribute("data-src", r); s.textContent = p.archivos[r]; d.head.appendChild(s); });
    d.body.insertAdjacentHTML("afterbegin", p.archivos["marco.html"]);
    p.js.forEach(function (r) { var s = d.createElement("script"); s.textContent = p.archivos[r] + "\n//# sourceURL=" + origen + "/" + r; d.body.appendChild(s); });
  }

  var est = leerEstado(), fabrica = null, confirmado = false, timer = null, fuente = "fabrica";
  if (est.pendiente) { est.activa = est.pendiente; est.pendiente = null; est.sinOk = 0; est.fallos = 0; }
  if (est.activa && (est.malas.indexOf(est.activa) > -1 || est.sinOk >= 2 || est.fallos >= 2)) { if (est.malas.indexOf(est.activa) < 0) est.malas.push(est.activa); est.motivo = "No arrancó bien dos veces: volví a la versión de fábrica."; est.activa = null; }
  guardar(est);

  function volverFabrica(motivo) {
    var e = leerEstado();
    if (e.activa && e.malas.indexOf(e.activa) < 0) e.malas.push(e.activa);
    e.activa = null; e.sinOk = 0; e.fallos = 0; e.motivo = motivo; guardar(e);
    try { location.reload(); } catch (x) {}
  }
  function fallo(ev) {
    if (confirmado || fuente !== "ota") return;
    var e = leerEstado(); e.fallos = (e.fallos | 0) + 1; guardar(e);
    g.removeEventListener("error", fallo);
    if (e.fallos >= 2) volverFabrica("La actualización " + e.activa + " falló dos veces: volví a la versión de fábrica.");
    else setTimeout(function () { location.reload(); }, 50);
  }

  g.MesaArranque = {
    shell: SHELL, almacen: almacen, validar: validar, cmpVer: cmpVer, sha256: sha256, canonico: canonico,
    estado: function () { var e = leerEstado(); e.fuente = fuente; e.fabrica = fabrica; e.shell = SHELL; e.version = fuente === "ota" ? e.activa : fabrica; return e; },
    /* La app lo llama cuando terminó de pintar la primera pantalla. */
    ok: function () {
      if (confirmado) return; confirmado = true; clearTimeout(timer); g.removeEventListener("error", fallo);
      var e = leerEstado(); if (fuente === "ota") { e.sinOk = 0; e.fallos = 0; e.confirmada = e.activa; guardar(e); }
    },
    /* Deja una versión ya verificada para el próximo arranque. */
    programar: function (ver) { var e = leerEstado(); e.pendiente = ver; e.motivo = null; guardar(e); return almacen.limpiar([ver, e.activa].filter(Boolean)); },
    fabrica: function () { var e = leerEstado(); e.activa = null; e.pendiente = null; e.sinOk = 0; e.fallos = 0; e.motivo = null; guardar(e); return almacen.limpiar([]); },
    olvidarMotivo: function () { var e = leerEstado(); e.motivo = null; guardar(e); }
  };

  function arrancarFabrica() {
    fuente = "fabrica";
    return traerFabrica().then(function (p) { fabrica = p.version; montar(p, "fabrica"); });
  }
  function arrancarOta(ver) {
    return almacen.leer(ver).then(function (t) { return validar(JSON.parse(t)); }).then(function (p) {
      if (p.version !== ver) throw new Error("versión cruzada");
      return fetch("manifiesto.json", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (m) { fabrica = m.version; }, function () {}).then(function () {
        fuente = "ota";
        var e = leerEstado(); e.sinOk = (e.sinOk | 0) + 1; guardar(e);
        g.addEventListener("error", fallo);
        timer = setTimeout(function () { if (!confirmado) volverFabrica("La actualización " + ver + " no terminó de arrancar en " + (ESPERA_OK / 1000) + " segundos: volví a la versión de fábrica."); }, ESPERA_OK);
        montar(p, "ota-" + ver);
      });
    });
  }
  (est.activa ? arrancarOta(est.activa).catch(function (err) {
    var e = leerEstado(); if (e.activa && e.malas.indexOf(e.activa) < 0) e.malas.push(e.activa);
    e.activa = null; e.motivo = "No pude abrir la actualización guardada (" + (err && err.message || err) + "): uso la de fábrica."; guardar(e);
    return arrancarFabrica();
  }) : arrancarFabrica()).catch(function (err) {
    document.body.insertAdjacentHTML("afterbegin", '<p style="font:600 16px system-ui;color:#EEF3F8;padding:40px 24px">Mesa PRO no pudo arrancar (' + String(err && err.message || err).replace(/[<>&]/g, "") + '). Cerrala y volvé a abrirla.</p>');
  });
})(window);
