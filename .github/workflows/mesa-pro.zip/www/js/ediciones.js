/* Mesa PRO - ediciones (agregar, editar, borrar, pausar) y su cola de envío.
   Parte pura (Mesa.edReducir / Mesa.edMezclar): MISMA lógica que apps-script/Datos.gs. Si cambiás una, cambiá la otra
   y corré test/merge.test.js (compara las dos). */
(function (g) {
  var M = g.Mesa = g.Mesa || {};
  var COLS = ["movimientos", "suscripciones", "cuentas"];
  M.ED_COLS = COLS;
  function asig(o) { for (var i = 1; i < arguments.length; i++) { var s = arguments[i]; if (s) for (var k in s) if (Object.prototype.hasOwnProperty.call(s, k)) o[k] = s[k]; } return o; }
  function esMan(e) { return !!e && (e.origen === "manual" || /^man-/.test(String(e.id || ""))); }
  function num(x) { if (typeof x === "string" && x.trim() !== "") x = Number(x.replace(",", ".")); return typeof x === "number" && isFinite(x); }

  /* Deja un solo item por (col,id): el último por fecha (ts). Dos upsert seguidos se suman campo a campo. */
  M.edReducir = function (items) {
    var ord = (items || []).map(function (it, i) { return { it: it, i: i }; }).sort(function (a, b) { var x = String(a.it.ts || ""), y = String(b.it.ts || ""); return x < y ? -1 : x > y ? 1 : a.i - b.i; });
    var mapa = {}, orden = [];
    ord.forEach(function (o) {
      var it = o.it, k = it.col + "|" + it.id, prev = mapa[k];
      if (it.op === "upsert" && prev && prev.op === "upsert") it = { col: it.col, op: "upsert", id: it.id, ts: it.ts, data: asig({}, prev.data, it.data) };
      if (!prev) orden.push(k);
      mapa[k] = it;
    });
    return orden.map(function (k) { return mapa[k]; });
  };

  function minimo(col, d) {
    if (col === "movimientos") return !!d.fecha && num(d.monto);
    if (col === "suscripciones") return typeof d.servicio === "string" && d.servicio !== "";
    if (col === "cuentas") return num(d.saldo);
    return false;
  }

  /* Aplica las ediciones sobre los datos y devuelve datos nuevos (no toca los originales). */
  M.edMezclar = function (datos, items) {
    var out = asig({}, datos || {});
    COLS.forEach(function (c) { out[c] = Array.isArray(out[c]) ? out[c].slice() : []; });
    M.edReducir(items).forEach(function (it) {
      if (COLS.indexOf(it.col) < 0) return;
      var lista = out[it.col], idx = -1, i;
      for (i = 0; i < lista.length; i++) if (lista[i] && String(lista[i].id) === String(it.id)) { idx = i; break; }
      if (it.op === "delete") { if (idx > -1) lista.splice(idx, 1); return; }
      if (it.op !== "upsert" || !it.data || typeof it.data !== "object") return;
      var d = asig({}, it.data); delete d.id; delete d.origen;
      if (idx > -1) {
        var orig = lista[idx], man = esMan(orig);
        if (it.col === "cuentas" && !man) { d = Object.prototype.hasOwnProperty.call(d, "nota") ? { nota: d.nota } : null; if (!d) return; }
        var el = asig({}, orig, d); el.id = orig.id; el.origen = man ? "manual" : "editado"; lista[idx] = el;
      } else {
        if (!minimo(it.col, d)) return;
        var nuevo = asig({}, d); nuevo.id = String(it.id); nuevo.origen = "manual"; lista.push(nuevo);
      }
    });
    return out;
  };

  M.nuevoId = function () { return "man-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); };

  /* Diferencia entre un elemento actual y el editado (solo lo que cambió). */
  M.edDiff = function (actual, nuevo) {
    var d = {}, k;
    for (k in nuevo) if (Object.prototype.hasOwnProperty.call(nuevo, k) && k !== "id" && k !== "origen") {
      if (JSON.stringify(nuevo[k]) !== JSON.stringify(actual ? actual[k] : undefined)) d[k] = nuevo[k] === undefined ? null : nuevo[k];
    }
    return d;
  };

  /* ---------- cola de envío (en el celular) ---------- */
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) {} return null; }
  M.Cola = function (clave) {
    var q = { items: [] };
    try { var j = JSON.parse(ls(clave)); if (Array.isArray(j)) q.items = j.filter(function (x) { return x && x.col && x.id && x.op; }); } catch (e) {}
    function guardar() { ls(clave, JSON.stringify(q.items)); }
    q.pendientes = function () { return q.items.filter(function (x) { return !x.sent; }).length; };
    q.agregar = function (it) {
      it.ts = new Date().toISOString();
      if (it.op === "delete") it._h = Date.now() + 5500; /* espera el "Deshacer" antes de mandarlo */
      /* dos cambios seguidos al mismo elemento que todavía no salieron se juntan en uno */
      if (it.op === "upsert") for (var i = q.items.length - 1; i >= 0; i--) { var x = q.items[i]; if (x.col === it.col && x.id === it.id) { if (!x.sent && x.op === "upsert") { x.data = asig({}, x.data, it.data); x.ts = it.ts; guardar(); return x; } break; } }
      q.items.push(it); guardar(); return it;
    };
    /* Deshacer un borrado que todavía no salió: lo saca de la cola. */
    q.quitar = function (it) { var i = q.items.indexOf(it); if (i > -1 && !it.sent) { q.items.splice(i, 1); guardar(); return true; } return false; };
    q.listos = function () { var ahora = Date.now(); return q.items.filter(function (x) { return !x.sent && (!x._h || x._h <= ahora); }); };
    q.proximoHold = function () { var ahora = Date.now(), m = null; q.items.forEach(function (x) { if (!x.sent && x._h && x._h > ahora && (m == null || x._h < m)) m = x._h; }); return m; };
    /* Manda lo pendiente. Devuelve una promesa { ok, enviados, error }. */
    q.enviar = function (url, k) {
      var lote = q.listos().slice(0, 50);
      if (!lote.length) return Promise.resolve({ ok: true, enviados: 0 });
      var cuerpo = JSON.stringify({ k: k, items: lote.map(function (x) { return { col: x.col, op: x.op, id: x.id, data: x.data || {}, ts: x.ts }; }) });
      var ctrl = g.AbortController ? new AbortController() : null, to = setTimeout(function () { if (ctrl) ctrl.abort(); }, 15000);
      return fetch(url, { method: "POST", body: cuerpo, headers: { "Content-Type": "text/plain;charset=utf-8" }, redirect: "follow", signal: ctrl && ctrl.signal })
        .then(function (r) { clearTimeout(to); if (!r.ok) throw new Error("El servidor contestó " + r.status + "."); return r.json(); })
        .then(function (j) {
          if (!j || j.ok !== true) throw new Error(j && j.error === "clave" ? "La clave no coincide con la del script." : "El script rechazó los cambios" + (j && j.error ? " (" + j.error + ")." : "."));
          lote.forEach(function (x) { x.sent = true; delete x._h; }); guardar();
          return { ok: true, enviados: lote.length, version: j.version };
        }).catch(function (e) { clearTimeout(to); return { ok: false, enviados: 0, error: (e && e.name === "AbortError") ? "Tardó demasiado." : (e && e.message) || "Sin conexión." }; });
    };
    /* Cuando el servidor ya devolvió los datos con lo enviado, ya no hace falta aplicarlo a mano. */
    q.limpiarEnviados = function (lista) { var n = q.items.length; q.items = q.items.filter(function (x) { return !(x.sent && (!lista || lista.indexOf(x) > -1)); }); if (q.items.length !== n) guardar(); };
    q.enviados = function () { return q.items.filter(function (x) { return x.sent; }); };
    q.guardar = guardar;
    return q;
  };
})(typeof window !== "undefined" ? window : this);
