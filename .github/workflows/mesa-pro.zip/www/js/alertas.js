/* Mesa PRO - reglas de alertas. Funciones puras, sin DOM.
   Las usan la app (js/app.js) y el chequeo en segundo plano (runners/check.js, que se arma con resources/build-runner.js
   pegando calc.js + este archivo). Si cambiás una regla acá, corré `node resources/build-runner.js`. */
(function (g) {
  var M = g.Mesa = g.Mesa || {};

  /* Categorías que se pueden prender o apagar en Ajustes */
  M.CATS_AVISO = [
    { id: "retiro", t: "Retiros", d: "Listo para retirar, muy cerca de retirar o retiro frenado por algo que se arregla." },
    { id: "riesgo", t: "Riesgo de la cuenta", d: "Poco margen para perder o cuenta perdida." },
    { id: "objetivo", t: "Objetivo alcanzado", d: "Llegaste al objetivo o estás por llegar." },
    { id: "pagos", t: "Pagos que vencen", d: "3 días antes, el día anterior y el mismo día." },
    { id: "datos", t: "Datos desactualizados", d: "Hace más de 2 días que no se actualizan." },
    { id: "infra", t: "Infraestructura", d: "Vencimiento de las alertas de TradingView y cambio de contrato (3 días antes)." },
    { id: "servidor", t: "Avisos del contador", d: "Avisos importantes que deja el proceso automático." }
  ];
  var CAT_POR_CODIGO = { listo_retiro: "retiro", retiro_bloqueado: "retiro", retiro_cerca: "retiro", margen_bajo: "riesgo", cuenta_perdida: "riesgo", objetivo: "objetivo", datos_viejos: "datos", pago: "pagos" };

  /* número entero positivo estable (sirve de id de notificación y de clave corta) */
  M.hash = function (s) { s = String(s); var h = 7; for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 2000000000; return h + 1; };

  function cap(s) { s = String(s || ""); return s.charAt(0).toUpperCase() + s.slice(1); }
  function unir(a, b) { a = String(a || "").trim(); b = String(b || "").trim(); if (!b || a.indexOf(b) > -1) return a; return a + (/[.!?]$/.test(a) ? " " : ". ") + b; }

  /* Texto de un aviso de pago a "dias" días del vencimiento (0 = hoy). etapa: 0 hoy, 1 mañana, 3 faltan 2 o 3 días. */
  M.pagoAviso = function (s, dias) {
    var cuando = dias === 0 ? "hoy" : dias === 1 ? "mañana" : "en " + dias + " días";
    return { etapa: dias === 0 ? 0 : dias === 1 ? 1 : 3,
      titulo: dias === 0 ? "Hoy se paga " + s.servicio : dias === 1 ? "Mañana se paga " + s.servicio : "Se viene un pago",
      texto: s.servicio + (s.monto != null ? " (" + M.usd(s.monto) + ")" : "") + " vence " + cuando + ", el " + M.fecha(s.prox) + ". Dejá saldo disponible en la tarjeta." };
  };

  /* ctx: { data (normalizado), cuentas (M.cuenta), subs (solo activas, con prox y dias), hoy, esDemo } */
  M.construirAlertas = function (ctx) {
    var data = ctx.data, cuentas = ctx.cuentas, subs = ctx.subs, hoy = ctx.hoy, esDemo = ctx.esDemo;
    var al = [], claves = {};
    function add(a) { if (a.key && claves[a.key]) return; if (a.key) claves[a.key] = 1; if (a.notif == null) a.notif = true; al.push(a); }

    if (!cuentas.length) add({ key: "vacio", cat: "datos", nivel: "warn", titulo: "Sin cuentas", texto: "Todavía no hay cuentas cargadas. Revisá que el archivo de Drive se esté actualizando.", prio: 0, notif: false });
    if (data.malos) add({ key: "malos", cat: "datos", nivel: "warn", titulo: "Datos mal formados", texto: "Se ignoraron " + data.malos + (data.malos === 1 ? " dato mal formado" : " datos mal formados") + " del archivo. Revisá el proceso que lo genera.", prio: 6, notif: false });

    /* por cuenta */
    cuentas.forEach(function (c) {
      var n = c.nombre, p = c.payout, id = c.id;
      if (c.estado === "perdida") add({ key: "riesgo|" + id + "|perdida", cat: "riesgo", nivel: "bad", titulo: "Cuenta perdida", texto: n + " está perdida. Revisá en FundedNext si podés reiniciarla.", prio: 1 });
      else if (c.activa && c.nivel === "bad") add({ key: "riesgo|" + id + "|bad", cat: "riesgo", nivel: "bad", titulo: "Hacé esto ahora", texto: "Te quedan " + M.usd(Math.max(0, c.margen)) + " antes de perder " + n + ". Cerrá las posiciones y no operes más hoy.", prio: 1 });
      else if (c.activa && c.nivel === "warn") add({ key: "riesgo|" + id + "|warn", cat: "riesgo", nivel: "warn", titulo: "Poco margen", texto: "Te quedan " + M.usd(c.margen) + " en " + n + ". Operá con menos contratos hasta recuperar colchón.", prio: 2 });

      var elegible = p && p.elegible === true;
      if (c.retirable > 0 || elegible) {
        var monto = c.retirable > 0 ? c.retirable : (p && p.max_retiro > 0 ? p.max_retiro : null);
        add({ key: "retiro|" + id, cat: "retiro", nivel: "ok", accion: true, titulo: "Listo para retirar", prio: 3,
          texto: monto != null ? "Podés retirar " + M.usd(monto) + " de " + n + ". Pedí el retiro en FundedNext." : "Ya cumpliste las condiciones de retiro de " + n + ". Pedí el retiro en FundedNext." });
      } else if (p && p.bloqueo) {
        add({ key: "bloqueo|" + id + "|" + M.hash(p.bloqueo), cat: "retiro", nivel: "warn", titulo: "Retiro frenado, tiene arreglo", prio: 3,
          texto: "El retiro de " + n + " está frenado: " + String(p.bloqueo).replace(/[.\s]+$/, "") + ". " + (p.solucion ? cap(String(p.solucion).replace(/[.\s]+$/, "")) + "." : "Revisalo en FundedNext.") });
      } else if (c.activa && c.estado !== "evaluacion") {
        var faltaDia = p && p.dias_req >= 2 && p.dias_ok != null && p.dias_ok >= p.dias_req - 1 && p.dias_ok < p.dias_req;
        var casi = c.objGan > 0 && c.resultado >= 0.85 * c.objGan && !c.llegoObjetivo;
        if (faltaDia || casi) add({ key: "cerca|" + id, cat: "retiro", nivel: "ok", titulo: "Muy cerca de retirar", prio: 5,
          texto: faltaDia ? "Te falta " + (p.dias_req - p.dias_ok) + " día de payout en " + n + " (" + p.dias_ok + " de " + p.dias_req + "). Operá con cuidado y no rompas la regla de consistencia."
            : "Llevás el " + M.pct(c.resultado / c.objGan * 100, 0) + " del objetivo de " + n + ": faltan " + M.usd(c.falta) + ". Cuidá el colchón y no fuerces operaciones." });
      }
      if (c.estado === "evaluacion" && c.llegoObjetivo) add({ key: "objetivo|" + id, cat: "objetivo", nivel: "ok", accion: true, titulo: "Objetivo alcanzado", prio: 3, texto: "Llegaste al objetivo de " + n + ". Pedí la aprobación en FundedNext." });
      else if (c.estado === "evaluacion" && c.activa && c.objGan > 0 && c.resultado >= 0.85 * c.objGan && c.nivel !== "bad") add({ key: "cerca|" + id, cat: "objetivo", nivel: "ok", titulo: "Muy cerca de aprobar", prio: 5, texto: "Llevás el " + M.pct(c.resultado / c.objGan * 100, 0) + " del objetivo de " + n + ": faltan " + M.usd(c.falta) + ". Cuidá el colchón y no fuerces operaciones." });
    });

    /* avisos que deja el proceso automático (el contador) */
    (data.alertas || []).forEach(function (a) {
      var cod = a.codigo || "", cat = CAT_POR_CODIGO[cod] || "servidor";
      if (cod === "listo_retiro" && a.cuenta_id && claves["retiro|" + a.cuenta_id]) return;
      if (cod === "retiro_bloqueado" && a.cuenta_id && al.some(function (x) { return x.key.indexOf("bloqueo|" + a.cuenta_id + "|") === 0; })) return;
      var ok = a.nivel === "ok", importante = a.nivel !== "ok" || cod === "listo_retiro";
      add({ key: "srv|" + (a.id || M.hash(a.texto)), cat: cat, nivel: a.nivel, accion: cod === "listo_retiro" || undefined, notif: importante,
        titulo: cod === "listo_retiro" ? "Listo para retirar" : cod === "retiro_bloqueado" ? "Retiro frenado, tiene arreglo" : a.nivel === "bad" ? "Mesa PRO: hacé esto ahora" : ok ? "Mesa PRO" : "Mesa PRO: mirá esto",
        texto: unir(a.texto, a.accion), prio: 5 });
    });

    /* pagos (solo suscripciones activas) */
    subs.forEach(function (s) {
      if (s.dias == null || s.dias < 0 || s.dias > 3) return;
      var pa = M.pagoAviso(s, s.dias);
      add({ key: "pago|" + s.id + "|" + M.iso(s.prox) + "|" + pa.etapa, cat: "pagos", nivel: "warn", titulo: pa.titulo, texto: pa.texto, prio: 4 });
    });

    /* infraestructura (calculada en el celular con riesgo.js): alertas de TradingView y cambio de contrato a 3 días o menos */
    if (M.R && M.R.infra) {
      var tv = data.infra && Array.isArray(data.infra.alertas_tv) ? data.infra.alertas_tv : null;
      M.R.infra({ hoy: M.iso(hoy), alertasTv: tv }).forEach(function (it) {
        if ((it.id !== "contrato" && it.id.indexOf("tv|") !== 0) || it.dias == null || it.dias < 0 || it.dias > 3) return;
        add({ key: "infra|" + it.id + "|" + it.dias, cat: "infra", nivel: "warn", prio: 4,
          titulo: it.id === "contrato" ? "Se viene el cambio de contrato" : "Vencen alertas de TradingView",
          texto: it.id === "contrato" ? it.valor + ": " + it.detalle : it.titulo + " " + it.valor.toLowerCase() + ". " + it.detalle });
      });
    }

    if (!esDemo && data.generado) {
      var gen = new Date(data.generado);
      if (!isNaN(gen) && (Date.now() - gen.getTime()) > 48 * 36e5) add({ key: "datos|" + M.iso(gen), cat: "datos", nivel: "warn", titulo: "Datos viejos", prio: 4, texto: "Los datos tienen más de dos días. Revisá que el proceso automático de Drive siga andando." });
    }
    return al;
  };

  /* Decide qué alertas son nuevas (para notificar una sola vez).
     alertas: las de construirAlertas; previo: { clave: "AAAA-MM-DD" } ya notificadas; prefs: { categoria: false } apaga una categoría.
     opt.sinPagos: no notificar pagos (los cubren los recordatorios programados).
     Devuelve { nuevas: [{ id, key, titulo, texto, nivel }], mapa } donde mapa es el nuevo "ya avisadas" (solo lo que sigue vigente). */
  M.alertasNuevas = function (alertas, previo, hoyISO, prefs, opt) {
    prefs = prefs || {}; opt = opt || {}; previo = previo || {};
    var nuevas = [], mapa = {};
    alertas.forEach(function (a) {
      if (!a.notif || prefs[a.cat] === false) return;
      if (opt.sinPagos && a.cat === "pagos") return;
      if (opt.frenado && a.nivel !== "bad") return; /* "Frenar por hoy": solo pasan los críticos */
      if (previo[a.key]) { mapa[a.key] = previo[a.key]; return; }
      mapa[a.key] = hoyISO;
      nuevas.push({ id: M.hash(a.key), key: a.key, titulo: a.titulo, texto: a.texto, nivel: a.nivel, cat: a.cat });
    });
    return { nuevas: nuevas, mapa: mapa };
  };
})(typeof window !== "undefined" ? window : this);
