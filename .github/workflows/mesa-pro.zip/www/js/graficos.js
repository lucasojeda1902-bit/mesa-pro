/* Mesa PRO - gráficos analizables del detalle de cuenta.
   Curva de saldo y drawdown con TradingView Lightweight Charts 5.0.9 (vendor/, Apache 2.0, se carga recién al abrir el gráfico);
   calendario por día en SVG propio. Los datos salen de cuentas[].curva o cuentas[].historial_saldo: nunca se inventan puntos. */
(function (g) {
  var M = g.Mesa = g.Mesa || {}, esc = M.esc;
  var carga = null;
  function cargarLib() {
    if (g.LightweightCharts) return Promise.resolve(g.LightweightCharts);
    if (carga) return carga;
    carga = new Promise(function (ok, mal) {
      var s = document.createElement("script"); s.src = "vendor/lightweight-charts.js";
      s.onload = function () { g.LightweightCharts ? ok(g.LightweightCharts) : mal(new Error("lib")); };
      s.onerror = function () { carga = null; mal(new Error("No pude cargar la librería de gráficos.")); };
      document.head.appendChild(s);
    });
    return carga;
  }
  function tok(n) { return getComputedStyle(document.documentElement).getPropertyValue(n).trim() || "#888"; }
  function rgba(hex, a) { var m = /^#?([\da-f]{2})([\da-f]{2})([\da-f]{2})$/i.exec(hex); return m ? "rgba(" + parseInt(m[1], 16) + "," + parseInt(m[2], 16) + "," + parseInt(m[3], 16) + "," + a + ")" : hex; }
  var DIAS = ["dom", "lun", "mar", "mié", "jue", "vie", "sáb"];
  function diaTxt(f) { var d = M.parseISO(f); return d ? DIAS[d.getDay()] + " " + M.fecha(f).slice(0, 5) : f; }

  /* HTML del bloque (se pinta dentro del sheet); M.graf.montar lo activa. */
  M.graf = {
    html: function (c) {
      var cu = M.R.curva(c);
      if (cu.length < 2) return '<div class="graf-vacio"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 19h16M6 15l4-4 3 3 5-6"/></svg><p><b>Todavía no hay datos suficientes para el gráfico.</b> Hace falta un cierre por día (al menos dos) en <code>historial_saldo</code> o <code>curva</code>. Lo escribe el contador automático; la app no inventa puntos.</p></div>';
      var md = M.R.mejorDia(cu), dd = M.R.ddMax(cu), ult = cu[cu.length - 1];
      var h = '<p class="graf-corte">Corte de datos: cierre del ' + M.fecha(ult.fecha) + " · " + cu.length + (cu.length === 1 ? " día" : " días") + (cu.some(function (p) { return p.estimado; }) ? " · resultado diario estimado con la diferencia entre cierres" : "") + "</p>";
      h += '<div class="seg rangos" role="group" aria-label="Rango del gráfico">' + [["7", "7 d"], ["14", "14 d"], ["30", "30 d"], ["0", "Todo"]].map(function (r) { return '<button type="button" data-rango="' + r[0] + '" aria-pressed="' + (r[0] === "0") + '">' + r[1] + "</button>"; }).join("") + "</div>";
      h += '<div class="graf-det" id="graf-det" aria-live="polite"></div><div class="lwc" id="lwc-curva" role="img" aria-label="Curva de saldo con piso y objetivo. Tocá y arrastrá para ver cada día; pellizcá para hacer zoom."></div>';
      h += '<h3 class="graf-t">Drawdown <span>(caída desde tu máximo)</span></h3><p class="graf-p">Peor caída: <b class="pierde">' + M.usd(dd) + "</b>" + ((c.raw.reglas && +c.raw.reglas.perdida_max) || c.perdidaMax ? " de " + M.usd((c.raw.reglas && +c.raw.reglas.perdida_max) || c.perdidaMax, 0) + " de pérdida máxima." : ".") + '</p><div class="lwc chico" id="lwc-dd" role="img" aria-label="Drawdown, sincronizado con la curva"></div>';
      h += '<h3 class="graf-t">Calendario <span>(resultado de cada día)</span></h3><p class="graf-p">' + (md ? "Mejor día: <b class=\"gana\">" + M.usdSigno(md.r) + "</b> el " + M.fecha(md.fecha) + (c.resultado > 0 ? ", el " + M.pct(md.r / c.resultado * 100, 0) + " de lo ganado." : ".") : "Todavía no hubo un día en ganancia.") + '</p><div class="cal" id="cal"></div><p class="cal-det" id="cal-det">Tocá un día para ver el detalle.</p>';
      return h;
    },
    /* Activa los gráficos dentro de "raiz". Devuelve una función para destruirlos. */
    montar: function (raiz, c) {
      var cu = M.R.curva(c), vivo = true, charts = [];
      if (cu.length < 2) return function () {};
      calendario(raiz, cu, c);
      var det = raiz.querySelector("#graf-det");
      det.innerHTML = resumenDia(cu[cu.length - 1], c);
      cargarLib().then(function (L) {
        if (!vivo) return;
        var c1 = raiz.querySelector("#lwc-curva"), c2 = raiz.querySelector("#lwc-dd");
        var gana = tok("--gana"), pierde = tok("--pierde"), suave = tok("--suave"), linea = tok("--linea2"), acento = tok("--acento"), ok = tok("--l-ok"), bad = tok("--l-bad");
        function opciones(alto) {
          return { autoSize: true, height: alto, layout: { background: { type: "solid", color: "transparent" }, textColor: suave, fontFamily: "Manrope, system-ui, sans-serif", fontSize: 11, attributionLogo: true },
            localization: { locale: "es-AR", priceFormatter: function (v) { return M.num(v, 0); } },
            grid: { vertLines: { visible: false }, horzLines: { color: linea } }, rightPriceScale: { borderVisible: false }, timeScale: { borderVisible: false, fixLeftEdge: true, fixRightEdge: true, rightOffset: 0 },
            crosshair: { mode: 1, vertLine: { color: suave, labelBackgroundColor: acento }, horzLine: { color: suave, labelBackgroundColor: acento } },
            handleScale: { pinch: true, mouseWheel: true, axisPressedMouseMove: false }, handleScroll: { horzTouchDrag: true, vertTouchDrag: false, pressedMouseMove: true, mouseWheel: false }, kineticScroll: { touch: true, mouse: false } };
        }
        var ch = L.createChart(c1, opciones(230)); charts.push(ch);
        var serie = ch.addSeries(L.BaselineSeries, { baseValue: { type: "price", price: c.inicial }, topLineColor: gana, bottomLineColor: pierde, topFillColor1: rgba(gana, 0.28), topFillColor2: rgba(gana, 0.02), bottomFillColor1: rgba(pierde, 0.02), bottomFillColor2: rgba(pierde, 0.28), lineWidth: 2, priceLineVisible: false, title: "saldo" });
        serie.setData(cu.map(function (p) { return { time: p.fecha, value: p.saldo }; }));
        var conPiso = cu.filter(function (p) { return p.piso != null; }), piso = null;
        if (conPiso.length >= 2) { piso = ch.addSeries(L.LineSeries, { color: bad, lineWidth: 1, lineStyle: 2, priceLineVisible: false, lastValueVisible: true, title: "piso", crosshairMarkerVisible: false }); piso.setData(conPiso.map(function (p) { return { time: p.fecha, value: p.piso }; })); }
        else if (c.raw.piso != null) serie.createPriceLine({ price: c.raw.piso, color: bad, lineStyle: 2, lineWidth: 1, axisLabelVisible: true, title: "piso hoy" });
        if (c.objSaldo != null) serie.createPriceLine({ price: c.objSaldo, color: ok, lineStyle: 2, lineWidth: 1, axisLabelVisible: true, title: "objetivo" });
        var marcas = cu.filter(function (p) { return p.r != null && p.ops != null && p.ops > 0; }).map(function (p) { return { time: p.fecha, position: p.r >= 0 ? "belowBar" : "aboveBar", color: p.r >= 0 ? gana : pierde, shape: "circle", size: 0.6 }; });
        if (marcas.length && L.createSeriesMarkers) L.createSeriesMarkers(serie, marcas);
        ch.timeScale().fitContent();

        var ch2 = L.createChart(c2, opciones(130)); charts.push(ch2);
        var s2 = ch2.addSeries(L.AreaSeries, { lineColor: pierde, topColor: rgba(pierde, 0.02), bottomColor: rgba(pierde, 0.35), invertFilledArea: true, lineWidth: 2, priceLineVisible: false, title: "caída" });
        s2.setData(cu.map(function (p) { return { time: p.fecha, value: p.dd }; }));
        var pm = (c.raw.reglas && +c.raw.reglas.perdida_max) || c.perdidaMax;
        if (pm) s2.createPriceLine({ price: -pm, color: bad, lineStyle: 2, lineWidth: 1, axisLabelVisible: true, title: "quema" });
        ch2.timeScale().fitContent();

        /* sincronía: mismo rango visible y misma cruz en los dos */
        var sinc = false;
        function rango(desde, hacia) { desde.timeScale().subscribeVisibleLogicalRangeChange(function (r) { if (sinc || !r) return; sinc = true; hacia.timeScale().setVisibleLogicalRange(r); sinc = false; }); }
        rango(ch, ch2); rango(ch2, ch);
        var porFecha = {}; cu.forEach(function (p) { porFecha[p.fecha] = p; });
        var ultimo = null;
        function fechaDe(t) { return typeof t === "string" ? t : t && t.year ? t.year + "-" + ("0" + t.month).slice(-2) + "-" + ("0" + t.day).slice(-2) : null; }
        var cruz = false;
        function seguir(otro, otraSerie, campo) {
          return function (p) {
            if (cruz) return;
            var f = fechaDe(p.time), q = f && porFecha[f];
            cruz = true;
            try { if (!q) otro.clearCrosshairPosition(); else { if (f !== ultimo) { ultimo = f; det.innerHTML = resumenDia(q, c); if (M.hap) M.hap("s"); } otro.setCrosshairPosition(q[campo], f, otraSerie); } } catch (e) {}
            cruz = false;
          };
        }
        ch.subscribeCrosshairMove(seguir(ch2, s2, "dd"));
        ch2.subscribeCrosshairMove(seguir(ch, serie, "saldo"));
        Array.prototype.forEach.call(raiz.querySelectorAll("[data-rango]"), function (b) {
          b.addEventListener("click", function () {
            Array.prototype.forEach.call(raiz.querySelectorAll("[data-rango]"), function (x) { x.setAttribute("aria-pressed", String(x === b)); });
            var k = +b.getAttribute("data-rango");
            if (!k || k >= cu.length) ch.timeScale().fitContent(); else ch.timeScale().setVisibleLogicalRange({ from: cu.length - k - 0.5, to: cu.length - 0.5 });
            M.hap && M.hap("s");
          });
        });
        [c1, c2].forEach(function (el) { el.classList.add("listo"); });
      }).catch(function (e) { var c1 = raiz.querySelector("#lwc-curva"); if (c1) c1.innerHTML = '<p class="graf-p" style="padding:20px">' + esc(e.message) + "</p>"; });
      return function () { vivo = false; charts.forEach(function (x) { try { x.remove(); } catch (e) {} }); charts = []; };
    }
  };

  function resumenDia(p, c) {
    var piso = p.piso != null ? p.piso : c.raw.piso, margen = piso != null ? p.saldo - piso : null;
    return "<b>" + esc(diaTxt(p.fecha)) + "</b><span>Saldo " + M.usd(p.saldo) + "</span>" +
      (margen != null ? '<span class="' + (margen <= 0 ? "pierde" : "") + '">Margen sobre el piso ' + M.usd(margen) + (p.piso == null ? " (piso de hoy)" : "") + "</span>" : "") +
      (p.r != null ? '<span class="' + (p.r > 0 ? "gana" : p.r < 0 ? "pierde" : "") + '">Día ' + M.usdSigno(p.r) + (p.ops != null ? " · " + p.ops + (p.ops === 1 ? " operación" : " operaciones") : "") + (p.estimado ? " (estimado)" : "") + "</span>" : "") +
      (p.dd < 0 ? '<span>Caída desde el máximo ' + M.usd(p.dd) + "</span>" : "");
  }

  /* Calendario mensual en SVG, con el mejor día marcado. Se navega por mes. */
  function calendario(raiz, cu, c) {
    var cont = raiz.querySelector("#cal"), det = raiz.querySelector("#cal-det");
    var meses = []; cu.forEach(function (p) { var k = p.fecha.slice(0, 7); if (meses.indexOf(k) < 0) meses.push(k); });
    var idx = meses.length - 1, md = M.R.mejorDia(cu), porFecha = {}, maxAbs = 1;
    cu.forEach(function (p) { porFecha[p.fecha] = p; if (p.r != null) maxAbs = Math.max(maxAbs, Math.abs(p.r)); });
    function pintar() {
      var k = meses[idx], y = +k.slice(0, 4), m = +k.slice(5, 7), primero = new Date(y, m - 1, 1), dias = new Date(y, m, 0).getDate(), off = (primero.getDay() + 6) % 7;
      var W = 340, cel = 44, gap = 4, x0 = (W - (7 * cel + 6 * gap)) / 2, filas = Math.ceil((off + dias) / 7), H = 22 + filas * (cel + gap);
      var s = '<div class="cal-cab"><button type="button" class="cal-nav" data-cal="-1" aria-label="Mes anterior"' + (idx ? "" : " disabled") + '>‹</button><b>' + M.mesTxt(k) + '</b><button type="button" class="cal-nav" data-cal="1" aria-label="Mes siguiente"' + (idx < meses.length - 1 ? "" : " disabled") + ">›</button></div>";
      s += '<svg viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="Resultado de cada día de ' + M.mesTxt(k) + '">';
      ["L", "M", "M", "J", "V", "S", "D"].forEach(function (d, i) { s += '<text x="' + (x0 + i * (cel + gap) + cel / 2) + '" y="13" text-anchor="middle" class="cal-dow">' + d + "</text>"; });
      var tot = 0;
      for (var d = 1; d <= dias; d++) {
        var pos = off + d - 1, cx = x0 + (pos % 7) * (cel + gap), cy = 22 + Math.floor(pos / 7) * (cel + gap), f = k + "-" + ("0" + d).slice(-2), p = porFecha[f], r = p && p.r;
        var clase = r == null ? "nada" : r > 0 ? "g" : r < 0 ? "p" : "cero", op = r == null ? 1 : (0.25 + 0.75 * Math.abs(r) / maxAbs).toFixed(2), mejor = md && md.fecha === f;
        if (r != null) tot += r;
        s += '<g class="cal-d ' + clase + (mejor ? " mejor" : "") + '" data-f="' + f + '" tabindex="' + (p ? 0 : -1) + '" role="button" aria-label="' + M.fecha(f) + (r != null ? ": " + M.usdSigno(r) : ": sin datos") + (mejor ? ", mejor día" : "") + '"><rect x="' + cx + '" y="' + cy + '" width="' + cel + '" height="' + cel + '" rx="10" style="opacity:' + (clase === "g" || clase === "p" ? op : 1) + '"/>' + (mejor ? '<rect class="aro" x="' + (cx + 1) + '" y="' + (cy + 1) + '" width="' + (cel - 2) + '" height="' + (cel - 2) + '" rx="9"/>' : "") +
          '<text x="' + (cx + 6) + '" y="' + (cy + 15) + '">' + d + "</text>" + (r != null ? '<text class="m" x="' + (cx + cel - 5) + '" y="' + (cy + cel - 7) + '" text-anchor="end">' + (Math.abs(r) >= 1000 ? M.num(r / 1000, 1) + "k" : M.num(r, 0)) + "</text>" : "") + (mejor ? '<text class="estrella" x="' + (cx + cel - 6) + '" y="' + (cy + 14) + '" text-anchor="end">★</text>' : "") + "</g>";
      }
      s += "</svg>";
      cont.innerHTML = s + '<p class="cal-tot">Total del mes: <b class="' + (tot > 0 ? "gana" : tot < 0 ? "pierde" : "") + '">' + M.usdSigno(Math.round(tot * 100) / 100) + "</b></p>";
    }
    function elegir(gr) {
      var f = gr.getAttribute("data-f"), p = porFecha[f];
      Array.prototype.forEach.call(cont.querySelectorAll(".cal-d.sel"), function (x) { x.classList.remove("sel"); }); gr.classList.add("sel");
      det.innerHTML = p ? resumenDia(p, c) + (md && md.fecha === f ? '<span class="gana">★ Tu mejor día' + (c.resultado > 0 ? ": pesa el " + M.pct(p.r / c.resultado * 100, 0) + " de la ganancia" : "") + "</span>" : "") : "<b>" + esc(diaTxt(f)) + "</b><span>Sin datos (no operaste o no hay cierre).</span>";
      M.hap && M.hap("s");
    }
    cont.addEventListener("click", function (e) {
      var n = e.target.closest("[data-cal]"); if (n) { idx = Math.max(0, Math.min(meses.length - 1, idx + +n.getAttribute("data-cal"))); pintar(); return; }
      var gr = e.target.closest(".cal-d"); if (gr) elegir(gr);
    });
    cont.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { var gr = e.target.closest(".cal-d"); if (gr) { e.preventDefault(); elegir(gr); } } });
    pintar();
  }
})(window);
