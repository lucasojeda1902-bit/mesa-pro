/* Mesa PRO - actualización por aire (lado de la app). Baja mesa-web.json del Apps Script (?k=CLAVE&web=1),
   la verifica con la cáscara (js/arranque.js) y la deja lista para el próximo arranque. */
(function (g) {
  var M = g.Mesa = g.Mesa || {};
  var A = function () { return g.MesaArranque || null; };
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) {} return null; }

  M.ota = {
    disponible: function () { return !!A(); },
    estado: function () { var a = A(); return a ? a.estado() : { fuente: "fabrica", version: null, fabrica: null, shell: null, malas: [] }; },
    /* Busca y baja. Devuelve { estado: "nueva"|"igual"|"mala"|"error", version, mensaje } */
    buscar: function (url, k) {
      var a = A();
      if (!a) return Promise.resolve({ estado: "error", mensaje: "Esta versión no admite actualizaciones por aire." });
      if (!url) return Promise.resolve({ estado: "error", mensaje: "Primero conectá tus datos (URL y clave)." });
      var ctrl = g.AbortController ? new AbortController() : null, to = setTimeout(function () { if (ctrl) ctrl.abort(); }, 20000), texto = null;
      ls("mesa.ota.buscado", String(Date.now()));
      return fetch(url + (url.indexOf("?") > -1 ? "&" : "?") + "k=" + encodeURIComponent(k || "") + "&web=1", { cache: "no-store", signal: ctrl && ctrl.signal })
        .then(function (r) { if (!r.ok) throw new Error("El servidor contestó " + r.status + "."); return r.text(); })
        .then(function (t) {
          texto = t; var j = JSON.parse(t);
          if (j && j.ok === false) throw new Error(j.error === "no_web" ? "Todavía no hay ninguna actualización en tu Drive (mesa-web.json)." : j.error === "clave" ? "La clave no coincide con la del script." : "El script devolvió un error.");
          var e = a.estado(), actual = e.pendiente || e.activa || e.fabrica || "0.0.0";
          if (e.malas.indexOf(j.version) > -1) return { estado: "mala", version: j.version, mensaje: "La versión " + j.version + " ya falló en este celular: no la vuelvo a instalar." };
          if (a.cmpVer(j.version, actual) <= 0) return { estado: "igual", version: actual, mensaje: "Ya tenés la última versión (" + actual + ")." };
          return a.validar(j).then(function (p) { return a.almacen.guardar(p.version, texto).then(function () { return a.programar(p.version); }).then(function () { return { estado: "nueva", version: p.version, mensaje: "Bajé la versión " + p.version + ". Se aplica la próxima vez que abras la app." }; }); });
        })
        .catch(function (e) { return { estado: "error", mensaje: e && e.name === "AbortError" ? "Tardó demasiado." : e instanceof SyntaxError ? "La respuesta no es un archivo de actualización." : (e && e.message) || "No pude buscar la actualización." }; })
        .then(function (r) { clearTimeout(to); return r; });
    },
    fabrica: function () { var a = A(); return a ? a.fabrica() : Promise.resolve(); },
    reiniciar: function () { try { location.reload(); } catch (e) {} },
    /* Busca sola una vez por día (en silencio). */
    tocaBuscar: function () { var t = +ls("mesa.ota.buscado") || 0; return Date.now() - t > 24 * 36e5; }
  };
})(window);
