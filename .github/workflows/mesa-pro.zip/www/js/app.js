/* Mesa PRO - pantallas, datos y gestos. JS puro, sin build. */
(function () {
  "use strict";
  var M = window.Mesa, esc = M.esc;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) {} return null; }
  var reducido = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  var INTERVALO = 15 * 60 * 1000;

  var VERSION_APK = "3.0.0";
  var S = { base: null, data: null, res: null, syncErr: null, fuente: "demo", ultima: null, error: null, cargando: false, tab: 0, f: { tipo: "todos", cat: "", mes: "" }, listo: false, movsVista: [], seg: "movs", dtag: "", rod: {}, kzEdit: false, calc: { instr: "MNQ", stop: "", riesgo: "", com: "" } };
  try { var cg = JSON.parse(localStorage.getItem("mesa.calc")); if (cg && typeof cg === "object") ["instr", "stop", "riesgo", "com"].forEach(function (k) { if (typeof cg[k] === "string") S.calc[k] = cg[k]; }); if (!M.R.INSTR[S.calc.instr]) S.calc.instr = "MNQ"; } catch (e) {}
  var ICO_SUBS = '<path d="M17 3l3 3-3 3M4 11V9a3 3 0 0 1 3-3h13M7 21l-3-3 3-3M20 13v2a3 3 0 0 1-3 3H4"/>';
  var TABS = [
    { id: "hoy", t: "Hoy", i: '<circle cx="12" cy="13" r="7.5"/><path d="M12 9.2V13l2.6 1.7M9.5 2.8h5"/>' },
    { id: "cuentas", t: "Cuentas", i: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 10h18M7 15h4"/>' },
    { id: "diario", t: "Diario", i: '<path d="M6.5 3.5h10a2 2 0 0 1 2 2v13a2 2 0 0 1-2 2h-10z"/><path d="M6.5 3.5v17M10 8.5h5M10 12h5"/>' },
    { id: "plata", t: "Plata", i: '<circle cx="12" cy="12" r="9"/><path d="M14.8 9.4c-.5-.9-1.6-1.4-2.8-1.4-1.6 0-2.7.8-2.7 2 0 2.9 5.6 1.3 5.6 4.1 0 1.2-1.2 2-2.9 2-1.4 0-2.5-.5-3.1-1.5M12 6.3V8m0 8v1.7"/>' },
    { id: "mas", t: "Más", i: '<circle cx="5.5" cy="12" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="18.5" cy="12" r="1.7"/>' }
  ];
  var ICO_GASTO = '<path d="M7 17 17 7M9 7h8v8"/>', ICO_COBRO = '<path d="M17 7 7 17M15 17H7V9"/>';
  var CHEV = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>';
  var OK = '<svg class="ok" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.7 2.7L16 9.8"/></svg>';
  var NO = '<svg class="no" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/></svg>';
  var MAL = '<svg class="mal" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9 9l6 6M15 9l-6 6"/></svg>';
  var PLUS = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>';
  var ICO_PAUSA = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 6v12M15 6v12"/></svg>', ICO_PLAY = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5.5v13l10-6.5z"/></svg>';
  var ICO_EDIT = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20h4L19 9l-4-4L4 16zM13.5 6.5l4 4"/></svg>', ICO_BORRAR = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 7h14M10 7V5h4v2M7 7l1 12h8l1-12M10 11v5M14 11v5"/></svg>';
  var colaOut = M.Cola("mesa.outbox"), colaLocal = M.Cola("mesa.local"), envioT = null;
  var ESTADO_TXT = { ok: "Todo bien", warn: "Mirá esto", bad: "Hacé esto ahora" };

  /* ---------- helpers de vista ---------- */
  function cnt(v, dec, signo) { return '<span data-c="' + v + '" data-d="' + dec + '"' + (signo ? ' data-s="1"' : "") + ">" + (signo && v > 0 ? "+" : "") + M.num(v, dec) + "</span>"; }
  function barra(p, clase, etq, ahora) {
    p = M.clamp(p, 0, 1);
    return '<div class="barra ' + (clase || "") + '" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + Math.round(p * 100) + '" aria-label="' + esc(etq) + '"><i style="--p:' + p.toFixed(4) + '"></i></div>';
  }
  function fila(k, v, h) { return '<div class="fila"><span class="k">' + k + '</span><span class="v">' + v + (h ? '<span class="h">' + h + "</span>" : "") + "</span></div>"; }
  function titulo(peq, t) { return '<header class="titulo"><small>' + esc(peq) + "</small><h1>" + esc(t) + "</h1></header>"; }
  function vacio(txt, btn) { return '<div class="vacio"><p>' + txt + "</p>" + (btn || "") + "</div>"; }
  function skeleton() {
    function l(w, h, m) { return '<div class="sk" style="width:' + w + ";height:" + h + "px;margin-bottom:" + (m || 0) + 'px"></div>'; }
    return '<div class="titulo">' + l("120px", 14, 10) + l("180px", 34) + "</div>" +
      '<div class="card" style="display:flex;gap:18px;align-items:center;padding:22px 20px"><div class="sk" style="width:38px;height:98px;border-radius:999px;flex:none"></div><div style="flex:1">' + l("90px", 14, 12) + l("100%", 20, 8) + l("82%", 20) + "</div></div>" +
      '<div class="card" style="display:grid;grid-template-columns:repeat(3,1fr);gap:18px">' + [1, 2, 3].map(function () { return "<div>" + l("60%", 13, 12) + l("100%", 24, 10) + l("80%", 12) + "</div>"; }).join("") + "</div>" +
      '<div class="card">' + l("50%", 14, 14) + l("65%", 32, 12) + l("100%", 12) + "</div>" +
      '<div class="card">' + l("60%", 14, 14) + l("45%", 32, 12) + l("100%", 12) + "</div>";
  }
  /* línea chica de la curva (sin ejes) para la tarjeta de la cuenta */
  function sparkline(c) {
    var cu = M.R.curva(c).slice(-40), W = 300, H = 44, vs = cu.map(function (p) { return p.saldo; }), mn = Math.min.apply(null, vs), mx = Math.max.apply(null, vs), rg = mx - mn || 1;
    var d = cu.map(function (p, i) { return (i ? "L" : "M") + (i / (cu.length - 1) * W).toFixed(1) + " " + (H - 4 - (p.saldo - mn) / rg * (H - 8)).toFixed(1); }).join(" ");
    var sube = vs[vs.length - 1] >= vs[0];
    return '<svg class="spark ' + (sube ? "sube" : "baja") + '" viewBox="0 0 ' + W + " " + H + '" preserveAspectRatio="none" aria-hidden="true"><path d="' + d + ' L' + W + " " + H + " L0 " + H + 'Z" class="spark-a"/><path d="' + d + '" class="spark-l"/></svg>';
  }
  function ringSvg(p, nivel, grande, z) {
    var r = 44, c = 2 * Math.PI * r, off = c * (1 - M.clamp(p, 0, 1)), ang = (M.clamp(p, 0, 1) * 360).toFixed(1);
    return '<div class="anillo' + (z ? " z2" : "") + (p <= 0 ? " vacio" : "") + '" style="--ang:' + ang + 'deg;--circ:' + c.toFixed(2) + ";--off:" + off.toFixed(2) + ";--c:" + ({ ok: "var(--l-ok)", warn: "var(--l-warn)", bad: "var(--l-bad)" }[nivel] || "var(--acento)") + (grande ? ";width:148px;height:148px" : "") + '"><svg viewBox="0 0 100 100" aria-hidden="true"><circle class="pista-a" cx="50" cy="50" r="' + r + '"/><circle class="arco" cx="50" cy="50" r="' + r + '"/></svg>' + (p > 0 ? '<i class="punta" aria-hidden="true"></i>' : "") + '<div class="anillo-c"><b>' + cnt(Math.round(p * 100), 0) + '%</b><span>del objetivo</span></div></div>';
  }
  function insignia(c) { var n = c.estado === "perdida" ? "bad" : c.estado === "fondeada" ? "ok" : c.estado === "pausada" ? "warn" : ""; return '<span class="insignia ' + n + '">' + esc(M.ESTADOS[c.estado] || c.estado) + "</span>"; }
  function chipOrigen(el) { var man = M.esManual(el); return '<span class="chip-mini ' + (man ? "man" : "auto") + '">' + (man ? "Manual" : "Automática") + "</span>"; }
  function consistencia(c) {
    var max = c.raw.consistencia_max_pct, mejor = c.raw.mejor_dia_pct;
    var h = max != null ? "Ningún día puede pasar el " + max + "% de la ganancia" : "";
    if (mejor != null) return { v: '<span class="' + (max != null && mejor > max ? "pierde" : "gana") + '">' + M.pct(mejor, 0) + "</span>", h: h, ok: max == null || mejor <= max, txt: "Tu mejor día pesa el " + M.pct(mejor, 0) + " de la ganancia (límite " + (max != null ? max + "%" : "sin dato") + ")." };
    return { v: c.resultado > 0 ? "Sin dato" : "Sin ganancia aún", h: h, ok: null, txt: max != null ? "Límite: ningún día puede pasar el " + max + "% de la ganancia. Todavía no hay ganancia para medirlo." : "Sin dato." };
  }

  /* ---------- pantallas ---------- */
  /* ---------- Hoy: tablero antes de la apertura ---------- */
  var INSTRS = ["MNQ", "MYM", "MES", "NQ", "YM", "ES"], NY_TZ = "America/New_York";
  var ICO_KZ = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="3.5"/><path d="M12 1.5v4M12 18.5v4M1.5 12h4M18.5 12h4"/></svg>';
  var ICO_LAPIZ = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20h4L19 9l-4-4L4 16zM13.5 6.5l4 4"/></svg>';
  function cap1(t) { return String(t).replace(/^./, function (c) { return c.toUpperCase(); }); }
  function corteTxt() {
    var gd = S.data && S.data.generado;
    if (S.fuente === "demo") return "corte de los datos de ejemplo";
    if (!gd || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(String(gd))) return "último dato recibido (sin hora de corte)";
    return "cierre del " + M.fecha(String(gd).slice(0, 10)).slice(0, 5) + " a las " + String(gd).slice(11, 16);
  }
  function tope() { return M.R.TOPE_SCRIPTS; }
  function frenadoHoy() { return M.frenadoHoy ? M.frenadoHoy() : null; }
  function rodNum(id, txt) { return '<span class="rod-num" id="' + id + '">' + txt + "</span>"; }

  function vHoy(r) {
    var h = titulo(cap1(M.fechaLarga(M.hoy())), "Hoy"), c = r.principal, fr = frenadoHoy();
    h += '<div class="escena"><section class="t3d heroe" id="heroe" role="status" aria-label="Semáforo: ' + ESTADO_TXT[r.nivel] + '"><div class="sombra3d" aria-hidden="true"></div><div class="cara">' +
      '<div class="heroe-fila"><div class="lente z2" aria-hidden="true"><i></i></div><div class="heroe-txt z3"><p class="sem-estado">' + ESTADO_TXT[r.nivel] + '</p><p class="sem-frase' + (r.frase.length > 90 ? " larga" : "") + '">' + esc(r.frase) + "</p></div></div>" +
      '<div class="heroe-pie z1"><span>' + (S.fuente === "demo" ? "Datos de ejemplo" : "Datos al " + corteTxt()) + "</span>" + (r.masAlertas > 0 ? '<button class="ver-mas" data-act="alertas" type="button">Ver ' + r.masAlertas + (r.masAlertas === 1 ? " aviso más" : " avisos más") + CHEV + "</button>" : "") + '</div><div class="brillo" aria-hidden="true"></div></div></section></div>';
    if (fr) h += '<div class="frenado-banner" role="status"><b>Frenaste por hoy a las ' + esc(fr.hora) + ".</b> Solo te llegan avisos críticos hasta mañana.</div>";
    h += '<section class="card ny" id="ny">' + nyHtml() + "</section>";
    h += perderHtml(c) + ganarHtml(c) + calcHtml(c) + infraHtml(r);
    var neto = r.neto;
    h += '<h2 class="sec">Plata</h2><section class="card tres" aria-label="Resumen de plata"><div><span class="etq">Puesto</span><span class="num">' + cnt(r.puesto, r.puesto >= 1e4 ? 0 : 2) + '</span><span class="nota">lo pagado</span></div>' +
      '<div><span class="etq">Cobrado</span><span class="num gana">' + cnt(r.cobrado, r.cobrado >= 1e4 ? 0 : 2) + '</span><span class="nota">lo cobrado</span></div>' +
      '<div><span class="etq">Neto</span><span class="num ' + (neto > 0 ? "gana" : neto < 0 ? "pierde" : "") + '">' + cnt(neto, Math.abs(neto) >= 1e4 ? 0 : 2, true) + '</span><span class="nota">' + (neto > 0 ? "ganancia" : neto < 0 ? "todavía en rojo" : "a mano") + '</span></div><p class="pie-tres">Montos en dólares (US$) · gasto fijo ' + M.usd(r.gastoMes) + " por mes</p></section>";
    return h + vVenc(r);
  }
  function nyHtml() {
    var ahora = M.ahora(), s = M.R.sesion(ahora);
    if (!s) { S.nyEstado = "x"; return '<p class="t">Apertura de Nueva York</p><p class="p" style="margin-top:6px">Este celular no puede calcular la hora de Nueva York (le falta la información de zonas horarias).</p>'; }
    S.nyEstado = s.estado + s.diaApertura;
    var etq = { antes: "Falta para la apertura de Nueva York", previa: "La apertura es en minutos", sesion: "Sesión de los scripts en curso", cerrado: "Falta para la próxima apertura" }[s.estado];
    var pill = { antes: "Antes de abrir", previa: "Previa", sesion: "En sesión", cerrado: s.motivo ? cap1(s.motivo) : "Cerrado" }[s.estado];
    var h = '<div class="ny-cab"><p class="t">' + etq + '</p><span class="pill ' + (s.estado === "sesion" ? "vivo" : s.estado === "previa" ? "warn" : "") + '">' + pill + "</span></div>";
    h += '<p class="reloj" aria-hidden="true">' + rodNum("ny-reloj", M.R.reloj(s.estado === "sesion" ? s.quedaMs : s.faltaMs)) + '</p><p class="solo-lector" id="ny-lector">' + (s.estado === "sesion" ? "Quedan " : "Faltan ") + M.R.duracion(s.estado === "sesion" ? s.quedaMs : s.faltaMs) + "</p>";
    h += '<p class="p ny-sub">' + (s.estado === "sesion" ? "Hasta las 15:45 de Nueva York (" + s.cierreAR + " en Argentina), cuando terminan los scripts." :
      s.estado === "cerrado" ? "Próxima apertura: " + M.fechaLarga(M.parseISO(s.diaApertura)) + " a las " + s.aperturaAR + " (09:30 en Nueva York)." :
      "Abre a las 09:30 de Nueva York, que hoy son las <b>" + s.aperturaAR + "</b> en Argentina. Los scripts operan hasta las " + s.cierreAR + "." + (s.mediaJornada ? " <b>Media jornada:</b> la bolsa cierra a las 13:00 de Nueva York." : "") + (s.listaVencida ? " Ojo: la lista de feriados de la app terminó en " + M.R.FERIADOS_HASTA + ", hay que actualizarla." : "")) + "</p>";
    if (s.estado === "sesion") { var tot = s.transcurridoMs + s.quedaMs; h += barra(s.transcurridoMs / tot, "ok", "Avance de la sesión").replace('<div class="barra', '<div id="ny-barra" class="barra') + '<div class="barra-eje"><span>' + s.aperturaAR + " abrió</span><span>" + s.cierreAR + " terminan</span></div>"; }
    h += '<div class="ny-hora"><span>Nueva York <b id="ny-hny">' + M.R.horaEn(ahora, NY_TZ) + '</b></span><span>Argentina <b id="ny-har">' + M.R.horaEn(ahora) + "</b></span></div>";
    return h + '<button class="btn kz-btn block" data-act="kz" type="button">' + ICO_KZ + "Entrar en modo Killzone</button>";
  }
  function perderHtml(c) {
    var pp = c && M.R.puedoPerder(c, tope());
    var h = '<section class="card kpi" id="kpi-perder"><p class="t">Cuánto podés perder hoy</p>';
    if (!pp) return h + '<p class="p" style="margin-top:8px">No hay una cuenta activa con piso cargado. Cuando la haya, acá ves cuánto colchón te queda.</p></section>';
    h += '<p class="gran ' + (pp.manda === "perdida" ? "pierde" : "") + '"><small>US$</small>' + rodNum("rod-perder", M.num(pp.valor, 0)) + "</p>";
    h += '<p class="p">' + esc(pp.texto) + "</p>" + barra(c.pctMargen != null ? c.pctMargen : 0, c.nivel, "Colchón que te queda") +
      '<div class="barra-eje"><span>Piso ' + M.usd(c.raw.piso, 0) + "</span><span>Margen " + M.usd(pp.margen) + "</span></div>";
    return h + '<p class="corte">' + esc(c.nombre) + " · saldo " + M.usd(c.raw.saldo) + " al " + corteTxt() + ". Si hoy perdés todo eso, quedás en " + M.usd(c.raw.saldo - pp.valor) + ".</p></section>";
  }
  function ganarHtml(c) {
    var g = c && M.R.puedoGanar(c, M.R.curva(c));
    var pc = g ? Math.round(g.pct * 100) : 40;
    var h = '<section class="card kpi" id="kpi-ganar"><p class="t">Cuánto podés ganar hoy sin romper la consistencia del ' + pc + "%</p>";
    if (!g) return h + '<p class="p" style="margin-top:8px">Sin cuenta activa para calcularlo.</p></section>';
    h += '<p class="gran gana"><small>US$</small>' + rodNum("rod-ganar", M.num(g.techo, 0)) + '</p><p class="p">' + esc(g.texto) + "</p>";
    h += '<div style="margin-top:8px">' + fila("Tu mejor día", g.b != null ? M.usd(g.b) : "Sin dato", g.b != null ? cap1(g.fuenteB) : "Hace falta un cierre por día para saberlo") +
      fila("Consistencia ahora", g.actual == null ? (g.G > 0 ? "Sin dato" : "Sin ganancia aún") : '<span class="' + (g.cumple ? "gana" : "pierde") + '">' + M.pct(g.actual * 100, 0) + "</span>", "Límite " + pc + "% · mejor día ÷ ganancia total") +
      (g.necesario != null && !g.cumple ? fila("Para destrabar", "Ganancia total " + M.usd(g.necesario), "Así tu mejor día queda en el " + pc + "%") : "") + "</div>";
    return h + '<p class="corte">Estimado con la regla del ' + pc + "% y los datos al " + corteTxt() + ". El número oficial lo da FundedNext.</p></section>";
  }
  function calcHtml(c) {
    var k = S.calc;
    var h = '<section class="card calc" id="calc"><p class="t">Calculadora de tamaño</p><p class="p" style="margin:2px 0 12px">Cuántos contratos entran con tu stop y tu riesgo.</p>';
    h += '<div class="seg seg-ins" role="group" aria-label="Instrumento">' + INSTRS.map(function (x) { return '<button type="button" data-act="calc-ins" data-v="' + x + '" aria-pressed="' + (k.instr === x) + '">' + x + "</button>"; }).join("") + "</div>";
    h += '<div class="calc-grid"><label class="campo"><span>Stop (puntos)</span><input id="calc-stop" type="text" inputmode="decimal" autocomplete="off" placeholder="Ej.: 10" value="' + esc(k.stop) + '"></label>' +
      '<label class="campo"><span>Riesgo (US$)</span><input id="calc-riesgo" type="text" inputmode="decimal" autocomplete="off" placeholder="' + esc(riesgoDef(c) != null ? M.num(riesgoDef(c), 0) : "Ej.: 250") + '" value="' + esc(k.riesgo) + '"></label>' +
      '<label class="campo"><span>Comisión (US$)</span><input id="calc-com" type="text" inputmode="decimal" autocomplete="off" placeholder="' + M.num(M.R.INSTR[k.instr].com) + '" value="' + esc(k.com) + '"></label></div>';
    return h + '<div class="calc-res" id="calc-res" aria-live="polite">' + calcRes(c) + '</div><p class="corte">Informativa: la app no manda órdenes. Punto: MNQ US$ 2 · MYM 0,5 · MES 5 · NQ 20 · YM 5 · ES 50. Comisión por contrato, ida y vuelta (la de los minis es estimada).</p></section>';
  }
  function riesgoDef(c) { var pp = c && M.R.puedoPerder(c, tope()); return pp ? pp.valor : null; }
  function calcRes(c) {
    var k = S.calc, rd = riesgoDef(c), riesgo = k.riesgo !== "" ? parseMonto(k.riesgo) : rd;
    var r = M.R.tamano({ instr: k.instr, stop: parseMonto(k.stop), riesgo: riesgo, com: k.com !== "" ? parseMonto(k.com) : null });
    if (!r.ok) return '<p class="calc-vacio">' + esc(r.motivo) + (k.riesgo === "" && rd != null ? " Si no ponés riesgo, uso lo que podés perder hoy (" + M.usd(rd, 0) + ")." : "") + "</p>";
    return '<div class="calc-n"><b>' + r.contratos + "</b><span>" + (r.contratos === 1 ? "contrato" : "contratos") + " de " + k.instr + " como máximo</span></div>" +
      fila("Si pega el stop", '<span class="pierde">−' + M.usd(r.perdida) + "</span>", M.usd(r.porContrato) + " por contrato (" + r.ticks + " ticks + comisión " + M.usd(r.com) + ")") +
      fila("Objetivo 1:2", r.objetivo2 + " puntos", r.contratos ? "Ganarías " + M.usd(r.ganancia2) + " neto" : "") +
      (k.riesgo === "" && rd != null ? '<p class="corte" style="margin-top:4px">Riesgo usado: lo que podés perder hoy (' + M.usd(rd, 0) + ").</p>" : "");
  }
  function infraHtml(r) {
    var it = M.R.infra({ hoy: M.iso(M.hoy()), alertasTv: S.data && S.data.infra && S.data.infra.alertas_tv, recordatorios: M.nativa() ? { activos: ls("mesa.recordatorios") === "1", proximos: r.vencimientos.filter(function (s) { return s.dias <= 7; }).length } : null, generado: S.fuente === "demo" ? null : S.data && S.data.generado, ahora: M.ahora().getTime() });
    return '<section class="card"><p class="t">Estado de la mesa</p><p class="p" style="margin-top:2px">Lo calcula este celular con la fecha de hoy.</p><div class="infra">' + it.map(function (i) {
      return '<div class="infra-it n-' + i.nivel + '"><i aria-hidden="true"></i><div><b>' + esc(i.titulo) + "</b><span>" + esc(i.detalle) + "</span></div><em>" + esc(i.valor) + "</em></div>";
    }).join("") + "</div></section>";
  }
  function tickReloj() {
    var ahora = M.ahora(), s = M.R.sesion(ahora); if (!s) return;
    if (S.tab === 0) {
      var ny = $("#ny");
      if (ny && S.nyEstado !== s.estado + s.diaApertura) { ny.innerHTML = nyHtml(); M.fx.rodillo($("#ny-reloj"), $("#ny-reloj").textContent, false); }
      var el = $("#ny-reloj"), ms = s.estado === "sesion" ? s.quedaMs : s.faltaMs;
      if (el) M.fx.rodillo(el, M.R.reloj(ms));
      var a = $("#ny-hny"), b = $("#ny-har"), br = $("#ny-barra i"), lec = $("#ny-lector");
      if (a) a.textContent = M.R.horaEn(ahora, NY_TZ); if (b) b.textContent = M.R.horaEn(ahora);
      if (lec) lec.textContent = (s.estado === "sesion" ? "Quedan " : "Faltan ") + M.R.duracion(ms);
      if (br && s.estado === "sesion") br.style.setProperty("--p", (s.transcurridoMs / (s.transcurridoMs + s.quedaMs)).toFixed(4));
    }
    if (kzAbierto) { var k = $("#kz-reloj"); if (k) M.fx.rodillo(k, M.R.reloj(s.estado === "sesion" ? s.quedaMs : s.faltaMs)); var e = $("#kz-etq"); if (e) e.textContent = kzEtq(s); }
  }
  /* números con rodillo: solo giran los dígitos que cambiaron desde la última vez */
  function rodar(raiz, primera) {
    $$(".rod-num[id]", raiz).forEach(function (el) {
      var nuevo = el.textContent, prev = S.rod[el.id];
      if (prev != null && prev !== nuevo && !primera) { M.fx.rodillo(el, prev, false); requestAnimationFrame(function () { M.fx.rodillo(el, nuevo); }); }
      else M.fx.rodillo(el, nuevo, !!primera && !reducido);
      S.rod[el.id] = nuevo;
    });
  }

  /* ---------- Modo Killzone ---------- */
  var kzAbierto = false, wake = null;
  var KZ_LISTA = ["Revisé las noticias rojas del día", "Las alertas de órdenes están activas", "Sé cuánto puedo perder hoy", "Sin revancha: si se frena, se frena"];
  function kzLista() { try { var l = JSON.parse(ls("mesa.kz.lista")); if (Array.isArray(l)) return l.filter(function (x) { return typeof x === "string"; }).slice(0, 12); } catch (e) {} return KZ_LISTA.slice(); }
  function kzTildes() { try { var t = JSON.parse(ls("mesa.kz.tildes")); if (t && t.fecha === M.iso(M.hoy()) && Array.isArray(t.ok)) return t.ok; } catch (e) {} return []; }
  function kzEtq(s) { return !s ? "Sin hora de Nueva York" : s.estado === "sesion" ? "Sesión en curso · quedan" : s.estado === "cerrado" ? "Mercado cerrado · próxima apertura en" : "Apertura de Nueva York en"; }
  function kzHtml() {
    var r = S.res, c = r && r.principal, s = M.R.sesion(M.ahora()), pp = c && M.R.puedoPerder(c, tope()), g = c && M.R.puedoGanar(c, M.R.curva(c)), fr = frenadoHoy(), L = kzLista(), T = kzTildes();
    var ms = !s ? 0 : s.estado === "sesion" ? s.quedaMs : s.faltaMs;
    var h = '<div class="kz-top"><span class="kz-tag"><i></i>KILLZONE</span><button class="kz-salir" data-act="kz-cerrar" type="button">Salir</button></div>';
    h += '<p class="kz-etq" id="kz-etq">' + kzEtq(s) + '</p><p class="kz-reloj">' + rodNum("kz-reloj", M.R.reloj(ms)) + "</p>";
    h += '<p class="kz-sub">' + (s ? "Abre " + s.aperturaAR + " · scripts hasta " + s.cierreAR + " (hora de Argentina)" : "") + "</p>";
    h += '<div class="kz-nums"><div><span>Podés perder hoy</span><b>' + (pp ? M.usd(pp.valor, 0) : "—") + '</b></div><div><span>Colchón hasta el piso</span><b>' + (pp ? M.usd(pp.margen, 0) : "—") + '</b></div><div><span>Tope de los scripts</span><b>' + M.usd(tope(), 0) + '</b></div><div><span>Techo de ganancia</span><b class="gana">' + (g ? M.usd(g.techo, 0) : "—") + "</b></div></div>";
    h += '<p class="kz-corte">' + (c ? esc(c.nombre) + " · " : "") + "números al " + corteTxt() + ".</p>";
    h += '<div class="kz-check"><div class="kz-check-cab"><b>Antes de operar</b><button type="button" data-act="kz-editar">' + (S.kzEdit ? "Listo" : "Editar") + "</button></div>";
    if (S.kzEdit) h += L.map(function (t, i) { return '<div class="kz-ed"><input data-kz-i="' + i + '" value="' + esc(t) + '" maxlength="80" aria-label="Paso ' + (i + 1) + '"><button type="button" data-act="kz-quitar" data-i="' + i + '" aria-label="Quitar este paso">×</button></div>'; }).join("") + '<button class="btn sec block" type="button" data-act="kz-sumar">' + PLUS + "Agregar un paso</button>";
    else h += L.map(function (t, i) { var on = T.indexOf(i) > -1; return '<button class="kz-it" type="button" role="checkbox" aria-checked="' + on + '" data-act="kz-check" data-i="' + i + '"><i aria-hidden="true"></i><span>' + esc(t) + "</span></button>"; }).join("") + (L.length ? '<p class="kz-cuenta">' + T.filter(function (i) { return i < L.length; }).length + " de " + L.length + " listos</p>" : "");
    h += "</div>";
    h += fr ? '<div class="kz-frenado"><b>Frenaste por hoy a las ' + esc(fr.hora) + '.</b><span>Los avisos que no son críticos quedan en silencio hasta mañana. Quedó anotado en el Diario.</span><button class="btn sec" type="button" data-act="kz-reanudar">Deshacer</button></div>'
      : '<button class="btn kz-frenar block" type="button" data-act="kz-frenar">Frenar por hoy</button>';
    return h;
  }
  function kzPintar() { var el = $("#kz-in"); if (!el) return; el.innerHTML = kzHtml(); var r = $("#kz-reloj"); if (r) M.fx.rodillo(r, r.textContent, false); }
  function pedirPantalla() { try { if (navigator.wakeLock && kzAbierto && !document.hidden) navigator.wakeLock.request("screen").then(function (w) { wake = w; }).catch(function () {}); } catch (e) {} }
  function kzAbrir() {
    if (!S.res) return;
    if (sheetAbierto) cerrarSheet();
    kzAbierto = true; S.kzEdit = false; kzPintar();
    var k = $("#kz"); k.hidden = false; requestAnimationFrame(function () { k.classList.add("on"); });
    pager.setAttribute("inert", ""); document.body.classList.add("kz-on"); M.fx.activar(null); fabEstado(); M.hap("m"); pedirPantalla();
    setTimeout(function () { var b = $(".kz-salir"); if (b) b.focus({ preventScroll: true }); }, 80);
  }
  function kzCerrar() {
    if (!kzAbierto) return;
    kzAbierto = false; var k = $("#kz"); k.classList.remove("on"); setTimeout(function () { if (!kzAbierto) k.hidden = true; }, 260);
    pager.removeAttribute("inert"); document.body.classList.remove("kz-on"); fabEstado(); activarTilt(); M.hap("l");
    try { if (wake) wake.release(); } catch (e) {} wake = null;
  }
  function kzFrenar() {
    confirmar("¿Frenar por hoy?", "Queda anotado en el Diario y los avisos que no son críticos se silencian hasta mañana. Cerrá las posiciones desde tu plataforma: la app no opera.", "Frenar").then(function (si) {
      if (!si) return;
      var ahora = M.ahora(), f = M.iso(M.hoy()), hora = M.R.horaEn(ahora);
      ls("mesa.frenado", JSON.stringify({ fecha: f, hora: hora }));
      editar("diario", "upsert", "man-frenar-" + f, { fecha: f, texto: "Frené por hoy a las " + hora + ".", etiquetas: ["Frené a tiempo"] });
      kzPintar(); M.runnerConfig(); M.hap("ok"); toast("Listo: frenaste por hoy.");
    });
  }

  /* ---------- Diario: notas por día con etiquetas ---------- */
  var ETIQUETAS = ["Con plan", "Sin plan", "Bien ejecutada", "FOMO", "Revancha", "Noticia", "Error de script", "Frené a tiempo"];
  function vDiario(r) {
    var l = r.diario, n = l.length, hoyISO = M.iso(M.hoy());
    var h = titulo(n ? n + (n === 1 ? " nota" : " notas") : "Tus notas por día", "Diario");
    var deHoy = l.filter(function (x) { return x.fecha === hoyISO; }).length;
    h += '<button class="card tap nota-hoy" data-act="diario-nueva" type="button"><span class="nota-hoy-ico">' + ICO_LAPIZ + "</span><span><b>" + (deHoy ? "Sumar otra nota de hoy" : "Escribí la nota de hoy") + "</b><span>Qué hiciste, cómo te sentiste y qué aprendiste. Con etiquetas para encontrarlo después.</span></span></button>";
    if (!n) return h + vacio("Todavía no hay notas. Las que escribas se guardan en tu Drive como el resto de tus cambios.");
    var tags = {}; l.forEach(function (x) { x.etiquetas.forEach(function (t) { tags[t] = (tags[t] || 0) + 1; }); });
    var orden = Object.keys(tags).sort(function (a, b) { return tags[b] - tags[a] || (a < b ? -1 : 1); });
    if (S.dtag && !tags[S.dtag]) S.dtag = "";
    if (orden.length) h += '<div class="chips-filtro" role="group" aria-label="Filtrar por etiqueta">' + [""].concat(orden).map(function (t) { return '<button type="button" class="chip-f" data-act="diario-tag" data-v="' + esc(t) + '" aria-pressed="' + (S.dtag === t) + '">' + (t ? esc(t) + " <em>" + tags[t] + "</em>" : "Todas") + "</button>"; }).join("") + "</div>";
    var vis = S.dtag ? l.filter(function (x) { return x.etiquetas.indexOf(S.dtag) > -1; }) : l, grupos = [], porF = {};
    vis.forEach(function (x) { if (!porF[x.fecha]) { porF[x.fecha] = []; grupos.push(x.fecha); } porF[x.fecha].push(x); });
    grupos.forEach(function (f) {
      h += '<h2 class="sec">' + cap1(M.fechaLarga(M.parseISO(f))) + (f === hoyISO ? " · hoy" : "") + '</h2><div class="card lista-card">' + porF[f].map(function (x) {
        return '<button class="nota" data-act="diario-ver" data-id="' + esc(x.id) + '" type="button"><p>' + esc(x.texto) + "</p>" + (x.etiquetas.length ? '<span class="chips">' + x.etiquetas.map(function (t) { return '<span class="chip-mini' + (t === "Frené a tiempo" || t === "Bien ejecutada" || t === "Con plan" ? " ok" : t === "FOMO" || t === "Revancha" || t === "Sin plan" ? " mal" : "") + '">' + esc(t) + "</span>"; }).join("") + "</span>" : "") + "</button>";
      }).join("") + "</div>";
    });
    return h;
  }
  function sheetDiario(id) {
    var x = (S.res.diario || []).filter(function (d) { return d.id === id; })[0]; if (!x) return;
    var cu = S.res.cuentas.filter(function (c) { return c.id === x.cuenta_id; })[0];
    var h = '<p class="etq">' + cap1(M.fechaLarga(M.parseISO(x.fecha))) + '</p><p class="nota-full">' + esc(x.texto) + "</p>" +
      (x.etiquetas.length ? '<p class="chips" style="margin-top:12px">' + x.etiquetas.map(function (t) { return '<span class="chip-mini">' + esc(t) + "</span>"; }).join("") + "</p>" : "") +
      (cu ? '<div style="margin-top:10px">' + fila("Cuenta", esc(cu.nombre), esc(cu.login)) + "</div>" : "") +
      '<div class="acciones"><button class="btn sec" data-act="diario-edit" data-id="' + esc(x.id) + '" type="button">' + ICO_EDIT + 'Editar</button><button class="btn sec peligro" data-act="diario-del" data-id="' + esc(x.id) + '" type="button">' + ICO_BORRAR + "Eliminar</button></div>";
    abrirSheet("Nota del diario", h);
  }
  function sheetFormDiario(id) {
    var x = id ? crudo("diario", id) : null, sel = (x && Array.isArray(x.etiquetas) ? x.etiquetas : []).slice();
    var extra = sel.filter(function (t) { return ETIQUETAS.indexOf(t) < 0; });
    var cuentas = (S.res && S.res.cuentas) || [];
    var h = '<form novalidate onsubmit="return false">' + fCampo("fecha", "Día", "date", x ? String(x.fecha).slice(0, 10) : M.iso(M.hoy())) +
      fCampo("texto", "Nota", "area", x ? x.texto : "", { max: 1000, ph: "Ej.: entré con plan, respeté el stop, no hubo revancha." }) +
      '<div class="campo"><span>Etiquetas</span><div class="tags" id="f-tags">' + ETIQUETAS.concat(extra).map(function (t) { return '<button type="button" class="chip-f" data-act="f-tag" data-v="' + esc(t) + '" aria-pressed="' + (sel.indexOf(t) > -1) + '">' + esc(t) + "</button>"; }).join("") + "</div></div>" +
      fCampo("tag-otra", "Otra etiqueta", "text", "", { opc: true, max: 24, ph: "Ej.: Viernes" }) +
      (cuentas.length ? fSelect("cuenta", "Cuenta", [["", "Ninguna"]].concat(cuentas.map(function (c) { return [c.id, c.nombre + " · " + c.id]; })), x ? x.cuenta_id || "" : "", { opc: true }) : "") +
      fPie(x ? "Guardar cambios" : "Guardar nota", "diario-guardar", id || "") + "</form>";
    abrirSheet(x ? "Editar nota" : "Nota del día", h, { alAbrir: function () { if (!x) setTimeout(function () { var i = $("#f-texto"); if (i) i.focus({ preventScroll: true }); }, 380); } });
  }
  function guardarDiario(id) {
    fLimpiar();
    var orig = id ? crudo("diario", id) : null, bad = false;
    var fecha = fVal("fecha"); if (!M.parseISO(fecha)) { fErr("fecha", "Elegí un día."); bad = true; }
    var texto = fVal("texto"); if (!texto) { fErr("texto", "Escribí algo, aunque sea una línea."); bad = true; }
    if (bad) return fFoco();
    var tags = $$("#f-tags [aria-pressed=true]").map(function (b) { return b.dataset.v; }), otra = fVal("tag-otra").slice(0, 24);
    if (otra && tags.indexOf(otra) < 0) tags.push(otra);
    var nuevo = Object.assign({}, orig || {}, { fecha: fecha, texto: texto.slice(0, 1000), etiquetas: tags.slice(0, 12) });
    var cu = $("#f-cuenta") ? $("#f-cuenta").value : ""; if (cu) nuevo.cuenta_id = cu; else if (orig && orig.cuenta_id != null) nuevo.cuenta_id = null;
    guardarElemento("diario", id || M.nuevoId(), nuevo, !id);
    cerrarSheet(); avisoGuardado(id ? "Nota guardada." : "Nota agregada al diario.");
  }

  /* ---------- búsqueda global ---------- */
  function norm(t) { return String(t == null ? "" : t).toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, ""); }
  function sheetBuscar() {
    abrirSheet("Buscar", '<label class="campo buscar-campo"><span class="solo-lector">Qué buscás</span><input id="q" type="search" placeholder="Ej.: Apex, comisión, FOMO" autocomplete="off" enterkeyhint="search"></label><div id="q-res">' + ayudaBuscar() + "</div>",
      { alAbrir: function () { setTimeout(function () { var i = $("#q"); if (i) i.focus({ preventScroll: true }); }, 360); } });
  }
  function ayudaBuscar() { return '<p class="p" style="margin-top:4px">Busca en movimientos, suscripciones, cuentas y notas del diario.</p>'; }
  function buscar(q) {
    var t = norm(q).trim(); if (!S.res) return ""; if (t.length < 2) return ayudaBuscar();
    var palabras = t.split(/\s+/), r = S.res;
    function ok() { var txt = norm(Array.prototype.join.call(arguments, " ")); return palabras.every(function (p) { return txt.indexOf(p) > -1; }); }
    var grupos = [
      ["Movimientos", r.movs.filter(function (m) { return ok(m.descripcion, m.categoria, m.detalle && m.detalle.nota, m.detalle && m.detalle.medio_pago, m.fecha, m.tipo); }).map(function (m) { return movRow(m); })],
      ["Suscripciones", r.subs.filter(function (s) { return ok(s.servicio, s.para_que); }).map(function (s) { return '<button class="res" data-act="sub" data-id="' + esc(s.id) + '" type="button"><b>' + esc(s.servicio) + "</b><span>" + (s.monto != null ? M.usd(s.monto) + " " + (M.FREC_TXT[s.frecuencia] || "") : "Monto a confirmar") + (s.pausada ? " · pausada" : "") + "</span></button>"; })],
      ["Cuentas", r.cuentas.filter(function (c) { return ok(c.nombre, c.id, c.raw.firma, c.raw.tipo, c.nota); }).map(function (c) { return '<button class="res" data-act="cuenta" data-id="' + esc(c.id) + '" type="button"><b>' + esc(c.nombre) + "</b><span>Cuenta " + esc(c.login) + " · saldo " + M.usd(c.raw.saldo) + "</span></button>"; })],
      ["Diario", r.diario.filter(function (x) { return ok(x.texto, x.etiquetas.join(" "), x.fecha); }).map(function (x) { return '<button class="res" data-act="diario-ver" data-id="' + esc(x.id) + '" type="button"><b>' + M.fecha(x.fecha) + "</b><span>" + esc(x.texto.length > 90 ? x.texto.slice(0, 90) + "…" : x.texto) + "</span></button>"; })]
    ].filter(function (g2) { return g2[1].length; });
    if (!grupos.length) return '<p class="p" style="margin-top:4px">No encontré nada con “' + esc(q.trim()) + "”.</p>";
    return grupos.map(function (g2) { return '<h2 class="sec">' + g2[0] + " <em>" + g2[1].length + '</em></h2><div class="card lista-card">' + g2[1].slice(0, 25).join("") + "</div>"; }).join("");
  }
  function sheetMenu() {
    var it = [["diario-nueva", "Nota del diario", ICO_LAPIZ], ["mov-nuevo", "Gasto o cobro", '<svg viewBox="0 0 24 24" aria-hidden="true">' + ICO_GASTO + "</svg>"], ["sub-nueva", "Suscripción", '<svg viewBox="0 0 24 24" aria-hidden="true">' + ICO_SUBS + "</svg>"], ["cuenta-nueva", "Cuenta manual", '<svg viewBox="0 0 24 24" aria-hidden="true">' + TABS[1].i + "</svg>"], ["kz", "Modo Killzone", ICO_KZ]];
    abrirSheet("Agregar", '<div class="menu-grid">' + it.map(function (x) { return '<button class="card tap menu-it" data-act="' + x[0] + '" type="button">' + x[2] + "<b>" + x[1] + "</b></button>"; }).join("") + "</div>");
  }

  function vVenc(r) {
    var h = '<section class="card"><p class="t">Próximos vencimientos</p><p class="p" style="margin-top:2px">Pagos de los próximos 30 días.</p>';
    if (!r.vencimientos.length) h += '<p class="p" style="margin-top:12px">No hay pagos en los próximos 30 días.</p>';
    else h += '<div style="margin-top:6px">' + r.vencimientos.map(function (s) {
      return '<button class="venc" data-act="sub" data-id="' + esc(s.id) + '" type="button"><span class="venc-fecha' + (s.dias <= 3 ? " pronto" : "") + '"><b>' + s.prox.getDate() + "</b>" + M.MESES[s.prox.getMonth()].slice(0, 3) + '</span><span class="venc-txt"><b>' + esc(s.servicio) + "</b><span>" + M.enDias(s.dias).replace(/^./, function (c) { return c.toUpperCase(); }) + '</span></span><span class="venc-monto">' + (s.monto != null ? M.usd(s.monto) : "A confirmar") + "</span></button>";
    }).join("") + "</div>";
    var sinFecha = r.subs.filter(function (s) { return !s.pausada && !s.prox; }).length;
    if (sinFecha) h += '<p class="p" style="margin-top:10px;font-size:13px;font-weight:700;color:var(--alerta)">' + sinFecha + (sinFecha === 1 ? " suscripción no tiene" : " suscripciones no tienen") + " fecha de pago. Cargala para recibir avisos.</p>";
    return h + "</section>";
  }

  function vCuentas(r) {
    var n = r.cuentas.filter(function (c) { return c.activa; }).length;
    var h = titulo(n + (n === 1 ? " cuenta activa" : " cuentas activas"), "Cuentas");
    var btnAgregar = '<button class="btn sec block" data-act="cuenta-nueva" type="button">' + PLUS + "Agregar cuenta manual</button>";
    if (!r.cuentas.length) return h + vacio("Todavía no hay cuentas cargadas. Las de FundedNext aparecen solas; las de otras firmas las agregás a mano.", btnAgregar);
    var heroe = r.principal ? r.principal.id : (r.cuentas[0] && r.cuentas[0].id);
    r.cuentas.slice().sort(function (a, b) { return (b.id === heroe) - (a.id === heroe); }).forEach(function (c) {
      var cons = consistencia(c), d = c.raw.dias_operados, dm = c.raw.dias_minimos, es3d = c.id === heroe;
      h += (es3d ? '<div class="escena">' : "") + '<button class="card tap' + (es3d ? " t3d vidrio cuenta-heroe" : "") + '" data-act="cuenta" data-id="' + esc(c.id) + '" type="button">' + (es3d ? '<div class="sombra3d" aria-hidden="true"></div>' : "") + '<div class="cuenta-top">' + ringSvg(c.progreso, c.activa ? c.nivel : "", false, es3d) +
        '<div class="cuenta-id' + (es3d ? " z3" : "") + '"><h3>' + esc(c.nombre) + '</h3><p class="chips" style="margin-top:10px">' + insignia(c) + chipOrigen(c.raw) + "</p></div></div>" + '<p class="login" style="margin-top:14px">Cuenta ' + esc(c.login) + (c.raw.firma ? " · " + esc(c.raw.firma) : "") + "</p>" + (c.nota ? '<p class="nota-cuenta">' + esc(c.nota) + "</p>" : "") +
        '<p class="saldo' + (es3d ? " z2" : "") + '"><small>Saldo</small>' + M.usd(c.raw.saldo) + "</p>" + (M.R.curva(c).length >= 2 ? sparkline(c) : "") +
        '<div class="grilla">' +
        '<div><span class="k">Piso</span><span class="v">' + M.usd(c.raw.piso, 0) + '</span><span class="h">Si bajás de acá, se pierde</span></div>' +
        '<div><span class="k">Margen</span><span class="v ' + (c.nivel === "ok" ? "" : c.nivel === "warn" ? "alerta" : "pierde") + '">' + M.usd(c.margen) + '</span><span class="h">Lo que podés perder</span></div>' +
        '<div><span class="k">Objetivo</span><span class="v">' + M.usd(c.objSaldo, 0) + '</span><span class="h">Ganar ' + M.usd(c.objGan, 0) + " para aprobar</span></div>" +
        '<div><span class="k">Consistencia</span><span class="v">' + cons.v + '</span><span class="h">' + (c.raw.consistencia_max_pct != null ? "Límite " + c.raw.consistencia_max_pct + "% por día" : "") + "</span></div>" +
        '<div><span class="k">Días operados</span><span class="v">' + (d != null ? d : "Sin dato") + '</span><span class="h">' + (dm != null ? "Mínimo " + dm : "Desde " + M.fecha(c.raw.inicio)) + "</span></div>" +
        '<div><span class="k">Resultado</span><span class="v ' + (c.resultado > 0 ? "gana" : c.resultado < 0 ? "pierde" : "") + '">' + M.usdSigno(c.resultado) + '</span><span class="h">Desde que empezó</span></div></div>' +
        '<span class="ver-mas">Ver gráficos, detalle y qué significa cada cosa' + CHEV + "</span>" + (es3d ? '<div class="brillo" aria-hidden="true"></div>' : "") + "</button>" + (es3d ? "</div>" : "");
    });
    return h + btnAgregar + '<p class="p" style="margin:10px 4px 0;font-size:13px">Las cuentas de otra firma que no sea FundedNext se cargan a mano. Las de FundedNext se actualizan solas.</p>';
  }

  function opcionesMes(movs) { return M.porMes(movs).map(function (m) { return m.k; }); }
  function filtrar(res) {
    var f = S.f;
    return res.movs.filter(function (m) { return (f.tipo === "todos" || (f.tipo === "gastos" ? m.tipo !== "cobro" : m.tipo === "cobro")) && (!f.cat || m.categoria === f.cat) && (!f.mes || m.fecha.slice(0, 7) === f.mes); });
  }
  function movRow(m) {
    var cobro = m.tipo === "cobro";
    return '<button class="mov" data-act="mov" data-id="' + esc(m.id) + '" type="button"><span class="mov-ico ' + (cobro ? "cobro" : "gasto") + '"><svg viewBox="0 0 24 24" aria-hidden="true">' + (cobro ? ICO_COBRO : ICO_GASTO) + '</svg></span><span class="mov-txt"><b>' + esc(m.descripcion) + "</b><span>" + M.fechaCorta(m.fecha) + " · " + esc(m.categoria || "Sin categoría") + (m.origen === "manual" ? " · Manual" : m.origen === "editado" ? " · Editado" : "") + '</span></span><span class="mov-monto ' + (cobro ? "gana" : "") + '">' + (cobro ? "+" : "−") + M.usd(m.monto) + "</span></button>";
  }
  function libro(res) {
    var l = filtrar(res); S.movsVista = l;
    var sum = l.reduce(function (a, m) { return a + (m.tipo === "cobro" ? m.monto : -m.monto); }, 0);
    var h = "";
    if (!res.movs.length) return vacio("Todavía no hay movimientos. Se cargan solos o los agregás vos con el botón +.");
    if (!l.length) return vacio("No hay movimientos con estos filtros.", '<button class="btn sec" data-act="limpiar" type="button">Limpiar filtros</button>');
    h += '<div class="card lista-card">' + l.map(movRow).join("") + "</div>";
    h += '<div class="fila" style="padding:4px 4px 14px"><span class="k">' + l.length + (l.length === 1 ? " movimiento" : " movimientos") + '</span><span class="v ' + (sum > 0 ? "gana" : sum < 0 ? "pierde" : "") + '">' + M.usdSigno(sum) + "</span></div>";
    return h + '<button class="btn sec block" data-act="exportar" type="button"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v11m0 0-4-4m4 4 4-4M5 19h14"/></svg>Exportar a planilla (CSV)</button>';
  }
  function niceMax(v) { var c = [25, 50, 100, 200, 250, 500, 1000, 2000, 2500, 5000, 10000, 20000, 25000, 50000, 100000]; for (var i = 0; i < c.length; i++) if (v <= c[i]) return c[i]; return Math.ceil(v / 1e5) * 1e5; }
  function chartMeses(res) {
    var hoy = M.hoy(), meses = [], i, mm = {};
    M.porMes(res.movs).forEach(function (m) { mm[m.k] = m; });
    for (i = 5; i >= 0; i--) { var d = new Date(hoy.getFullYear(), hoy.getMonth() - i, 1); var k = d.getFullYear() + "-" + (d.getMonth() < 9 ? "0" : "") + (d.getMonth() + 1); meses.push({ k: k, cobro: (mm[k] || {}).cobro || 0, gasto: (mm[k] || {}).gasto || 0 }); }
    var max = niceMax(Math.max.apply(null, meses.map(function (m) { return Math.max(m.cobro, m.gasto); }).concat([1])));
    var W = 340, H = 190, L = 40, R = 6, T = 14, B = 26, pw = W - L - R, ph = H - T - B, gw = pw / 6, bw = 15;
    var s = '<svg viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="Cobros y gastos por mes, últimos seis meses">';
    [0, 0.5, 1].forEach(function (f) { var y = T + ph - ph * f; s += '<line class="grid" x1="' + L + '" x2="' + (W - R) + '" y1="' + y + '" y2="' + y + '"/><text x="' + (L - 8) + '" y="' + (y + 4) + '" text-anchor="end">' + M.num(max * f, 0) + "</text>"; });
    meses.forEach(function (m, j) {
      var cx = L + gw * j + gw / 2, hc = ph * m.cobro / max, hg = ph * m.gasto / max;
      s += '<g class="col" tabindex="0" role="button" data-k="' + m.k + '" data-co="' + m.cobro + '" data-ga="' + m.gasto + '" aria-label="' + M.mesTxt(m.k) + ": cobrado " + M.usd(m.cobro) + ", gastado " + M.usd(m.gasto) + '"><rect class="hit" x="' + (L + gw * j + 2) + '" y="' + T + '" width="' + (gw - 4) + '" height="' + ph + '"/>';
      if (hc > 0) s += '<rect class="b" x="' + (cx - bw - 2) + '" y="' + (T + ph - Math.max(hc, 3)) + '" width="' + bw + '" height="' + Math.max(hc, 3) + '" rx="4.5" fill="var(--c-cobro)"/>';
      if (hg > 0) s += '<rect class="b" x="' + (cx + 2) + '" y="' + (T + ph - Math.max(hg, 3)) + '" width="' + bw + '" height="' + Math.max(hg, 3) + '" rx="4.5" fill="var(--c-gasto)"/>';
      s += '<text x="' + cx + '" y="' + (H - 6) + '" text-anchor="middle">' + M.mesTxt(m.k, true) + "</text></g>";
    });
    return s + '</svg><div class="tip" id="tip" aria-hidden="true"></div>';
  }
  function vPlata(res) {
    var h = titulo(S.seg === "subs" ? "Pagos fijos" : "Libro de movimientos", "Plata");
    h += '<div class="seg seg-plata" role="group" aria-label="Sección de Plata"><button type="button" data-act="seg-plata" data-v="movs" aria-pressed="' + (S.seg !== "subs") + '">Movimientos</button><button type="button" data-act="seg-plata" data-v="subs" aria-pressed="' + (S.seg === "subs") + '">Suscripciones</button></div>';
    if (S.seg === "subs") return h + '<div id="p-subs">' + vSubs(res) + "</div>";
    var cuotas = res.cuotas, ret = cuotas > 0 ? res.cobrado / cuotas : null;
    h += '<section class="card"><p class="t">Retorno sobre lo pagado en cuentas</p><p class="gran">' + (ret != null ? cnt(Math.round(ret * 100), 0) + "%" : "Sin cuotas") + '</p><p class="p">' +
      (ret != null ? "Cobraste " + M.usd(res.cobrado) + " de los " + M.usd(cuotas) + " que pagaste en cuentas de fondeo. " + (res.cobrado >= cuotas ? "Ya recuperaste todo." : "Te faltan " + M.usd(cuotas - res.cobrado) + " para quedar a mano.") : "Todavía no pagaste cuentas de fondeo.") + "</p>" +
      (ret != null ? barra(Math.min(ret, 1), ret >= 1 ? "ok" : "", "Recuperado de lo pagado") : "") + "</section>";
    h += '<h2 class="sec">Cobros y gastos por mes</h2><section class="card"><div class="leyenda"><span><i style="background:var(--c-cobro)"></i>Cobrado</span><span><i style="background:var(--c-gasto)"></i>Gastado</span></div><div class="grafico" id="graf-meses">' + chartMeses(res) + "</div><p class=\"p\" style=\"margin-top:10px;font-size:13px\">Tocá un mes para ver los montos.</p></section>";
    var meses = M.porMes(res.movs);
    if (meses.length) {
      h += '<h2 class="sec">Totales por mes</h2><section class="card"><table class="tabla"><thead><tr><th scope="col">Mes</th><th scope="col">Cobrado</th><th scope="col">Gastado</th><th scope="col">Neto</th></tr></thead><tbody>' +
        meses.map(function (m) { var n = m.cobro - m.gasto; return "<tr><td>" + M.mesTxt(m.k) .replace(/ \d{4}$/, function (a) { return " '" + a.slice(3); }) + "</td><td>" + M.num(m.cobro) + "</td><td>" + M.num(m.gasto) + '</td><td class="' + (n > 0 ? "gana" : n < 0 ? "pierde" : "") + '">' + (n > 0 ? "+" : "") + M.num(n) + "</td></tr>"; }).join("") + "</tbody></table></section>";
      var cats = M.porCategoria(res.movs, "gasto"), tot = cats.reduce(function (a, c) { return a + c.total; }, 0);
      if (cats.length) h += '<h2 class="sec">Gastos por categoría</h2><section class="card">' + cats.map(function (c) { return '<div class="cat"><div class="cat-top"><span>' + esc(c.cat) + "</span><span>" + M.usd(c.total) + " · " + M.pct(c.total / tot * 100, 0) + "</span></div>" + barra(c.total / tot, "", c.cat) + "</div>"; }).join("") + "</section>";
      var cc = M.porCategoria(res.movs, "cobro");
      if (cc.length) h += '<h2 class="sec">Cobros por categoría</h2><section class="card">' + cc.map(function (c) { return '<div class="cat"><div class="cat-top"><span>' + esc(c.cat) + "</span><span>" + M.usd(c.total) + "</span></div></div>"; }).join("") + "</section>";
    }
    var cats2 = {}; res.movs.forEach(function (m) { cats2[m.categoria || ""] = 1; });
    h += '<h2 class="sec">Libro de movimientos</h2><div class="seg" id="seg-tipo" role="group" aria-label="Tipo de movimiento">' +
      [["todos", "Todo"], ["gastos", "Gastos"], ["cobros", "Cobros"]].map(function (t) { return '<button type="button" data-act="tipo" data-v="' + t[0] + '" aria-pressed="' + (S.f.tipo === t[0]) + '">' + t[1] + "</button>"; }).join("") + "</div>" +
      '<div class="filtros"><select data-f="cat" aria-label="Categoría"><option value="">Categoría</option>' + Object.keys(cats2).filter(Boolean).map(function (c) { return '<option value="' + esc(c) + '"' + (S.f.cat === c ? " selected" : "") + ">" + esc(c) + "</option>"; }).join("") + '</select>' +
      '<select data-f="mes" aria-label="Mes"><option value="">Mes</option>' + opcionesMes(res.movs).map(function (k) { return '<option value="' + k + '"' + (S.f.mes === k ? " selected" : "") + ">" + M.mesTxt(k) + "</option>"; }).join("") + "</select></div>" +
      '<div id="libro">' + libro(res) + "</div>";
    return h;
  }

  function vSubs(res) {
    var h = '<p class="sub-res">' + res.subs.length + (res.subs.length === 1 ? " servicio" : " servicios") + (res.pausadas ? " · " + res.pausadas + (res.pausadas === 1 ? " pausada" : " pausadas") : "") + "</p>";
    h += '<section class="card dos"><div><span class="etq">Por mes</span><p class="gran"><small>US$</small>' + cnt(res.gastoMes, 2) + '</p></div><div><span class="etq">Por año</span><p class="gran"><small>US$</small>' + cnt(res.gastoMes * 12, 2) + "</p></div></section>";
    if (res.pausadas) h += '<p class="p" style="margin:-4px 4px 12px;font-size:13px;color:var(--suave)">Las pausadas no suman acá ni te avisan.</p>';
    if (res.sinMonto.length) h += '<p class="p alerta" style="margin:-4px 4px 16px;font-weight:700">Falta confirmar el monto de ' + res.sinMonto.map(function (s) { return esc(s.servicio); }).join(" y ") + ". No está sumado.</p>";
    if (!res.subs.length) return h + vacio("Todavía no hay suscripciones. Agregá la primera con el botón +.");
    var orden = res.subs.slice().sort(function (a, b) { return (a.pausada - b.pausada) || ((a.prox ? a.prox.getTime() : 9e15) - (b.prox ? b.prox.getTime() : 9e15)); });
    orden.forEach(function (s) {
      h += '<button class="card tap sub-card' + (s.pausada ? " pausada" : "") + '" data-act="sub" data-id="' + esc(s.id) + '" type="button"><div class="sub"><div class="sub-ini" aria-hidden="true">' + esc(s.servicio.charAt(0)) + '</div><div class="sub-cuerpo"><h3>' + esc(s.servicio) + '</h3><p class="p" style="margin-top:3px">' + esc(s.para_que || "") + "</p></div>" +
        '<div class="sub-monto">' + (s.monto != null ? M.usd(s.monto) + "<small>" + (M.FREC_TXT[s.frecuencia] || "") + "</small>" : '<span class="alerta">A confirmar</span>') + '</div></div><div class="sub-pie">' +
        (s.pausada ? '<span class="pill pausa">' + ICO_PAUSA + "Pausada</span>" : s.prox ? '<span class="pill' + (s.dias <= 3 ? " warn" : "") + '">Próximo pago ' + M.fecha(s.prox) + " · " + M.enDias(s.dias) + "</span>" : '<span class="pill warn">Fecha de pago a confirmar</span>') +
        (s.monto != null && s.frecuencia !== "mensual" ? '<span class="pill">' + M.usd(s.mensual) + " por mes</span>" : "") + "</div></button>";
    });
    return h;
  }

  function relativo(iso) {
    if (!iso) return "nunca";
    var m = Math.round((Date.now() - new Date(iso).getTime()) / 6e4);
    if (m < 1) return "hace un momento"; if (m < 60) return "hace " + m + (m === 1 ? " minuto" : " minutos");
    var hh = Math.round(m / 60); if (hh < 24) return "hace " + hh + (hh === 1 ? " hora" : " horas");
    return "el " + M.fecha(new Date(iso));
  }
  function relCorto(iso) {
    if (!iso) return "Sin actualizar";
    var m = Math.round((Date.now() - new Date(iso).getTime()) / 6e4);
    if (m < 1) return "Recién"; if (m < 60) return "Hace " + m + " min";
    var hh = Math.round(m / 60); return hh < 24 ? "Hace " + hh + " h" : M.fecha(new Date(iso)).slice(0, 5);
  }
  function vMas() {
    var tema = ls("mesa.tema") || "auto", url = ls("mesa.url") || "", k = ls("mesa.clave") || "";
    var h = titulo("Ajustes, avisos y la app", "Más");
    h += '<section class="card"><p class="t" style="margin-bottom:14px">De dónde salen los datos</p>' +
      '<label class="campo"><span>URL del endpoint</span><input id="in-url" type="url" inputmode="url" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="https://script.google.com/…/exec" value="' + esc(url) + '"><span class="ayuda">La que te da Apps Script al publicar. Si la dejás vacía, se ven datos de ejemplo.</span></label>' +
      '<label class="campo"><span>Clave</span><span class="clave-wrap"><input id="in-clave" type="password" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="La misma que pusiste en CLAVE" value="' + esc(k) + '"><button type="button" data-act="clave" aria-label="Mostrar u ocultar la clave">Ver</button></span></label>' +
      '<button class="btn block" data-act="guardar" type="button">Guardar y actualizar</button></section>';
    h += '<section class="card"><p class="t">Estado</p>' + fila("Datos", S.fuente === "demo" ? "De ejemplo" : "Tuyos (endpoint)") + fila("Última actualización", S.ultima ? relativo(S.ultima) : "nunca", S.ultima ? new Date(S.ultima).toLocaleString("es-AR", { hour12: false }) : "") +
      (S.data && S.data.generado ? fila("Datos generados", new Date(S.data.generado).toLocaleString("es-AR", { hour12: false })) : "") +
      (S.base && S.base.ediciones_version != null ? fila("Cambios guardados en Drive", "Versión " + S.base.ediciones_version) : "") +
      (S.fuente === "demo" ? fila("Tus cambios", "Solo en este celular", colaLocal.items.length + (colaLocal.items.length === 1 ? " cambio" : " cambios") + " en el ejemplo") : fila("Cambios sin enviar", colaOut.pendientes() ? '<span class="alerta">' + colaOut.pendientes() + "</span>" : "Ninguno", S.syncErr ? esc(S.syncErr) : "")) +
      (S.error ? fila("Último error", '<span class="pierde">' + esc(S.error) + "</span>") : "") +
      '<div style="margin-top:12px"><button class="btn sec block" data-act="actualizar" type="button"' + (S.cargando ? " disabled" : "") + '><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 12a8 8 0 1 1-2.6-5.9M20 4v5h-5"/></svg>Actualizar ahora</button></div><p class="p" style="margin-top:10px;font-size:13px">Se actualiza solo al abrir y cada 15 minutos. También podés tirar hacia abajo en cualquier pantalla.</p></section>';
    h += '<section class="card"><p class="t" style="margin-bottom:12px">Tema</p><div class="seg" role="group" aria-label="Tema">' + [["auto", "Automático"], ["claro", "Claro"], ["oscuro", "Oscuro"]].map(function (t) { return '<button type="button" data-act="tema" data-v="' + t[0] + '" aria-pressed="' + (tema === t[0]) + '">' + t[1] + "</button>"; }).join("") + "</div></section>";
    var fm = M.fx.modo(), med = null; try { med = JSON.parse(ls("mesa.fx.medido")); } catch (e) {}
    h += '<section class="card"><p class="t">Efectos 3D y animaciones</p><p class="p" style="margin:4px 0 12px">' + (M.fx.reducido ? "Tu celular pide menos movimiento: los efectos quedan apagados." : "Automático mide tu celular y baja los efectos solo si no llega a 60 cuadros por segundo.") + '</p><div class="seg" role="group" aria-label="Efectos">' +
      [["auto", "Automático"], ["max", "Máximo"], ["ahorro", "Ahorro"]].map(function (t) { return '<button type="button" data-act="fx" data-v="' + t[0] + '" aria-pressed="' + (fm === t[0]) + '">' + t[1] + "</button>"; }).join("") + "</div>" +
      fila("Ahora", { max: "Todo prendido (giroscopio, brillo, rodillos)", bajo: "Bajado solo: 3D solo al tocar", ahorro: "Apagados" }[M.fx.nivel()]) +
      '<button class="btn sec block" data-act="perf" type="button" style="margin-top:10px">Probar rendimiento</button><p class="p" id="perf-res" role="status" style="margin-top:10px;font-size:13px">' + (med ? "Última medición: " + med.fps + " cuadros por segundo, el 95% de los cuadros en menos de " + M.num(med.p95, 1) + " ms." : "") + "</p></section>";
    var pf = M.prefsAviso();
    h += '<section class="card"><p class="t">Notificaciones</p><p class="p" style="margin:6px 0 4px">Elegí de qué querés que te avisemos. Llegan aunque la app esté cerrada.</p><div class="sws">' +
      M.CATS_AVISO.map(function (c) { var on = pf[c.id] !== false; return '<div class="sw-fila"><span class="sw-txt"><b>' + c.t + "</b><span>" + c.d + '</span></span><button class="sw" type="button" role="switch" aria-checked="' + on + '" aria-label="' + esc(c.t) + '" data-act="pref" data-id="' + c.id + '"><i></i></button></div>'; }).join("") + "</div>" +
      '<button class="btn sec block" data-act="avisos" id="btn-avisos" type="button" style="margin-bottom:10px">Activar avisos</button><button class="btn sec block" data-act="probar" type="button">Probar notificación</button><p class="p" id="aviso-estado" style="margin-top:12px;font-size:13px" role="status"></p>' +
      '<p class="p" style="margin-top:6px;font-size:13px">Android los separa en tres canales que podés ajustar en los ajustes del celular: <b>Críticos</b> (suenan siempre), <b>Recordatorios</b> e <b>Información</b>.</p></section>';
    h += '<section class="card"><p class="t">Para que los avisos lleguen a tiempo</p><p class="p" style="margin:6px 0 10px">Mesa PRO revisa tus cuentas en segundo plano cada 30 minutos más o menos, pero Android puede demorarlo cuando ahorra batería. Para que no se atrase:</p><ol class="pasos"><li>Abrí los <b>Ajustes del celular</b> y entrá a <b>Aplicaciones</b>.</li><li>Tocá <b>Mesa PRO</b> y después <b>Batería</b>.</li><li>Elegí <b>Sin restricciones</b> (en algunos celulares dice "No optimizar").</li><li>Si el celular tiene un modo de ahorro fuerte, dejá a Mesa PRO fuera de la lista de apps que se cierran.</li></ol></section>';
    var bioOn = ls("mesa.bio") === "1", bioOk = bioDisponible();
    h += '<section class="card"><p class="t">Privacidad</p><div class="sws"><div class="sw-fila"><span class="sw-txt"><b>Pedir huella al abrir</b><span>' + (bioOk ? "Al abrir y al volver después de 1 minuto. Si no tenés huella, usa el bloqueo del celular (PIN o patrón)." : "Solo en la app instalada en el celular.") + '</span></span><button class="sw" type="button" role="switch" aria-checked="' + (bioOn && bioOk) + '" aria-label="Pedir huella al abrir" data-act="bio"' + (bioOk ? "" : " disabled") + '><i></i></button></div></div><p class="p" style="font-size:13px">Cuando la app pasa a segundo plano se tapa la pantalla, así la vista de apps recientes no muestra tus saldos.</p></section>';
    var o = M.ota.estado();
    h += '<section class="card" id="ota"><p class="t">Versión y actualizaciones</p>' + fila("App instalada (APK)", "Mesa PRO " + VERSION_APK, "ar.lucas.mesapro") +
      fila("Pantallas y lógica", o.version ? (o.fuente === "ota" ? o.version + " · por aire" : o.version + " · de fábrica") : "De fábrica") +
      (o.pendiente ? fila("Lista para aplicar", '<span class="gana">' + esc(o.pendiente) + "</span>", "Se aplica la próxima vez que abras la app") : "") +
      (o.motivo ? '<p class="nota-local" style="margin:8px 0 4px">' + esc(o.motivo) + "</p>" : "") +
      '<p class="p" style="margin:8px 0 12px;font-size:13px">Las mejoras de pantallas y cálculos llegan por aire desde tu Drive (archivo mesa-web.json), sin reinstalar. Si una versión nueva no arranca bien, la app vuelve sola a la de fábrica.</p>' +
      '<div class="acciones" style="margin-top:0">' + (o.pendiente ? '<button class="btn" data-act="ota-reiniciar" type="button">Aplicar ahora</button>' : '<button class="btn sec" data-act="ota-buscar" type="button">Buscar actualización</button>') +
      '<button class="btn sec" data-act="ota-fabrica" type="button"' + (o.fuente === "ota" || o.pendiente ? "" : " disabled") + ">Volver a la de fábrica</button></div><p class=\"p\" id=\"ota-res\" role=\"status\" style=\"margin-top:10px;font-size:13px\"></p></section>";
    h += '<section class="card" id="acerca"><p class="t">Acerca de</p>' + fila("Mesa PRO", VERSION_APK, "Hecha para Lucas") +
      '<p class="p" style="margin:10px 0 6px;font-size:13.5px">Gráficos: <b>TradingView Lightweight Charts™ 5.0.9</b>, © TradingView, Inc., licencia Apache 2.0. Más información en <a href="https://www.tradingview.com/" target="_blank" rel="noopener">tradingview.com</a>.</p>' +
      '<p class="p" style="font-size:13.5px">Tipografías Manrope y Bricolage Grotesque (licencia SIL Open Font).</p><button class="btn sec block" data-act="licencia" type="button" style="margin-top:12px">Ver licencia de los gráficos</button></section>';
    return h;
  }

  /* ---------- render ---------- */
  function vError(msg) { return titulo("Sin datos", "Ups") + vacio("No pude mostrar los datos. " + esc(msg) + " Si cambiaste la URL o la clave, revisalas en Más.", '<div style="display:grid;gap:10px;justify-items:center"><button class="btn" data-act="actualizar" type="button">Reintentar</button><button class="btn sec" data-act="tab" data-i="4" type="button">Ir a Más</button></div>'); }
  function banner() { return S.fuente === "demo" ? '<button class="banner-demo" data-act="tab" data-i="4" type="button">Estos son datos de ejemplo. Conectá los tuyos en Más.</button>' : ""; }
  function render() {
    try { pintar(); }
    catch (e) {
      S.renderFallo = true;
      S.res = null; S.error = "El archivo tiene un dato mal formado.";
      try { ["hoy", "cuentas", "diario", "plata"].forEach(function (k) { $("#p-" + k + " .contenido").innerHTML = vError(S.error); }); $("#p-mas .contenido").innerHTML = vMas(); document.body.setAttribute("data-nivel", "bad"); } catch (e2) {}
      estadoChip();
    }
  }
  function pintar() {
    var panels = { hoy: $("#p-hoy .contenido"), cuentas: $("#p-cuentas .contenido"), diario: $("#p-diario .contenido"), plata: $("#p-plata .contenido"), mas: $("#p-mas .contenido") };
    if (S.data) {
      S.res = M.resumen(S.data, M.hoy(), S.fuente === "demo");
      var bn = banner(); panels.hoy.innerHTML = bn + vHoy(S.res); panels.cuentas.innerHTML = bn + vCuentas(S.res); panels.diario.innerHTML = bn + vDiario(S.res); panels.plata.innerHTML = bn + vPlata(S.res);
      document.body.setAttribute("data-nivel", S.res.nivel);
    } else {
      document.body.setAttribute("data-nivel", S.error ? "bad" : "none");
      ["hoy", "cuentas", "diario", "plata"].forEach(function (k) { panels[k].innerHTML = S.error ? vError(S.error) : skeleton(); });
    }
    panels.mas.innerHTML = vMas();
    estadoChip(); pintarAvisosBtn(); chipSync(); fabEstado(); estadoRunner();
    $$(".panel").forEach(function (p, i) { if (S.listo && (p.classList.contains("vivo") || i === S.tab)) { p.classList.add("vivo"); rodar(p, false); } });
    activarTilt();
    if (kzAbierto) kzPintar();
  }
  function activarTilt() { M.fx.activar(sheetAbierto || kzAbierto ? null : $(".t3d", panelAct())); }
  function chipSync() {
    var el = $("#chip-sync"); if (!el) return;
    var n = S.fuente === "demo" ? 0 : colaOut.pendientes();
    el.hidden = !n; el.classList.toggle("error", !!(n && S.syncErr)); document.body.classList.toggle("hay-sync", !!n);
    if (n) { $("#chip-sync-txt").textContent = "Sin sincronizar (" + n + ")"; el.setAttribute("aria-label", "Sin sincronizar, " + n + (n === 1 ? " cambio" : " cambios") + ". Tocá para enviar ahora."); }
  }
  function fabEstado() {
    var f = $("#fab"); if (!f) return;
    var ver = !!S.data && !sheetAbierto && !kzAbierto;
    f.classList.toggle("on", ver); f.tabIndex = ver ? 0 : -1; document.body.classList.toggle("fab-on", ver);
    f.setAttribute("aria-label", S.tab === 2 ? "Nueva nota del diario" : S.tab === 3 ? (S.seg === "subs" ? "Agregar suscripción" : "Agregar movimiento") : "Agregar");
  }
  function estadoChip() {
    var chip = $("#chip"), tx = $("#chip-txt"), c = "chip-estado", t;
    if (S.cargando) { c += " cargando"; t = "Actualizando…"; }
    else if (S.error && !S.data) { c += " error"; t = "Sin datos"; }
    else if (S.fuente === "demo") { c += " ejemplo"; t = "Datos de ejemplo"; }
    else if (S.error) { c += " error"; t = "Sin conexión · " + relativo(S.ultima); }
    else t = relCorto(S.ultima);
    chip.className = c; tx.textContent = t;
    chip.setAttribute("aria-label", (S.fuente === "demo" || S.error || S.cargando ? t : "Actualizado " + relativo(S.ultima)) + (S.fuente === "demo" ? ". Tocá para conectar tus datos." : ". Tocá para actualizar."));
  }

  /* ---------- animaciones ---------- */
  function animar(raiz) {
    $$("[data-c]", raiz).forEach(function (el) {
      var to = +el.getAttribute("data-c"), dec = +el.getAttribute("data-d"), sg = el.hasAttribute("data-s");
      if (reducido || !isFinite(to) || to === 0) return;
      var t0 = null, dur = 1000;
      (function paso(t) {
        if (t0 == null) t0 = t;
        var p = M.clamp((t - t0) / dur, 0, 1), e = 1 - Math.pow(1 - p, 4), v = to * e;
        el.textContent = (sg && to > 0 ? "+" : "") + M.num(p === 1 ? to : v, dec);
        if (p < 1) requestAnimationFrame(paso);
      })(performance.now());
    });
  }
  function activarPanel(i) {
    var p = $$(".panel")[i];
    if (p.dataset.visto) return;
    p.dataset.visto = "1";
    animar(p); rodar(p, true);
    requestAnimationFrame(function () { requestAnimationFrame(function () { p.classList.add("vivo"); }); });
  }

  /* ---------- pager / tabs ---------- */
  var pager = $("#pager"), pista = $("#pista"), tabsEl = $("#tabs"), ind;
  function W() { return pager.clientWidth; }
  function setX(px) { pista.style.transform = "translate3d(" + px + "px,0,0)"; }
  function setInd(frac) { if (ind) ind.style.transform = "translate3d(" + (frac * 100) + "%,0,0)"; }
  function irA(i, quieto) {
    i = M.clamp(i, 0, 4);
    var cambio = i !== S.tab;
    S.tab = i;
    pista.classList.remove("arrastrando");
    setX(-i * W()); setInd(i);
    $$(".tab").forEach(function (b, j) { if (j === i) b.setAttribute("aria-current", "page"); else b.removeAttribute("aria-current"); });
    $$(".panel").forEach(function (p, j) { if (j === i) { p.removeAttribute("inert"); p.removeAttribute("aria-hidden"); } else { p.setAttribute("inert", ""); p.setAttribute("aria-hidden", "true"); } });
    if (cambio && !quieto) M.hap("s");
    if (S.listo) activarPanel(i);
    fabEstado(); if (i === 4) estadoRunner();
    activarTilt(); if (i === 0) tickReloj();
  }
  tabsEl.innerHTML = '<div class="tab-ind" id="tab-ind"><i></i></div>' + TABS.map(function (t, i) { return '<button class="tab" type="button" data-act="tab" data-i="' + i + '"><svg viewBox="0 0 24 24" aria-hidden="true">' + t.i + "</svg><span>" + t.t + "</span></button>"; }).join("");
  ind = $("#tab-ind");

  var g = null, ptr = $("#ptr"), refrescando = false;
  function panelAct() { return $$(".panel")[S.tab]; }
  pager.addEventListener("touchstart", function (e) {
    if (sheetAbierto || kzAbierto || e.touches.length > 1 || refrescando) { g = null; return; }
    var t = e.touches[0]; g = { x: t.clientX, y: t.clientY, t0: Date.now(), eje: null, dx: 0, pull: 0, top: panelAct().scrollTop <= 0 };
  }, { passive: true });
  pager.addEventListener("touchmove", function (e) {
    if (!g) return;
    var t = e.touches[0], dx = t.clientX - g.x, dy = t.clientY - g.y;
    if (!g.eje) {
      if (Math.abs(dx) > 10 && Math.abs(dx) > Math.abs(dy) * 1.3) { g.eje = "h"; pista.classList.add("arrastrando"); }
      else if (Math.abs(dy) > 10) g.eje = "v";
      else return;
    }
    if (g.eje === "h") {
      var off = dx; if ((S.tab === 0 && dx > 0) || (S.tab === 4 && dx < 0)) off = dx / 3;
      g.dx = off; setX(-S.tab * W() + off); setInd(S.tab - off / W());
    } else if (g.top && dy > 0 && panelAct().scrollTop <= 0) {
      var pull = Math.min(dy * 0.5, 110), c = $(".contenido", panelAct());
      g.pull = pull; c.classList.remove("vuelve"); c.style.transform = "translate3d(0," + pull + "px,0)";
      ptr.style.opacity = Math.min(pull / 56, 1); ptr.style.transform = "translate3d(0," + (pull - 52) + "px,0) rotate(" + (pull * 4) + "deg)";
    }
  }, { passive: true });
  function finGesto() {
    if (!g) return;
    var q = g; g = null;
    if (q.eje === "h") {
      var v = q.dx / Math.max(1, Date.now() - q.t0), n = S.tab;
      if (q.dx < -W() * 0.2 || v < -0.45) n++; else if (q.dx > W() * 0.2 || v > 0.45) n--;
      irA(n, true); if (n !== S.tab || true) { if (Math.abs(q.dx) > 30) M.hap("s"); }
    } else if (q.eje === "v" && q.pull) {
      var c = $(".contenido", panelAct()); c.classList.add("vuelve");
      if (q.pull >= 62) { M.hap("m"); c.style.transform = "translate3d(0,58px,0)"; ptr.style.transform = "translate3d(0,6px,0)"; ptr.classList.add("girando"); refrescando = true; actualizar(true).then(function () { refrescando = false; ptr.classList.remove("girando"); c.style.transform = ""; ptr.style.opacity = 0; ptr.style.transform = "translate3d(0,-60px,0)"; }); }
      else { c.style.transform = ""; ptr.style.opacity = 0; ptr.style.transform = "translate3d(0,-60px,0)"; }
    }
  }
  pager.addEventListener("touchend", finGesto, { passive: true });
  pager.addEventListener("touchcancel", finGesto, { passive: true });
  window.addEventListener("resize", function () { pista.classList.add("arrastrando"); setX(-S.tab * W()); requestAnimationFrame(function () { pista.classList.remove("arrastrando"); }); });

  /* ---------- sheet ---------- */
  var sheet = $("#sheet"), velo = $("#velo"), sCuerpo = $("#sheet-b"), sheetAbierto = false, foco = null, histPush = false, sLimpiar = null;
  function limpiarSheet() { if (sLimpiar) { try { sLimpiar(); } catch (e) {} sLimpiar = null; } }
  function abrirSheet(titulo, html, opts) {
    limpiarSheet();
    if (sheetAbierto) { /* ya hay una hoja abierta (ej. de detalle a formulario): solo cambia el contenido */
      $("#sheet-t").textContent = titulo; sCuerpo.innerHTML = html; sCuerpo.scrollTop = 0; sCuerpo.classList.add("vivo"); animar(sCuerpo); M.hap("l");
      if (opts && opts.alAbrir) sLimpiar = opts.alAbrir(sCuerpo) || null;
      return;
    }
    document.body.classList.add("sheet-on"); M.fx.activar(null);
    foco = document.activeElement; $("#sheet-t").textContent = titulo; sCuerpo.innerHTML = html; sCuerpo.scrollTop = 0; sCuerpo.classList.remove("vivo");
    sheet.style.transform = ""; sheet.classList.remove("arrastrando"); sheetAbierto = true; fabEstado();
    requestAnimationFrame(function () { sheet.classList.add("on"); velo.classList.add("on"); requestAnimationFrame(function () { sCuerpo.classList.add("vivo"); animar(sCuerpo); }); });
    try { history.pushState({ sheet: 1 }, ""); histPush = true; } catch (e) {}
    pager.setAttribute("inert", ""); M.hap("l");
    setTimeout(function () { $("#sheet-x").focus({ preventScroll: true }); }, 60);
    if (opts && opts.alAbrir) sLimpiar = opts.alAbrir(sCuerpo) || null;
  }
  function cerrarSheet(desdeHistoria) {
    if (!sheetAbierto) return;
    sheetAbierto = false; limpiarSheet(); document.body.classList.remove("sheet-on"); activarTilt(); sheet.classList.remove("arrastrando"); sheet.style.transform = ""; sheet.classList.remove("on"); velo.classList.remove("on"); velo.style.opacity = "";
    pager.removeAttribute("inert"); fabEstado();
    if (histPush && !desdeHistoria) { histPush = false; try { history.back(); } catch (e) {} } else histPush = false;
    if (foco && foco.focus) try { foco.focus({ preventScroll: true }); } catch (e) {}
    M.hap("l");
  }
  window.addEventListener("popstate", function () { if (sheetAbierto) { histPush = false; cerrarSheet(true); } });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") { if (sheetAbierto) cerrarSheet(); else if (kzAbierto) kzCerrar(); } });
  velo.addEventListener("click", function () { cerrarSheet(); });
  $("#sheet-x").addEventListener("click", function () { cerrarSheet(); });
  (function () {
    var d = null;
    sheet.addEventListener("touchstart", function (e) {
      if (e.target.closest(".lwc")) { d = null; return; } /* el gráfico usa el dedo para sí */
      var t = e.touches[0], enCab = !!e.target.closest("#sheet-cab");
      d = { y: t.clientY, t0: Date.now(), cab: enCab, arr: false, dy: 0 };
    }, { passive: true });
    sheet.addEventListener("touchmove", function (e) {
      if (!d) return;
      var dy = e.touches[0].clientY - d.y;
      if (!d.arr) { if (dy > 8 && (d.cab || sCuerpo.scrollTop <= 0)) { d.arr = true; d.y = e.touches[0].clientY; dy = 0; sheet.classList.add("arrastrando"); } else return; }
      dy = Math.max(0, dy); d.dy = dy; sheet.style.transform = "translate3d(0," + dy + "px,0)"; velo.style.opacity = String(Math.max(0, 1 - dy / 420));
    }, { passive: true });
    function fin() {
      if (!d) return; var q = d; d = null;
      if (!q.arr) return;
      var v = q.dy / Math.max(1, Date.now() - q.t0);
      if (q.dy > 110 || v > 0.6) cerrarSheet();
      else { sheet.classList.remove("arrastrando"); sheet.style.transform = ""; velo.style.opacity = ""; }
    }
    sheet.addEventListener("touchend", fin, { passive: true }); sheet.addEventListener("touchcancel", fin, { passive: true });
  })();

  function sheetCuenta(id) {
    var c = S.res.cuentas.filter(function (x) { return x.id === id; })[0]; if (!c) return;
    var cons = consistencia(c), d = c.raw.dias_operados, dm = c.raw.dias_minimos;
    var h = '<div class="cuenta-top">' + ringSvg(c.progreso, "", false) + '<div class="cuenta-id">' + insignia(c) + '<p class="etq" style="margin-top:14px">Resultado</p><p class="num ' + (c.resultado > 0 ? "gana" : c.resultado < 0 ? "pierde" : "") + '" style="font-size:21px">' + M.usdSigno(c.resultado) + '</p></div></div><p class="saldo"><small>Saldo</small>' + M.usd(c.raw.saldo) + '</p><p class="login" style="margin-top:6px">Cuenta ' + esc(c.login) + (c.raw.firma ? " · " + esc(c.raw.firma) : "") + '</p><p class="chips" style="margin-top:10px">' + chipOrigen(c.raw) + "</p>" + (c.nota ? '<p class="nota-cuenta" style="margin-top:12px">' + esc(c.nota) + "</p>" : "");
    h += '<h2 class="sec">Curva de saldo <span class="sec-h">(con piso y objetivo)</span></h2><div class="graf" id="graf-cuenta">' + M.graf.html(c) + "</div>";
    h += '<h2 class="sec">Cómo vas con las reglas</h2><div>' +
      '<div class="check">' + (c.margen > 0 ? OK : MAL) + "<div><b>Piso de " + M.usd(c.raw.piso, 0) + "</b><br><span class=\"suave\">" + (c.margen > 0 ? "Estás " + M.usd(c.margen) + " arriba. Te queda el " + M.pct((c.pctMargen || 0) * 100, 0) + " del colchón." : "Tocaste el piso: la cuenta se pierde.") + "</span></div></div>" +
      '<div class="check">' + (c.llegoObjetivo ? OK : NO) + "<div><b>Objetivo de " + M.usd(c.objSaldo, 0) + "</b><br><span class=\"suave\">" + (c.llegoObjetivo ? "Lo alcanzaste." : "Faltan " + M.usd(c.falta) + " para aprobar.") + "</span></div></div>" +
      '<div class="check">' + (cons.ok === true ? OK : cons.ok === false ? MAL : NO) + "<div><b>Consistencia</b><br><span class=\"suave\">" + cons.txt + "</span></div></div>" +
      (dm != null ? '<div class="check">' + (d != null && d >= dm ? OK : NO) + "<div><b>Días operados</b><br><span class=\"suave\">" + (d != null ? d : "Sin dato") + " de " + dm + " mínimos.</span></div></div>" : "") + "</div>";
    h += '<h2 class="sec">Qué significa cada cosa</h2><div class="glosario">' +
      fila("Saldo", "La plata que hay hoy en la cuenta.") + fila("Piso", "El saldo mínimo. Si bajás de ahí, se pierde la cuenta (se llama pérdida máxima).") + fila("Margen", "Cuánto te queda por perder antes de llegar al piso.") +
      fila("Objetivo", "El saldo que hay que alcanzar para aprobar la evaluación.") + fila("Consistencia", "Regla que evita que un solo día explique casi toda la ganancia.") + fila("Días operados", "Días en que hiciste al menos una operación.") + "</div>";
    if (c.payout) h += payoutHtml(c);
    h += '<div class="acciones"><button class="btn sec" data-act="cuenta-edit" data-id="' + esc(c.id) + '" type="button">' + ICO_EDIT + (c.manual ? "Editar cuenta" : (c.nota ? "Editar nota" : "Agregar una nota")) + "</button>" +
      (c.manual ? '<button class="btn sec peligro" data-act="cuenta-del" data-id="' + esc(c.id) + '" type="button">' + ICO_BORRAR + "Eliminar</button>" : "") + "</div>" +
      (c.manual ? "" : '<p class="p" style="margin-top:10px;font-size:13px">Los números de esta cuenta vienen solos de FundedNext y no se pueden cambiar a mano. Sí podés dejar una nota.</p>');
    abrirSheet(c.nombre, h, { alAbrir: function (b) { var gr = $("#graf-cuenta", b); return gr ? M.graf.montar(gr, c) : null; } });
  }
  function sheetMov(id) {
    var m = S.res.movs.filter(function (x) { return x.id === id; })[0]; if (!m) return;
    var cobro = m.tipo === "cobro", d = m.detalle || {}, cu = S.res.cuentas.filter(function (c) { return c.id === m.cuenta_id; })[0];
    var h = '<p class="etq">' + (cobro ? "Cobraste" : "Pagaste") + '</p><p class="gran ' + (cobro ? "gana" : "") + '" style="font-size:40px">' + (cobro ? "+" : "−") + M.usd(m.monto) + "</p>" +
      '<div style="margin-top:8px">' + fila("Fecha", M.fecha(m.fecha)) + fila("Tipo", cobro ? "Cobro" : "Gasto") + fila("Categoría", esc(m.categoria || "Sin categoría")) + (cu ? fila("Cuenta", esc(cu.nombre), esc(cu.login)) : "") +
      (d.precio_lista != null ? fila("Precio de lista", M.usd(d.precio_lista)) : "") + (d.descuento != null ? fila("Descuento", M.usd(d.descuento), d.precio_lista ? "Ahorraste el " + M.pct(d.descuento / d.precio_lista * 100, 0) : "") : "") +
      (d.medio_pago ? fila("Medio de pago", esc(d.medio_pago)) : "") + (d.nota ? fila("Nota", esc(d.nota)) : "") + (m.origen ? fila("Origen", m.origen === "manual" ? "Cargado a mano" : "Editado a mano") : "") + "</div>" +
      '<div class="acciones"><button class="btn sec" data-act="mov-edit" data-id="' + esc(m.id) + '" type="button">' + ICO_EDIT + 'Editar</button><button class="btn sec peligro" data-act="mov-del" data-id="' + esc(m.id) + '" type="button">' + ICO_BORRAR + "Eliminar</button></div>";
    abrirSheet(m.descripcion, h);
  }
  function sheetAlertas() {
    var h = S.res.alertas.map(function (a) { var n = a.nivel; return '<div class="check">' + (n === "bad" ? MAL : n === "warn" ? '<svg class="no" style="stroke:var(--alerta)" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4 3 20h18z"/><path d="M12 10v4M12 17v.5"/></svg>' : OK) + "<div><b>" + ESTADO_TXT[n] + "</b><br><span class=\"suave\">" + esc(a.texto) + "</span></div></div>"; }).join("");
    abrirSheet("Avisos", h || vacio("No hay avisos."));
  }
  function sheetExportar() {
    var n = S.movsVista.length;
    abrirSheet("Exportar a planilla", '<p class="p" style="margin-bottom:18px">Se exportan los ' + n + (n === 1 ? " movimiento" : " movimientos") + ' que ves ahora. Es un archivo CSV: se abre en Google Sheets y en Excel, con coma para los decimales.</p><div style="display:grid;gap:12px"><button class="btn block" data-act="compartir" type="button">Guardar o compartir el archivo</button><button class="btn sec block" data-act="copiar" type="button">Copiar para pegar en la planilla</button></div>');
  }
  function csvActual() { return M.csv(S.movsVista, S.res.cuentas); }
  function compartir() {
    var csv = csvActual(), nombre = "mesa-movimientos-" + M.iso(M.hoy()) + ".csv", P = window.Capacitor && Capacitor.Plugins;
    if (P && P.Filesystem && P.Share) {
      P.Filesystem.writeFile({ path: nombre, data: csv, directory: "CACHE", encoding: "utf8" }).then(function (r) { return P.Share.share({ title: "Movimientos Mesa PRO", url: r.uri, dialogTitle: "Guardar o enviar" }); }).catch(function (e) { if (!/cancel/i.test(String(e && e.message))) toast("No pude armar el archivo. Probá con Copiar."); });
      return;
    }
    var a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" })); a.download = nombre; document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); toast("Archivo listo"); M.hap("ok");
  }
  function copiar() {
    var csv = csvActual().replace(/^﻿/, "");
    function listo() { toast("Copiado. Pegalo en tu planilla."); M.hap("ok"); }
    function viejo() { var t = document.createElement("textarea"); t.value = csv; t.style.cssText = "position:fixed;opacity:0"; document.body.appendChild(t); t.select(); try { document.execCommand("copy"); listo(); } catch (e) { toast("No pude copiar."); } t.remove(); }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(csv).then(listo, viejo); else viejo();
  }

  /* tooltip del grafico de barras */
  function tooltipMeses() {
    var cont = $("#graf-meses"); if (!cont) return;
    var tip = $("#tip", cont);
    function mostrar(col) {
      $$("g.col", cont).forEach(function (x) { x.classList.toggle("sel", x === col); });
      var r = cont.getBoundingClientRect(), b = col.querySelector(".hit").getBoundingClientRect();
      tip.innerHTML = "<b>" + M.mesTxt(col.dataset.k) + '</b><i style="background:var(--c-cobro)"></i>Cobrado ' + M.usd(+col.dataset.co) + '<br><i style="background:var(--c-gasto)"></i>Gastado ' + M.usd(+col.dataset.ga);
      tip.classList.add("on"); M.hap("s");
      var x = b.left - r.left + b.width / 2 - 70; tip.style.left = M.clamp(x, 0, r.width - 150) + "px"; tip.style.top = "0px";
    }
    cont.addEventListener("click", function (e) { var c = e.target.closest("g.col"); if (c) mostrar(c); else { tip.classList.remove("on"); $$("g.col.sel", cont).forEach(function (x) { x.classList.remove("sel"); }); } });
    cont.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { var c = e.target.closest("g.col"); if (c) { e.preventDefault(); mostrar(c); } } });
  }

  /* ---------- toast (con acción opcional) y confirmación ---------- */
  var toastT, toastFn = null;
  function toast(t, acc) {
    var el = $("#toast"), b = $("#toast-a");
    $("#toast-t").textContent = t; toastFn = acc && acc.fn || null; b.hidden = !acc; if (acc) b.textContent = acc.txt;
    el.classList.toggle("act", !!acc); el.classList.add("on"); clearTimeout(toastT); toastT = setTimeout(cerrarToast, (acc && acc.ms) || 2600);
  }
  function cerrarToast() { $("#toast").classList.remove("on"); toastFn = null; }
  function confirmar(titulo, texto, si) {
    return new Promise(function (ok) {
      var d = $("#dlg"), previo = document.activeElement;
      $("#dlg-t").textContent = titulo; $("#dlg-p").textContent = texto; $("#dlg-si").textContent = si;
      d.hidden = false; requestAnimationFrame(function () { d.classList.add("on"); });
      function tecla(e) { if (e.key === "Escape") { e.stopImmediatePropagation(); fin(false); } }
      function fin(v) {
        document.removeEventListener("keydown", tecla, true); d.classList.remove("on"); setTimeout(function () { d.hidden = true; }, 200);
        $("#dlg-si").onclick = $("#dlg-no").onclick = d.onclick = null;
        if (previo && previo.focus) try { previo.focus({ preventScroll: true }); } catch (e) {}
        ok(v);
      }
      document.addEventListener("keydown", tecla, true);
      $("#dlg-si").onclick = function () { M.hap("m"); fin(true); }; $("#dlg-no").onclick = function () { fin(false); };
      d.onclick = function (e) { if (e.target === d) fin(false); };
      setTimeout(function () { $("#dlg-no").focus({ preventScroll: true }); }, 60);
    });
  }

  /* ---------- edición: agregar, editar, borrar, pausar ---------- */
  function cola() { return S.fuente === "demo" ? colaLocal : colaOut; }
  function recalcular() { if (!S.base) { S.data = null; return; } var q = cola(); S.data = q.items.length ? M.edMezclar(S.base, q.items) : S.base; }
  function crudo(col, id) { var l = (S.data && S.data[col]) || []; for (var i = 0; i < l.length; i++) if (String(l[i].id) === String(id)) return l[i]; return null; }
  function refrescarVista() {
    var y = scrollSave(); render(); scrollRestore(y); tooltipMeses();
    if (S.res) { var demo = S.fuente === "demo"; M.avisar(S.res, demo); M.recordatorios(S.res, demo).then(function () { M.runnerConfig(); }); }
  }
  function editar(col, op, id, data) {
    var it = cola().agregar({ col: col, op: op, id: id, data: data || {} });
    recalcular(); refrescarVista(); programarEnvio();
    return it;
  }
  function programarEnvio() {
    clearTimeout(envioT); envioT = null;
    if (S.fuente === "demo" || !(ls("mesa.url") || "").trim()) return;
    var espera = (colaOut.listos().length && !S.syncErr) ? 1200 : null, h = colaOut.proximoHold();
    if (h) espera = espera == null ? h - Date.now() + 100 : Math.min(espera, h - Date.now() + 100);
    if (espera != null) envioT = setTimeout(function () { actualizar(false); }, Math.max(250, espera));
  }
  /* Guarda un elemento nuevo (esNuevo) o los campos que cambiaron de uno existente. */
  function guardarElemento(col, id, nuevo, esNuevo) {
    var data = esNuevo ? nuevo : M.edDiff(crudo(col, id), nuevo);
    if (!esNuevo && !Object.keys(data).length) return null;
    return editar(col, "upsert", id, data);
  }
  function avisoGuardado(txt) { toast(S.fuente === "demo" ? txt + " Queda solo en este celular." : txt); M.hap("ok"); }

  function eliminar(col, id, mensaje, nombre) {
    var prev = crudo(col, id); if (!prev) return;
    confirmar("¿Eliminar " + nombre + "?", "Se borra de tu lista. Si te arrepentís, tenés unos segundos para deshacerlo.", "Eliminar").then(function (si) {
      if (!si) return;
      if (sheetAbierto) cerrarSheet();
      var it = editar(col, "delete", id, null);
      toast(mensaje, { txt: "Deshacer", ms: 5000, fn: function () {
        if (cola().quitar(it)) { recalcular(); refrescarVista(); programarEnvio(); }
        else { var d = Object.assign({}, prev); delete d.origen; editar(col, "upsert", id, d); }
        M.hap("ok");
      } });
      M.hap("m");
    });
  }

  /* ---------- formularios (hojas) ---------- */
  function fCampo(id, etq, tipo, val, o) {
    o = o || {};
    var ctl = tipo === "area" ? '<textarea id="f-' + id + '" rows="3" maxlength="' + (o.max || 300) + '" placeholder="' + esc(o.ph || "") + '">' + esc(val == null ? "" : val) + "</textarea>" :
      '<input id="f-' + id + '" type="' + tipo + '"' + (o.im ? ' inputmode="' + o.im + '"' : "") + ' autocomplete="off"' + (tipo === "text" ? ' autocapitalize="sentences"' : "") + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : "") + (o.max ? ' maxlength="' + o.max + '"' : "") + ' value="' + esc(val == null ? "" : val) + '">';
    return '<label class="campo" id="c-' + id + '"><span>' + etq + (o.opc ? ' <em>(opcional)</em>' : "") + "</span>" + ctl + (o.ayuda ? '<span class="ayuda">' + o.ayuda + "</span>" : "") + '<span class="error" id="e-' + id + '" role="alert"></span></label>';
  }
  function fSelect(id, etq, ops, val, o) {
    o = o || {};
    return '<label class="campo" id="c-' + id + '"><span>' + etq + (o.opc ? ' <em>(opcional)</em>' : "") + '</span><select id="f-' + id + '">' + ops.map(function (x) { return '<option value="' + esc(x[0]) + '"' + (String(x[0]) === String(val) ? " selected" : "") + ">" + esc(x[1]) + "</option>"; }).join("") + '</select>' + (o.ayuda ? '<span class="ayuda">' + o.ayuda + "</span>" : "") + '<span class="error" id="e-' + id + '" role="alert"></span></label>';
  }
  function fSeg(id, ops, val) { return '<div class="seg" id="f-' + id + '" data-v="' + esc(val) + '" role="group">' + ops.map(function (t) { return '<button type="button" data-act="f-seg" data-v="' + t[0] + '" aria-pressed="' + (val === t[0]) + '">' + t[1] + "</button>"; }).join("") + "</div>"; }
  function fErr(id, msg) { var c = $("#c-" + id); if (c) { c.classList.add("err"); $("#e-" + id).textContent = msg; } }
  function fLimpiar() { $$(".campo.err").forEach(function (c) { c.classList.remove("err"); }); $$(".campo .error").forEach(function (e) { e.textContent = ""; }); }
  function fFoco() { var p = $(".campo.err input, .campo.err select, .campo.err textarea"); M.hap("mal"); if (p) { p.focus({ preventScroll: true }); try { p.scrollIntoView({ block: "center", behavior: "smooth" }); } catch (e) {} } }
  function fVal(id) { var e = $("#f-" + id); return e ? e.value.trim() : ""; }
  function fPie(txtBtn, act, id, extra) {
    return '<button class="btn block" data-act="' + act + '"' + (id ? ' data-id="' + esc(id) + '"' : "") + ' type="button" style="margin-top:8px">' + txtBtn + "</button>" + (extra || "") +
      (S.fuente === "demo" ? '<p class="nota-local">Estás viendo datos de ejemplo: lo que cargues queda solo en este celular. Conectá tus datos en Ajustes para que se guarde en tu Drive y lo vea el contador.</p>'
        : '<p class="p" style="margin-top:12px;font-size:13px;text-align:center">Se guarda en tu celular y se manda a tu Drive en unos segundos.</p>');
  }
  /* "1.234,56", "1234.56" y "12,5" se entienden igual. Devuelve un número o null. */
  function parseMonto(t) {
    t = String(t == null ? "" : t).trim().replace(/\s|US\$|\$/g, ""); if (!t) return null;
    if (t.indexOf(",") > -1 && t.indexOf(".") > -1) t = t.lastIndexOf(",") > t.lastIndexOf(".") ? t.replace(/\./g, "").replace(",", ".") : t.replace(/,/g, "");
    else if (t.indexOf(",") > -1) t = t.replace(",", ".");
    else if (/^-?\d{1,3}(\.\d{3})+$/.test(t)) t = t.replace(/\./g, "");
    return /^-?\d+(\.\d+)?$/.test(t) ? Number(t) : null;
  }
  function numCampo(v) { return v == null ? "" : String(v).replace(".", ","); }

  var CATS_BASE = ["Cuentas de fondeo", "Software y datos", "Comisiones", "Impuestos", "Retiro de ganancias", "Otros"];
  function categoriasUsadas() {
    var o = {}, l = [];
    CATS_BASE.concat(((S.data && S.data.movimientos) || []).map(function (m) { return m.categoria; })).forEach(function (c) { if (c && !o[c]) { o[c] = 1; l.push(c); } });
    return l;
  }
  function sheetFormMov(id) {
    var m = id ? crudo("movimientos", id) : null, d = (m && m.detalle) || {}, cats = categoriasUsadas();
    var cuentas = (S.res && S.res.cuentas) || [];
    var h = '<form novalidate onsubmit="return false">' + fSeg("tipo", [["gasto", "Gasto"], ["cobro", "Cobro"]], m ? (m.tipo === "cobro" ? "cobro" : "gasto") : "gasto") +
      '<div style="height:16px"></div>' +
      fCampo("monto", "Monto en dólares (US$)", "text", m ? numCampo(m.monto) : "", { im: "decimal", ph: "0,00" }) +
      fCampo("fecha", "Fecha", "date", m ? String(m.fecha).slice(0, 10) : M.iso(M.hoy())) +
      fSelect("categoria", "Categoría", [["", "Elegí una categoría"]].concat(cats.map(function (c) { return [c, c]; })).concat([["__otra", "Otra…"]]), m ? m.categoria || "" : "") +
      '<div id="wrap-cat-otra" hidden>' + fCampo("categoria-otra", "Nombre de la categoría", "text", "", { max: 40 }) + "</div>" +
      fCampo("descripcion", "Descripción", "text", m ? m.descripcion : "", { max: 80, ph: "Ej.: Compra de cuenta 50K" }) +
      (cuentas.length ? fSelect("cuenta", "Cuenta relacionada", [["", "Ninguna"]].concat(cuentas.map(function (c) { return [c.id, c.nombre + " · " + c.id]; })), m ? m.cuenta_id || "" : "", { opc: true }) : "") +
      fCampo("medio", "Medio de pago", "text", d.medio_pago || "", { opc: true, max: 40, ph: "Ej.: Tarjeta, transferencia" }) +
      fCampo("nota", "Nota", "text", d.nota || "", { opc: true, max: 120 }) +
      fPie(m ? "Guardar cambios" : "Agregar movimiento", "mov-guardar", id || "") + "</form>";
    abrirSheet(m ? "Editar movimiento" : "Nuevo movimiento", h, { alAbrir: function () { if (!m) setTimeout(function () { var i = $("#f-monto"); if (i) i.focus({ preventScroll: true }); }, 380); } });
  }
  function guardarMov(id) {
    fLimpiar();
    var orig = id ? crudo("movimientos", id) : null, bad = false;
    var monto = parseMonto(fVal("monto")); if (monto == null || monto <= 0) { fErr("monto", "Poné un monto mayor a 0. Ej.: 70 o 1.250,50."); bad = true; }
    var fecha = fVal("fecha"); if (!M.parseISO(fecha)) { fErr("fecha", "Elegí una fecha."); bad = true; }
    var cat = $("#f-categoria").value; if (cat === "__otra") { cat = fVal("categoria-otra"); if (!cat) { fErr("categoria-otra", "Escribí el nombre de la categoría."); bad = true; } } else if (!cat) { fErr("categoria", "Elegí una categoría."); bad = true; }
    var desc = fVal("descripcion"); if (!desc) { fErr("descripcion", "Escribí una descripción corta."); bad = true; }
    if (bad) return fFoco();
    var nuevo = Object.assign({}, orig || {}, { fecha: fecha, tipo: $("#f-tipo").dataset.v, categoria: cat, descripcion: desc, monto: Math.round(monto * 100) / 100, moneda: (orig && orig.moneda) || "USD" });
    var cu = $("#f-cuenta") ? $("#f-cuenta").value : ""; if (cu) nuevo.cuenta_id = cu; else if (orig && orig.cuenta_id != null) nuevo.cuenta_id = null;
    var det = Object.assign({}, orig && orig.detalle), medio = fVal("medio"), nota = fVal("nota");
    if (medio) det.medio_pago = medio; else delete det.medio_pago; if (nota) det.nota = nota; else delete det.nota;
    if (Object.keys(det).length || (orig && orig.detalle)) nuevo.detalle = det;
    var nid = id || M.nuevoId();
    guardarElemento("movimientos", nid, nuevo, !id);
    cerrarSheet(); avisoGuardado(id ? "Cambios guardados." : "Movimiento agregado.");
  }

  var FRECS = [["semanal", "Cada semana"], ["mensual", "Cada mes"], ["bimestral", "Cada 2 meses"], ["trimestral", "Cada 3 meses"], ["semestral", "Cada 6 meses"], ["anual", "Cada año"]];
  function sheetFormSub(id) {
    var s = id ? crudo("suscripciones", id) : null;
    var h = '<form novalidate onsubmit="return false">' +
      fCampo("servicio", "Servicio", "text", s ? s.servicio : "", { max: 60, ph: "Ej.: Datos de mercado" }) +
      fCampo("monto", "Monto en dólares (US$)", "text", s && s.monto != null ? numCampo(s.monto) : "", { im: "decimal", ph: "0,00", opc: true, ayuda: "Si no sabés cuánto es, dejalo vacío: queda “a confirmar” y no se suma." }) +
      fSelect("frecuencia", "Cada cuánto se paga", FRECS, s ? s.frecuencia || "mensual" : "mensual") +
      fCampo("proximo", "Próximo pago", "date", s && s.proximo_pago ? String(s.proximo_pago).slice(0, 10) : "", { opc: true, ayuda: "Con la fecha te avisamos 3 días antes, el día anterior y el mismo día. Si ya pasó, la app la corre sola." }) +
      fCampo("para", "Para qué sirve", "text", s ? s.para_que || "" : "", { opc: true, max: 120, ph: "Ej.: precios en vivo en los gráficos" }) +
      fPie(s ? "Guardar cambios" : "Agregar suscripción", "sub-guardar", id || "") + "</form>";
    abrirSheet(s ? "Editar suscripción" : "Nueva suscripción", h, { alAbrir: function () { if (!s) setTimeout(function () { var i = $("#f-servicio"); if (i) i.focus({ preventScroll: true }); }, 380); } });
  }
  function guardarSub(id) {
    fLimpiar();
    var orig = id ? crudo("suscripciones", id) : null, bad = false;
    var serv = fVal("servicio"); if (!serv) { fErr("servicio", "Escribí el nombre del servicio."); bad = true; }
    var mt = fVal("monto"), monto = null; if (mt) { monto = parseMonto(mt); if (monto == null || monto <= 0) { fErr("monto", "Poné un monto mayor a 0, o dejalo vacío."); bad = true; } }
    var prox = fVal("proximo"); if (prox && !M.parseISO(prox)) { fErr("proximo", "Elegí una fecha válida o dejala vacía."); bad = true; }
    if (bad) return fFoco();
    var nuevo = Object.assign({}, orig || {}, { servicio: serv, monto: monto == null ? null : Math.round(monto * 100) / 100, moneda: (orig && orig.moneda) || "USD", frecuencia: $("#f-frecuencia").value, proximo_pago: prox || null, para_que: fVal("para") });
    if (!orig) nuevo.pausada = false;
    guardarElemento("suscripciones", id || M.nuevoId(), nuevo, !id);
    cerrarSheet(); avisoGuardado(id ? "Cambios guardados." : "Suscripción agregada.");
  }
  function sheetSub(id) {
    var s = S.res.subs.filter(function (x) { return x.id === id; })[0]; if (!s) return;
    var h = '<p class="etq">' + (s.pausada ? "Pausada: no suma ni te avisa" : "Se paga " + (M.FREC_TXT[s.frecuencia] || "")) + '</p><p class="gran" style="font-size:40px">' + (s.monto != null ? M.usd(s.monto) : "A confirmar") + '</p><p class="chips" style="margin-top:6px">' + (s.pausada ? '<span class="pill pausa">' + ICO_PAUSA + "Pausada</span>" : "") + (s.manual ? '<span class="chip-mini man">Manual</span>' : "") + (s.raw.origen === "editado" ? '<span class="chip-mini auto">Editada</span>' : "") + "</p>" +
      '<div style="margin-top:8px">' + fila("Frecuencia", { semanal: "Semanal", mensual: "Mensual", bimestral: "Bimestral", trimestral: "Trimestral", semestral: "Semestral", anual: "Anual" }[s.frecuencia] || "—") + fila("Próximo pago", s.prox ? M.fecha(s.prox) : "Sin fecha", s.prox ? M.enDias(s.dias) : "Cargala para recibir avisos") +
      (s.monto != null && s.frecuencia !== "mensual" ? fila("Equivale a", M.usd(s.mensual) + " por mes") : "") + (s.para_que ? fila("Para qué", esc(s.para_que)) : "") + "</div>" +
      '<div class="acciones tres-b"><button class="btn sec" data-act="sub-edit" data-id="' + esc(id) + '" type="button">' + ICO_EDIT + 'Editar</button><button class="btn sec" data-act="sub-pausa" data-id="' + esc(id) + '" type="button">' + (s.pausada ? ICO_PLAY + "Reanudar" : ICO_PAUSA + "Pausar") + '</button><button class="btn sec peligro" data-act="sub-del" data-id="' + esc(id) + '" type="button">' + ICO_BORRAR + "Eliminar</button></div>" +
      '<p class="p" style="margin-top:10px;font-size:13px">Pausar sirve para frenar el aviso y el gasto sin perder los datos. Reanudás cuando quieras.</p>';
    abrirSheet(s.servicio, h);
  }
  function pausarSub(id) {
    var s = crudo("suscripciones", id); if (!s) return;
    var p = s.pausada !== true;
    if (sheetAbierto) cerrarSheet();
    editar("suscripciones", "upsert", id, { pausada: p });
    toast(p ? "Pausada. No suma al gasto ni te avisa." : "Reanudada. Vuelve a sumar y a avisarte.", p ? { txt: "Deshacer", ms: 5000, fn: function () { editar("suscripciones", "upsert", id, { pausada: false }); } } : null); M.hap("ok");
  }

  var ESTADOS_OPS = [["evaluacion", "En evaluación"], ["fondeada", "Fondeada"], ["aprobada", "Aprobada"], ["pausada", "Pausada"], ["perdida", "Perdida"]];
  function sheetFormCuenta(id) {
    var c = id ? crudo("cuentas", id) : null;
    if (c && !M.esManual(c)) {
      var h0 = '<form novalidate onsubmit="return false"><p class="p" style="margin-bottom:16px">Esta cuenta viene sola de FundedNext, así que los números no se tocan. Podés dejar una nota para vos.</p>' +
        fCampo("nota", "Nota", "area", c.nota || "", { opc: true, max: 300, ph: "Ej.: retirar el viernes" }) + fPie("Guardar nota", "cuenta-guardar", id) + "</form>";
      return abrirSheet("Nota de " + (c.nombre || "la cuenta"), h0);
    }
    var h = '<form novalidate onsubmit="return false"><p class="p" style="margin-bottom:16px">Para cuentas de otra firma (no FundedNext). Vos cargás y actualizás los números.</p>' +
      fCampo("nombre", "Nombre de la cuenta", "text", c ? c.nombre : "", { max: 50, ph: "Ej.: Cuenta 100K" }) +
      fCampo("firma", "Firma", "text", c ? c.firma || "" : "", { opc: true, max: 40, ph: "Ej.: Apex, FTMO" }) +
      fCampo("tipo", "Tipo de cuenta", "text", c ? c.tipo || "" : "", { opc: true, max: 40, ph: "Ej.: Evaluación 50K" }) +
      fSelect("estado", "Estado", ESTADOS_OPS, c ? c.estado || "evaluacion" : "evaluacion") +
      fCampo("saldo_inicial", "Saldo inicial (US$)", "text", c ? numCampo(c.saldo_inicial) : "", { im: "decimal", ph: "50.000", ayuda: "Con cuánta plata arrancó la cuenta." }) +
      fCampo("saldo", "Saldo actual (US$)", "text", c ? numCampo(c.saldo) : "", { im: "decimal", ph: "50.000" }) +
      fCampo("piso", "Piso (US$)", "text", c && c.piso != null ? numCampo(c.piso) : "", { im: "decimal", opc: true, ayuda: "El saldo mínimo: si bajás de acá, se pierde la cuenta (pérdida máxima)." }) +
      fCampo("objetivo", "Objetivo de ganancia (US$)", "text", c && c.objetivo_ganancia != null ? numCampo(c.objetivo_ganancia) : "", { im: "decimal", opc: true, ayuda: "Cuánto hay que ganar para aprobar." }) +
      fCampo("retirable", "Retirable ahora (US$)", "text", c && c.retirable != null ? numCampo(c.retirable) : "", { im: "decimal", opc: true, ayuda: "Lo que podés retirar hoy. Dejalo en 0 si nada." }) +
      fCampo("nota", "Notas", "area", c ? c.nota || "" : "", { opc: true, max: 300 }) +
      fPie(c ? "Guardar cambios" : "Agregar cuenta", "cuenta-guardar", id || "") + "</form>";
    abrirSheet(c ? "Editar cuenta" : "Nueva cuenta manual", h);
  }
  function guardarCuenta(id) {
    fLimpiar();
    var orig = id ? crudo("cuentas", id) : null;
    if (orig && !M.esManual(orig)) { guardarElemento("cuentas", id, Object.assign({}, orig, { nota: fVal("nota") }), false); cerrarSheet(); return avisoGuardado("Nota guardada."); }
    var bad = false;
    var nombre = fVal("nombre"); if (!nombre) { fErr("nombre", "Escribí un nombre para reconocerla."); bad = true; }
    var ini = parseMonto(fVal("saldo_inicial")); if (ini == null || ini <= 0) { fErr("saldo_inicial", "Poné con cuánto arrancó la cuenta. Ej.: 50000."); bad = true; }
    var saldo = parseMonto(fVal("saldo")); if (saldo == null || saldo < 0) { fErr("saldo", "Poné el saldo de hoy. Ej.: 50250,75."); bad = true; }
    var piso = null; if (fVal("piso")) { piso = parseMonto(fVal("piso")); if (piso == null || piso < 0) { fErr("piso", "Poné un número válido o dejalo vacío."); bad = true; } else if (ini != null && piso >= ini) { fErr("piso", "El piso tiene que ser menor al saldo inicial."); bad = true; } }
    var obj = null; if (fVal("objetivo")) { obj = parseMonto(fVal("objetivo")); if (obj == null || obj <= 0) { fErr("objetivo", "Poné un número mayor a 0 o dejalo vacío."); bad = true; } }
    var ret = 0; if (fVal("retirable")) { ret = parseMonto(fVal("retirable")); if (ret == null || ret < 0) { fErr("retirable", "Poné un número válido (0 si nada)."); bad = true; } }
    if (bad) return fFoco();
    var r2 = function (x) { return Math.round(x * 100) / 100; };
    var nuevo = Object.assign({}, orig || {}, { nombre: nombre, firma: fVal("firma"), tipo: fVal("tipo") || nombre, estado: $("#f-estado").value, saldo_inicial: r2(ini), saldo: r2(saldo), piso: piso == null ? null : r2(piso), objetivo_ganancia: obj == null ? null : r2(obj), retirable: r2(ret || 0), nota: fVal("nota") });
    if (!orig) nuevo.inicio = M.iso(M.hoy());
    delete nuevo.objetivo_saldo;
    guardarElemento("cuentas", id || M.nuevoId(), nuevo, !id);
    cerrarSheet(); avisoGuardado(id ? "Cambios guardados." : "Cuenta agregada.");
  }
  function payoutHtml(c) {
    var p = c.payout, f = "";
    if (p.dias_ok != null || p.dias_req != null) f += fila("Días de payout", (p.dias_ok != null ? p.dias_ok : "?") + " de " + (p.dias_req != null ? p.dias_req : "?"), "Días que cumplen el mínimo para poder retirar");
    if (p.minimo_dia != null) f += fila("Mínimo por día", M.usd(p.minimo_dia), "Ganancia mínima para que cuente el día");
    if (p.pct_retiro != null) f += fila("Porcentaje que retirás", M.pct(p.pct_retiro, 0), "De la ganancia");
    if (p.max_retiro != null) f += fila("Máximo a retirar", M.usd(p.max_retiro));
    f += fila("Podés retirar", p.elegible === true ? '<span class="gana">Sí</span>' : p.elegible === false ? "Todavía no" : "Sin dato");
    if (p.proximo_ciclo) f += fila("Próximo ciclo", M.fecha(p.proximo_ciclo));
    var h = '<h2 class="sec">Retiro (payout)</h2><div>' + f + "</div>";
    if (p.bloqueo) h += '<div class="check" style="margin-top:6px"><svg class="no" style="stroke:var(--alerta)" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4 3 20h18z"/><path d="M12 10v4M12 17v.5"/></svg><div><b>Algo lo frena</b><br><span class="suave">' + esc(p.bloqueo) + "</span>" + (p.solucion ? '<br><span class="suave"><b>Qué hacer:</b> ' + esc(p.solucion) + "</span>" : "") + "</div></div>";
    return h;
  }
  function estadoRunner() {
    var el = $("#aviso-estado"); if (!el || S.tab !== 4) return;
    if (!M.nativa()) { el.textContent = "Los avisos con la app cerrada solo funcionan en la app instalada en el celular."; return; }
    M.runnerEstado().then(function (e) {
      el.textContent = !e ? "No pude consultar el chequeo en segundo plano. Se activa solo cuando Android lo permite." :
        e.ultima ? "Último chequeo en segundo plano: " + relativo(e.ultima) + "." + (e.error ? " Hubo un error: " + e.error + "." : "") :
        e.configurado ? "Todavía no hizo su primer chequeo. Android lo corre cuando puede, cada 30 minutos más o menos." : "Guardá la URL y la clave de arriba para que revise en segundo plano.";
    });
  }

  /* ---------- datos ---------- */
  function actualizar(manual) {
    if (S.cargando) return Promise.resolve();
    S.cargando = true; estadoChip();
    var url = (ls("mesa.url") || "").trim(), k = ls("mesa.clave") || "", ctrl = null, to = null, previos = [];
    /* 1) manda los cambios pendientes (si hay conexión), 2) baja los datos ya mezclados */
    var envio = url && colaOut.listos().length ? colaOut.enviar(url, k) : Promise.resolve(null);
    var p = envio.then(function (er) {
      if (er) S.syncErr = er.ok ? null : er.error;
      previos = colaOut.enviados();
      ctrl = window.AbortController ? new AbortController() : null; to = setTimeout(function () { if (ctrl) ctrl.abort(); }, 8000);
      if (!url) return fetch("data/demo.json", { cache: "no-store", signal: ctrl && ctrl.signal }).then(function (r) { if (!r.ok) throw new Error("No encontré los datos de ejemplo."); return r.json(); }).then(function (d) { S.fuente = "demo"; return d; });
      return fetch(url + (url.indexOf("?") > -1 ? "&" : "?") + "k=" + encodeURIComponent(k), { cache: "no-store", signal: ctrl && ctrl.signal }).then(function (r) { if (!r.ok) throw new Error("El servidor contestó " + r.status + "."); return r.json(); }).then(function (j) {
        if (j && j.ok === false) throw new Error(j.error === "clave" ? "La clave no coincide con la del script." : j.error === "no_archivo" ? "No encuentro mesa-datos.json en tu Drive." : "El script devolvió un error.");
        if (!j || !Array.isArray(j.cuentas)) throw new Error("El archivo no tiene el formato esperado.");
        S.fuente = "endpoint"; ls("mesa.cache", JSON.stringify(j)); return j;
      });
    });
    return p.then(function (d) {
      S.base = d; if (S.fuente === "endpoint") colaOut.limpiarEnviados(previos); recalcular();
      S.error = null; S.ultima = new Date().toISOString(); ls("mesa.ultima", S.ultima);
      if (manual) { toast(S.syncErr ? "Datos actualizados, pero hay cambios sin enviar." : "Datos actualizados"); M.hap("ok"); }
    }).catch(function (e) {
      var m = e && e.name === "AbortError" ? "Tardó más de 8 segundos en responder. Revisá tu conexión." : e instanceof SyntaxError ? "La URL no devuelve datos. Revisá que la implementación sea para \"Cualquier persona\"." : e instanceof TypeError ? "No hay conexión o la URL no es correcta." : (e && e.message) || "Falló la actualización.";
      S.error = m; if (manual) { toast(m); M.hap("mal"); }
    }).then(function () {
      clearTimeout(to); S.cargando = false; var y = scrollSave(), primera = S.listo && S.data && !S.tuvoDatos; if (S.data) S.tuvoDatos = true;
      render(); scrollRestore(y); tooltipMeses(); programarEnvio();
      if (primera) { $$(".panel").forEach(function (pn) { delete pn.dataset.visto; pn.classList.remove("vivo"); }); activarPanel(S.tab); }
      if (S.res) { var demo = S.fuente === "demo"; M.avisar(S.res, demo); M.recordatorios(S.res, demo).then(function () { M.runnerConfig(); }); }
      if (rutaPend && S.res) { var u = rutaPend; rutaPend = null; ruta(u); }
      if (S.fuente === "endpoint" && !S.error && M.ota.tocaBuscar()) M.ota.buscar(url, k).then(function (o) { if (o.estado === "nueva") { toast("Hay una versión nueva (" + o.version + ").", { txt: "Aplicar", ms: 9000, fn: M.ota.reiniciar }); if (S.tab === 4) render(); } });
    });
  }
  function scrollSave() { return $$(".panel").map(function (p) { return p.scrollTop; }); }
  function scrollRestore(a) { $$(".panel").forEach(function (p, i) { p.scrollTop = a[i] || 0; }); }

  /* ---------- tema, avisos ---------- */
  function aplicarTema() { var t = ls("mesa.tema") || "auto", r = document.documentElement; if (t === "auto") r.removeAttribute("data-tema"); else r.setAttribute("data-tema", t); barraEstado(); }
  /* ---------- nativo: barra de estado, atajos, avisos con botones, huella ---------- */
  function plug(n) { try { return (window.Capacitor && Capacitor.Plugins && Capacitor.Plugins[n]) || null; } catch (e) { return null; } }
  function noop() {}
  function temaOscuro() { var t = ls("mesa.tema") || "auto"; return t === "oscuro" || (t === "auto" && !(window.matchMedia && matchMedia("(prefers-color-scheme: light)").matches)); }
  function barraEstado() {
    var o = temaOscuro(), mt = document.querySelector('meta[name="theme-color"]'); if (mt) mt.setAttribute("content", o ? "#070B11" : "#EDF1F6");
    var SB = M.nativa() && plug("StatusBar"); if (!SB) return;
    try { SB.setStyle({ style: o ? "DARK" : "LIGHT" }).catch(noop); SB.setBackgroundColor({ color: o ? "#070B11" : "#EDF1F6" }).catch(noop); } catch (e) {}
  }
  var rutaPend = null;
  /* mesapro://hoy | killzone | gasto | diario | plata | suscripciones */
  function ruta(url) {
    var m = /^mesapro:\/\/([a-z-]+)/i.exec(String(url || "")); if (!m) return;
    if (!S.res) { rutaPend = url; return; }
    var r = m[1].toLowerCase();
    if (sheetAbierto) cerrarSheet();
    if (r !== "killzone") kzCerrar();
    if (r === "killzone") { irA(0, true); kzAbrir(); }
    else if (r === "gasto") { S.seg = "movs"; irA(3, true); refrescarVista(); sheetFormMov(); }
    else if (r === "suscripciones") { S.seg = "subs"; irA(3, true); refrescarVista(); }
    else irA({ hoy: 0, cuentas: 1, diario: 2, plata: 3, mas: 4 }[r] || 0, true);
  }
  function bioDisponible() { return M.nativa() && !!plug("BiometricAuthNative"); }
  function bioActivo() { return ls("mesa.bio") === "1" && bioDisponible(); }
  var bloqueado = false, ocultoDesde = 0;
  function bloquear() { if (!bioActivo() || bloqueado) return; bloqueado = true; $("#candado").hidden = false; document.body.classList.add("bloqueada"); desbloquear(); }
  function autenticar() {
    var B = plug("BiometricAuthNative"); if (!B) return Promise.reject(new Error("sin_plugin"));
    return B.internalAuthenticate({ reason: "Para ver tus cuentas", androidTitle: "Mesa PRO", androidSubtitle: "Usá tu huella o el bloqueo del celular", cancelTitle: "Cancelar", allowDeviceCredential: true, androidConfirmationRequired: false });
  }
  function desbloquear() { autenticar().then(function () { bloqueado = false; $("#candado").hidden = true; document.body.classList.remove("bloqueada"); M.hap("ok"); }, noop); }
  function bioCambiar(el) {
    if (ls("mesa.bio") === "1") { ls("mesa.bio", "0"); el.setAttribute("aria-checked", "false"); toast("Ya no se pide la huella."); return; }
    var B = plug("BiometricAuthNative"); if (!B) return;
    B.checkBiometry().then(function (r) {
      if (!r.isAvailable && !r.deviceIsSecure) { toast("El celular no tiene huella ni bloqueo de pantalla configurado."); M.hap("mal"); return; }
      return autenticar().then(function () { ls("mesa.bio", "1"); el.setAttribute("aria-checked", "true"); toast("Listo: se pide la huella al abrir."); M.hap("ok"); });
    }).catch(function () { toast("No se activó: la huella no se confirmó."); });
  }
  function tapar(si) { document.body.classList.toggle("tapado", !!si); }
  function nativoInit() {
    barraEstado();
    try { if (window.matchMedia) matchMedia("(prefers-color-scheme: light)").addEventListener("change", barraEstado); } catch (e) {}
    M.canales();
    var A = M.nativa() && plug("App");
    if (A) {
      try {
        A.addListener("appUrlOpen", function (e) { ruta(e && e.url); });
        A.getLaunchUrl().then(function (r) { if (r && r.url) ruta(r.url); }).catch(noop);
        A.addListener("appStateChange", function (s) {
          if (!s.isActive) { ocultoDesde = Date.now(); tapar(true); }
          else { tapar(false); if (bioActivo() && Date.now() - ocultoDesde > 60000) bloquear(); if (kzAbierto) pedirPantalla(); }
        });
      } catch (e) {}
    }
    var LN = M.nativa() && plug("LocalNotifications");
    if (LN) try {
      LN.addListener("localNotificationActionPerformed", function (a) {
        var ex = (a && a.notification && a.notification.extra) || {}, id = a && a.actionId;
        ruta("mesapro://" + (id === "kz" ? "killzone" : id === "subs" ? "suscripciones" : id === "hoy" ? "hoy" : ex.ruta || "hoy"));
      });
    } catch (e) {}
    if (bioActivo()) bloquear();
    var q = null; try { if (!M.nativa()) q = new URLSearchParams(location.search).get("ruta"); } catch (e) {}
    if (q) ruta("mesapro://" + q);
  }

  function pintarAvisosBtn() {
    var b = $("#btn-avisos"); if (!b) return;
    M.avisosEstado().then(function (e) { b.textContent = e === "granted" ? "Avisos activados" : e === "denied" ? "Bloqueados: activalos en los ajustes del celular" : e === "unsupported" ? "Este navegador no permite avisos" : "Activar avisos"; b.disabled = e === "granted" || e === "unsupported"; });
  }

  /* ---------- eventos ---------- */
  document.addEventListener("click", function (e) {
    var el = e.target.closest("[data-act]"); if (!el) return;
    var a = el.dataset.act;
    if (a === "tab") { irA(+el.dataset.i); }
    else if (a === "chip") { if (S.fuente === "demo") irA(4); else { M.hap("l"); actualizar(true); } }
    else if (a === "cuenta") sheetCuenta(el.dataset.id);
    else if (a === "mov") sheetMov(el.dataset.id);
    else if (a === "alertas") sheetAlertas();
    else if (a === "exportar") sheetExportar();
    else if (a === "compartir") compartir();
    else if (a === "copiar") copiar();
    else if (a === "tipo") { S.f.tipo = el.dataset.v; $$("#seg-tipo button").forEach(function (b) { b.setAttribute("aria-pressed", String(b === el)); }); $("#libro").innerHTML = libro(S.res); M.hap("s"); }
    else if (a === "limpiar") { S.f = { tipo: "todos", cat: "", mes: "" }; render(); }
    else if (a === "actualizar") { M.hap("l"); actualizar(true); }
    else if (a === "guardar") {
      var nu = $("#in-url").value.trim(), viejo = (ls("mesa.url") || "").trim();
      ls("mesa.url", nu); ls("mesa.clave", $("#in-clave").value.trim());
      if (!nu) { ls("mesa.cache", null); S.fuente = "demo"; }
      else if (S.fuente === "demo" || nu !== viejo) { S.base = null; S.data = null; S.res = null; S.error = null; S.tuvoDatos = false; S.fuente = "endpoint"; ls("mesa.cache", null); render(); }
      M.hap("m"); actualizar(true); M.runnerConfig();
    }
    else if (a === "clave") { var i = $("#in-clave"); i.type = i.type === "password" ? "text" : "password"; el.textContent = i.type === "password" ? "Ver" : "Ocultar"; }
    else if (a === "tema") { ls("mesa.tema", el.dataset.v); aplicarTema(); $$("[data-act=tema]").forEach(function (b) { b.setAttribute("aria-pressed", String(b === el)); }); M.hap("s"); }
    else if (a === "avisos") { M.avisosPedir().then(function (r) { pintarAvisosBtn(); if (r === "granted") { toast("Avisos activados"); M.hap("ok"); M.runnerConfig(); if (S.res) { M.avisar(S.res, S.fuente === "demo"); M.recordatorios(S.res, S.fuente === "demo").then(function () { M.runnerConfig(); }); } } }); }
    else if (a === "probar") { M.probar().then(function (r) { if (r.permiso !== "granted") { toast("Primero tocá “Activar avisos”."); M.hap("mal"); return; } toast("Te mandé una notificación de prueba."); M.hap("ok"); estadoRunner(); }); }
    else if (a === "pref") {
      var on = el.getAttribute("aria-checked") !== "true"; el.setAttribute("aria-checked", String(on)); M.prefAvisoSet(el.dataset.id, on); M.hap("s");
      M.runnerConfig(); if (el.dataset.id === "pagos" && S.res) M.recordatorios(S.res, S.fuente === "demo").then(function () { M.runnerConfig(); });
    }
    else if (a === "fab") { if (S.tab === 2) sheetFormDiario(); else if (S.tab === 3) { if (S.seg === "subs") sheetFormSub(); else sheetFormMov(); } else sheetMenu(); }
    else if (a === "seg-plata") { S.seg = el.dataset.v === "subs" ? "subs" : "movs"; var y0 = panelAct().scrollTop; $("#p-plata .contenido").innerHTML = banner() + vPlata(S.res); panelAct().scrollTop = Math.min(y0, 60); tooltipMeses(); animar($("#p-plata")); fabEstado(); M.hap("s"); }
    else if (a === "mov-nuevo") sheetFormMov();
    else if (a === "sub-nueva") sheetFormSub();
    else if (a === "diario-nueva") sheetFormDiario();
    else if (a === "diario-ver") sheetDiario(el.dataset.id);
    else if (a === "diario-edit") sheetFormDiario(el.dataset.id);
    else if (a === "diario-del") eliminar("diario", el.dataset.id, "Nota eliminada", "esta nota");
    else if (a === "diario-guardar") guardarDiario(el.dataset.id || "");
    else if (a === "diario-tag") { S.dtag = el.dataset.v || ""; $("#p-diario .contenido").innerHTML = banner() + vDiario(S.res); M.hap("s"); }
    else if (a === "f-tag") { el.setAttribute("aria-pressed", String(el.getAttribute("aria-pressed") !== "true")); M.hap("s"); }
    else if (a === "buscar") { if (S.res) sheetBuscar(); }
    else if (a === "kz") kzAbrir();
    else if (a === "kz-cerrar") kzCerrar();
    else if (a === "kz-check") { var T = kzTildes(), ki = +el.dataset.i, p0 = T.indexOf(ki); if (p0 > -1) T.splice(p0, 1); else T.push(ki); ls("mesa.kz.tildes", JSON.stringify({ fecha: M.iso(M.hoy()), ok: T })); kzPintar(); M.hap(p0 > -1 ? "s" : "ok"); }
    else if (a === "kz-editar") { S.kzEdit = !S.kzEdit; kzPintar(); }
    else if (a === "kz-quitar") { var L = kzLista(); L.splice(+el.dataset.i, 1); ls("mesa.kz.lista", JSON.stringify(L)); ls("mesa.kz.tildes", null); kzPintar(); }
    else if (a === "kz-sumar") { var L2 = kzLista(); if (L2.length < 12) { L2.push("Paso nuevo"); ls("mesa.kz.lista", JSON.stringify(L2)); kzPintar(); var ins = $$(".kz-ed input"); if (ins.length) { ins[ins.length - 1].focus(); ins[ins.length - 1].select(); } } }
    else if (a === "kz-frenar") kzFrenar();
    else if (a === "kz-reanudar") { ls("mesa.frenado", null); kzPintar(); M.runnerConfig(); refrescarVista(); toast("Listo: volvés a recibir todos los avisos."); }
    else if (a === "calc-ins") { S.calc.instr = el.dataset.v; ls("mesa.calc", JSON.stringify(S.calc)); $$("[data-act=calc-ins]").forEach(function (b) { b.setAttribute("aria-pressed", String(b === el)); }); var ci = $("#calc-com"); if (ci) ci.placeholder = M.num(M.R.INSTR[S.calc.instr].com); $("#calc-res").innerHTML = calcRes(S.res && S.res.principal); M.hap("s"); }
    else if (a === "fx") { M.fx.setModo(el.dataset.v); $("#p-mas .contenido").innerHTML = vMas(); activarTilt(); M.hap("s"); }
    else if (a === "perf") { var pr = $("#perf-res"); pr.textContent = "Midiendo 2 segundos… mové la pantalla si querés."; M.fx.perfilar(2000).then(function (rr) { ls("mesa.fx.medido", JSON.stringify({ fps: rr.fps, p95: rr.p95, cuando: Date.now() })); pr.textContent = rr.fps + " cuadros por segundo; el 95% de los cuadros tardó menos de " + M.num(rr.p95, 1) + " ms. " + (rr.p95 <= 20 ? "Anda fluido." : "Va justo: probá el modo Ahorro."); }); }
    else if (a === "ota-buscar") { var orr = $("#ota-res"); orr.textContent = "Buscando…"; M.ota.buscar((ls("mesa.url") || "").trim(), ls("mesa.clave") || "").then(function (o) { $("#p-mas .contenido").innerHTML = vMas(); var o2 = $("#ota-res"); if (o2) o2.textContent = o.mensaje; if (o.estado === "nueva") M.hap("ok"); }); }
    else if (a === "ota-reiniciar") M.ota.reiniciar();
    else if (a === "ota-fabrica") { confirmar("¿Volver a la versión de fábrica?", "Se borran las actualizaciones bajadas por aire y la app se reinicia con la versión que vino en el APK. Tus datos no se tocan.", "Volver").then(function (si) { if (si) M.ota.fabrica().then(M.ota.reiniciar); }); }
    else if (a === "bio") bioCambiar(el);
    else if (a === "desbloquear") desbloquear();
    else if (a === "licencia") { fetch("vendor/LICENSE-lightweight-charts.txt").then(function (r) { return r.text(); }).then(function (t) { abrirSheet("Licencia de Lightweight Charts", '<p class="p" style="margin-bottom:12px">TradingView Lightweight Charts™ · Copyright 2023 TradingView, Inc. · <a href="https://www.tradingview.com/" target="_blank" rel="noopener">tradingview.com</a></p><pre class="licencia">' + esc(t) + "</pre>"); }).catch(function () { toast("No pude abrir la licencia."); }); }
    else if (a === "sync") { M.hap("l"); actualizar(true); }
    else if (a === "toast-accion") { var fn = toastFn; cerrarToast(); if (fn) fn(); }
    else if (a === "f-seg") { var cont = el.parentNode; cont.dataset.v = el.dataset.v; $$("button", cont).forEach(function (b) { b.setAttribute("aria-pressed", String(b === el)); }); M.hap("s"); }
    else if (a === "sub") sheetSub(el.dataset.id);
    else if (a === "sub-edit") sheetFormSub(el.dataset.id);
    else if (a === "sub-pausa") pausarSub(el.dataset.id);
    else if (a === "sub-del") eliminar("suscripciones", el.dataset.id, "Suscripción eliminada", "esta suscripción");
    else if (a === "sub-guardar") guardarSub(el.dataset.id || "");
    else if (a === "mov-edit") sheetFormMov(el.dataset.id);
    else if (a === "mov-del") eliminar("movimientos", el.dataset.id, "Movimiento eliminado", "este movimiento");
    else if (a === "mov-guardar") guardarMov(el.dataset.id || "");
    else if (a === "cuenta-nueva") sheetFormCuenta();
    else if (a === "cuenta-edit") sheetFormCuenta(el.dataset.id);
    else if (a === "cuenta-del") eliminar("cuentas", el.dataset.id, "Cuenta eliminada", "esta cuenta");
    else if (a === "cuenta-guardar") guardarCuenta(el.dataset.id || "");
  });
  document.addEventListener("change", function (e) {
    if (e.target.id === "f-categoria") { var w = $("#wrap-cat-otra"); if (w) { w.hidden = e.target.value !== "__otra"; if (!w.hidden) { var oi = $("#f-categoria-otra"); if (oi) oi.focus(); } } return; }
    var f = e.target.dataset && e.target.dataset.f; if (!f) return;
    S.f[f] = e.target.value; $("#libro").innerHTML = libro(S.res); M.hap("s");
  });
  document.addEventListener("input", function (e) {
    var id = e.target.id;
    if (id === "q") { $("#q-res").innerHTML = buscar(e.target.value); return; }
    if (id === "calc-stop" || id === "calc-riesgo" || id === "calc-com") { S.calc[id.slice(5)] = e.target.value; ls("mesa.calc", JSON.stringify(S.calc)); $("#calc-res").innerHTML = calcRes(S.res && S.res.principal); return; }
    if (e.target.dataset && e.target.dataset.kzI != null) { var L = kzLista(); L[+e.target.dataset.kzI] = e.target.value.slice(0, 80); ls("mesa.kz.lista", JSON.stringify(L)); return; }
    var c = e.target.closest && e.target.closest(".campo.err"); if (c) { c.classList.remove("err"); var er = c.querySelector(".error"); if (er) er.textContent = ""; } });
  document.addEventListener("visibilitychange", function () {
    tapar(document.hidden);
    if (!document.hidden) { if (kzAbierto) pedirPantalla(); tickReloj(); }
    if (!document.hidden && (!S.ultima || Date.now() - new Date(S.ultima).getTime() > INTERVALO)) actualizar(false);
  });

  /* ---------- arranque ---------- */
  aplicarTema(); M.fx.aplicar(); nativoInit();
  irA(0, true);
  var cache = null; try { cache = JSON.parse(ls("mesa.cache")); } catch (e) {}
  if ((ls("mesa.url") || "").trim() && cache && cache.cuentas) { S.base = cache; S.fuente = "endpoint"; S.ultima = ls("mesa.ultima"); recalcular(); }
  render();
  /* la versión (de fábrica o por aire) arrancó bien: solo si pintó Hoy de verdad y sin errores */
  requestAnimationFrame(function () { var c = $("#p-hoy .contenido"); if (window.MesaArranque && !S.renderFallo && c && c.innerHTML.trim().length > 50) MesaArranque.ok(); });
  var t0 = Date.now();
  function revelar() {
    var espera = Math.max(0, (reducido ? 200 : 1100) - (Date.now() - t0));
    setTimeout(function () {
      S.listo = true; $("#splash").classList.add("fuera"); setTimeout(function () { $("#splash").remove(); }, 600);
      activarPanel(S.tab); tooltipMeses();
      setTimeout(function () { M.fx.autoMedir(); }, 400);
    }, espera);
  }
  if (S.data) S.tuvoDatos = true;
  actualizar(false); revelar(); M.runnerConfig();
  setInterval(function () { actualizar(false); }, INTERVALO);
  setInterval(estadoChip, 30000);
  setInterval(function () { if (!document.hidden && (S.tab === 0 || kzAbierto)) tickReloj(); }, 1000);
})();
