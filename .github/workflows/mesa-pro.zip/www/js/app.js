/* Mesa PRO - pantallas, datos y gestos. JS puro, sin build. */
(function () {
  "use strict";
  var M = window.Mesa, esc = M.esc;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) {} return null; }
  var reducido = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  var INTERVALO = 15 * 60 * 1000;

  var S = { data: null, res: null, fuente: "demo", ultima: null, error: null, cargando: false, tab: 0, f: { tipo: "todos", cat: "", mes: "" }, listo: false, movsVista: [] };
  var TABS = [
    { id: "inicio", t: "Inicio", i: '<path d="M4 11.5 12 4l8 7.5V19a1 1 0 0 1-1 1h-4v-5h-6v5H5a1 1 0 0 1-1-1z"/>' },
    { id: "cuentas", t: "Cuentas", i: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 10h18M7 15h4"/>' },
    { id: "plata", t: "Plata", i: '<circle cx="12" cy="12" r="9"/><path d="M14.8 9.4c-.5-.9-1.6-1.4-2.8-1.4-1.6 0-2.7.8-2.7 2 0 2.9 5.6 1.3 5.6 4.1 0 1.2-1.2 2-2.9 2-1.4 0-2.5-.5-3.1-1.5M12 6.3V8m0 8v1.7"/>' },
    { id: "subs", t: "Suscripciones", i: '<path d="M17 3l3 3-3 3M4 11V9a3 3 0 0 1 3-3h13M7 21l-3-3 3-3M20 13v2a3 3 0 0 1-3 3H4"/>' },
    { id: "ajustes", t: "Ajustes", i: '<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>' }
  ];
  var ICO_GASTO = '<path d="M7 17 17 7M9 7h8v8"/>', ICO_COBRO = '<path d="M17 7 7 17M15 17H7V9"/>';
  var CHEV = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>';
  var OK = '<svg class="ok" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.7 2.7L16 9.8"/></svg>';
  var NO = '<svg class="no" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/></svg>';
  var MAL = '<svg class="mal" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9 9l6 6M15 9l-6 6"/></svg>';
  var ESTADO_TXT = { ok: "Todo bien", warn: "Mirá esto", bad: "Hacé esto ahora" };

  /* ---------- helpers de vista ---------- */
  function cnt(v, dec, signo) { return '<span data-c="' + v + '" data-d="' + dec + '"' + (signo ? ' data-s="1"' : "") + ">" + (signo && v > 0 ? "+" : "") + M.num(v, dec) + "</span>"; }
  function barra(p, clase, etq, ahora) {
    p = M.clamp(p, 0, 1);
    return '<div class="barra ' + (clase || "") + '" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + Math.round(p * 100) + '" aria-label="' + esc(etq) + '"><i style="--p:' + p.toFixed(4) + '"></i></div>';
  }
  function fila(k, v, h) { return '<div class="fila"><span class="k">' + k + '</span><span class="v">' + v + (h ? '<span class="h">' + h + "</span>" : "") + "</span></div>"; }
  function titulo(peq, t) { return '<header class="titulo"><small>' + esc(peq) + "</small><h1>" + esc(t) + "</h1></header>"; }
  function vacio(txt, btn) { return '<div class="vacio"><p>' + txt + "</p>" + (btn || "") + "</div>"; }
  function skeleton() {
    function l(w, h, m) { return '<div class="sk" style="width:' + w + ";height:" + h + "px;margin-bottom:" + (m || 0) + 'px"></div>'; }
    return '<div class="titulo">' + l("120px", 14, 10) + l("180px", 34) + "</div>" +
      '<div class="card" style="display:flex;gap:18px;align-items:center;padding:22px 20px"><div class="sk" style="width:38px;height:98px;border-radius:999px;flex:none"></div><div style="flex:1">' + l("90px", 14, 12) + l("100%", 20, 8) + l("82%", 20) + "</div></div>" +
      '<div class="card" style="display:grid;grid-template-columns:repeat(3,1fr);gap:18px">' + [1, 2, 3].map(function () { return "<div>" + l("60%", 13, 12) + l("100%", 24, 10) + l("80%", 12) + "</div>"; }).join("") + "</div>" +
      '<div class="card">' + l("50%", 14, 14) + l("65%", 32, 12) + l("100%", 12) + "</div>" +
      '<div class="card">' + l("60%", 14, 14) + l("45%", 32, 12) + l("100%", 12) + "</div>";
  }
  function ringSvg(p, nivel, grande) {
    var r = 44, c = 2 * Math.PI * r, off = c * (1 - M.clamp(p, 0, 1));
    return '<div class="anillo" style="--circ:' + c.toFixed(2) + ";--off:" + off.toFixed(2) + ";--c:" + ({ ok: "var(--l-ok)", warn: "var(--l-warn)", bad: "var(--l-bad)" }[nivel] || "var(--acento)") + (grande ? ";width:148px;height:148px" : "") + '"><svg viewBox="0 0 100 100" aria-hidden="true"><circle class="pista-a" cx="50" cy="50" r="' + r + '"/><circle class="arco" cx="50" cy="50" r="' + r + '"/></svg><div class="anillo-c"><b>' + cnt(Math.round(p * 100), 0) + '%</b><span>del objetivo</span></div></div>';
  }
  function insignia(c) { var n = c.estado === "perdida" ? "bad" : c.estado === "fondeada" ? "ok" : c.estado === "pausada" ? "warn" : ""; return '<span class="insignia ' + n + '">' + esc(M.ESTADOS[c.estado] || c.estado) + "</span>"; }
  function consistencia(c) {
    var max = c.raw.consistencia_max_pct, mejor = c.raw.mejor_dia_pct;
    var h = max != null ? "Ningún día puede pasar el " + max + "% de la ganancia" : "";
    if (mejor != null) return { v: '<span class="' + (max != null && mejor > max ? "pierde" : "gana") + '">' + M.pct(mejor, 0) + "</span>", h: h, ok: max == null || mejor <= max, txt: "Tu mejor día pesa el " + M.pct(mejor, 0) + " de la ganancia (límite " + (max != null ? max + "%" : "sin dato") + ")." };
    return { v: c.resultado > 0 ? "Sin dato" : "Sin ganancia aún", h: h, ok: null, txt: max != null ? "Límite: ningún día puede pasar el " + max + "% de la ganancia. Todavía no hay ganancia para medirlo." : "Sin dato." };
  }

  /* ---------- pantallas ---------- */
  function vInicio(r) {
    var hoy = M.hoy(), h = titulo(M.fechaLarga(hoy).replace(/^./, function (c) { return c.toUpperCase(); }), "Hoy");
    h += '<section class="semaforo n-' + r.nivel + '" role="status"><div class="lampara" aria-hidden="true"><i></i><i></i><i></i></div><div><p class="sem-estado">' + ESTADO_TXT[r.nivel] + '</p><p class="sem-frase">' + esc(r.frase) + "</p>" +
      (r.masAlertas > 0 ? '<button class="ver-mas" style="min-height:44px;margin-top:2px" data-act="alertas" type="button">Ver ' + r.masAlertas + (r.masAlertas === 1 ? " aviso más" : " avisos más") + "</button>" : "") + "</div></section>";
    var neto = r.neto;
    h += '<section class="card tres" aria-label="Resumen de plata"><div><span class="etq">Puesto</span><span class="num">' + cnt(r.puesto, r.puesto >= 1e4 ? 0 : 2) + '</span><span class="nota">lo pagado</span></div>' +
      '<div><span class="etq">Cobrado</span><span class="num gana">' + cnt(r.cobrado, r.cobrado >= 1e4 ? 0 : 2) + '</span><span class="nota">lo cobrado</span></div>' +
      '<div><span class="etq">Neto</span><span class="num ' + (neto > 0 ? "gana" : neto < 0 ? "pierde" : "") + '">' + cnt(neto, Math.abs(neto) >= 1e4 ? 0 : 2, true) + '</span><span class="nota">' + (neto > 0 ? "ganancia" : neto < 0 ? "todavía en rojo" : "a mano") + '</span></div><p class="pie-tres">Montos en dólares (US$)</p></section>';
    if (r.retirable > 0) {
      h += '<section class="card"><p class="t">Retiro disponible</p><p class="gran">Podés retirar <br><small>US$</small>' + cnt(r.retirable, 2) + '</p><p class="p">Pedilo desde tu panel de FundedNext.</p></section>';
    } else if (r.enEval) {
      var c = r.enEval;
      h += '<section class="card"><p class="t">Para aprobar faltan</p><p class="gran"><small>US$</small>' + cnt(c.falta, 2) + '</p><p class="p">Tenés que llegar a ' + M.usd(c.objSaldo) + " en " + esc(c.nombre) + "." + (r.cuentas.length > 1 ? " Es la cuenta más cerca." : "") + "</p>" +
        barra(c.progreso, "", "Avance hacia el objetivo") + '<div class="barra-eje"><span>Ganado ' + M.usd(Math.max(0, c.resultado)) + '</span><span>Objetivo ' + M.usd(c.objGan) + "</span></div></section>";
    } else if (r.cuentas.some(function (c) { return c.llegoObjetivo; })) {
      h += '<section class="card"><p class="t">Objetivo cumplido</p><p class="gran">Listo para aprobar</p><p class="p">Pedí la aprobación en FundedNext.</p></section>';
    }
    if (r.tight) {
      var t = r.tight;
      h += '<section class="card"><p class="t">Distancia a perder la cuenta</p><p class="gran"><small>US$</small>' + cnt(Math.max(0, t.margen), 2) + '</p><p class="p">Es lo que podés perder en ' + esc(t.nombre) + " antes de que se pierda. El piso es " + M.usd(t.raw.piso) + ".</p>" +
        barra(t.pctMargen, t.nivel, "Colchón que te queda") + '<div class="barra-eje"><span>Cuenta perdida</span><span>Te queda el ' + M.pct(t.pctMargen * 100, 0) + " de " + M.usd(t.perdidaMax, 0) + "</span></div></section>";
    }
    var sinTxt = r.sinMonto.length ? " Sin contar " + r.sinMonto.map(function (s) { return esc(s.servicio); }).join(" ni ") + " (monto a confirmar)." : "";
    h += '<section class="card"><p class="t">Gasto fijo</p><p class="gran"><small>US$</small>' + cnt(r.gastoMes, 2) + ' <small style="margin:0">por mes</small></p><p class="p">' + M.usd(r.gastoMes * 12) + " por año." + sinTxt + "</p>";
    if (r.proximo) {
      var p = r.proximo;
      h += '<div style="margin-top:10px">' + fila("Próximo pago", M.fecha(p.prox), esc(p.servicio) + (p.monto != null ? " · " + M.usd(p.monto) : "") + " · " + M.enDias(p.dias)) + "</div>";
    } else h += '<div style="margin-top:10px">' + fila("Próximo pago", "Sin fecha", "Cargá la fecha en la suscripción") + "</div>";
    return h + "</section>";
  }

  function vCuentas(r) {
    var n = r.cuentas.filter(function (c) { return c.activa; }).length;
    var h = titulo(n + (n === 1 ? " cuenta activa" : " cuentas activas"), "Cuentas");
    if (!r.cuentas.length) return h + vacio("Todavía no hay cuentas cargadas. Aparecen solas cuando el proceso automático actualiza los datos.");
    r.cuentas.forEach(function (c) {
      var cons = consistencia(c), d = c.raw.dias_operados, dm = c.raw.dias_minimos;
      h += '<button class="card tap" data-act="cuenta" data-id="' + esc(c.id) + '" type="button"><div class="cuenta-top">' + ringSvg(c.progreso, "", false) +
        '<div class="cuenta-id"><h3>' + esc(c.nombre) + '</h3><p style="margin-top:10px">' + insignia(c) + "</p></div></div>" + '<p class="login" style="margin-top:14px">Cuenta ' + esc(c.login) + "</p>" +
        '<p class="saldo"><small>Saldo</small>' + M.usd(c.raw.saldo) + "</p>" +
        '<div class="grilla">' +
        '<div><span class="k">Piso</span><span class="v">' + M.usd(c.raw.piso, 0) + '</span><span class="h">Si bajás de acá, se pierde</span></div>' +
        '<div><span class="k">Margen</span><span class="v ' + (c.nivel === "ok" ? "" : c.nivel === "warn" ? "alerta" : "pierde") + '">' + M.usd(c.margen) + '</span><span class="h">Lo que podés perder</span></div>' +
        '<div><span class="k">Objetivo</span><span class="v">' + M.usd(c.objSaldo, 0) + '</span><span class="h">Ganar ' + M.usd(c.objGan, 0) + " para aprobar</span></div>" +
        '<div><span class="k">Consistencia</span><span class="v">' + cons.v + '</span><span class="h">' + (c.raw.consistencia_max_pct != null ? "Límite " + c.raw.consistencia_max_pct + "% por día" : "") + "</span></div>" +
        '<div><span class="k">Días operados</span><span class="v">' + (d != null ? d : "Sin dato") + '</span><span class="h">' + (dm != null ? "Mínimo " + dm : "Desde " + M.fecha(c.raw.inicio)) + "</span></div>" +
        '<div><span class="k">Resultado</span><span class="v ' + (c.resultado > 0 ? "gana" : c.resultado < 0 ? "pierde" : "") + '">' + M.usdSigno(c.resultado) + '</span><span class="h">Desde que empezó</span></div></div>' +
        '<span class="ver-mas">Ver detalle y qué significa cada cosa' + CHEV + "</span></button>";
    });
    return h;
  }

  function opcionesMes(movs) { return M.porMes(movs).map(function (m) { return m.k; }); }
  function filtrar(res) {
    var f = S.f;
    return res.movs.filter(function (m) { return (f.tipo === "todos" || (f.tipo === "gastos" ? m.tipo !== "cobro" : m.tipo === "cobro")) && (!f.cat || m.categoria === f.cat) && (!f.mes || m.fecha.slice(0, 7) === f.mes); });
  }
  function movRow(m) {
    var cobro = m.tipo === "cobro";
    return '<button class="mov" data-act="mov" data-id="' + esc(m.id) + '" type="button"><span class="mov-ico ' + (cobro ? "cobro" : "gasto") + '"><svg viewBox="0 0 24 24" aria-hidden="true">' + (cobro ? ICO_COBRO : ICO_GASTO) + '</svg></span><span class="mov-txt"><b>' + esc(m.descripcion) + "</b><span>" + M.fechaCorta(m.fecha) + " · " + esc(m.categoria || "Sin categoría") + '</span></span><span class="mov-monto ' + (cobro ? "gana" : "") + '">' + (cobro ? "+" : "−") + M.usd(m.monto) + "</span></button>";
  }
  function libro(res) {
    var l = filtrar(res); S.movsVista = l;
    var sum = l.reduce(function (a, m) { return a + (m.tipo === "cobro" ? m.monto : -m.monto); }, 0);
    var h = "";
    if (!res.movs.length) return vacio("Todavía no hay movimientos. Se cargan solos.");
    if (!l.length) return vacio("No hay movimientos con estos filtros.", '<button class="btn sec" data-act="limpiar" type="button">Limpiar filtros</button>');
    h += '<div class="card lista-card">' + l.map(movRow).join("") + "</div>";
    h += '<div class="fila" style="padding:4px 4px 14px"><span class="k">' + l.length + (l.length === 1 ? " movimiento" : " movimientos") + '</span><span class="v ' + (sum > 0 ? "gana" : sum < 0 ? "pierde" : "") + '">' + M.usdSigno(sum) + "</span></div>";
    return h + '<button class="btn sec block" data-act="exportar" type="button"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v11m0 0-4-4m4 4 4-4M5 19h14"/></svg>Exportar a planilla (CSV)</button>';
  }
  function niceMax(v) { var c = [25, 50, 100, 200, 250, 500, 1000, 2000, 2500, 5000, 10000, 20000, 25000, 50000, 100000]; for (var i = 0; i < c.length; i++) if (v <= c[i]) return c[i]; return Math.ceil(v / 1e5) * 1e5; }
  function chartMeses(res) {
    var hoy = M.hoy(), meses = [], i, mm = {};
    M.porMes(res.movs).forEach(function (m) { mm[m.k] = m; });
    for (i = 5; i >= 0; i--) { var d = new Date(hoy.getFullYear(), hoy.getMonth() - i, 1); var k = d.getFullYear() + "-" + (d.getMonth() < 9 ? "0" : "") + (d.getMonth() + 1); meses.push({ k: k, cobro: (mm[k] || {}).cobro || 0, gasto: (mm[k] || {}).gasto || 0 }); }
    var max = niceMax(Math.max.apply(null, meses.map(function (m) { return Math.max(m.cobro, m.gasto); }).concat([1])));
    var W = 340, H = 190, L = 40, R = 6, T = 14, B = 26, pw = W - L - R, ph = H - T - B, gw = pw / 6, bw = 15;
    var s = '<svg viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="Cobros y gastos por mes, últimos seis meses">';
    [0, 0.5, 1].forEach(function (f) { var y = T + ph - ph * f; s += '<line class="grid" x1="' + L + '" x2="' + (W - R) + '" y1="' + y + '" y2="' + y + '"/><text x="' + (L - 8) + '" y="' + (y + 4) + '" text-anchor="end">' + M.num(max * f, 0) + "</text>"; });
    meses.forEach(function (m, j) {
      var cx = L + gw * j + gw / 2, hc = ph * m.cobro / max, hg = ph * m.gasto / max;
      s += '<g class="col" tabindex="0" role="button" data-k="' + m.k + '" data-co="' + m.cobro + '" data-ga="' + m.gasto + '" aria-label="' + M.mesTxt(m.k) + ": cobrado " + M.usd(m.cobro) + ", gastado " + M.usd(m.gasto) + '"><rect class="hit" x="' + (L + gw * j + 2) + '" y="' + T + '" width="' + (gw - 4) + '" height="' + ph + '"/>';
      if (hc > 0) s += '<rect class="b" x="' + (cx - bw - 2) + '" y="' + (T + ph - Math.max(hc, 3)) + '" width="' + bw + '" height="' + Math.max(hc, 3) + '" rx="4.5" fill="var(--c-cobro)"/>';
      if (hg > 0) s += '<rect class="b" x="' + (cx + 2) + '" y="' + (T + ph - Math.max(hg, 3)) + '" width="' + bw + '" height="' + Math.max(hg, 3) + '" rx="4.5" fill="var(--c-gasto)"/>';
      s += '<text x="' + cx + '" y="' + (H - 6) + '" text-anchor="middle">' + M.mesTxt(m.k, true) + "</text></g>";
    });
    return s + '</svg><div class="tip" id="tip" aria-hidden="true"></div>';
  }
  function vPlata(res) {
    var h = titulo("Libro de movimientos", "Plata");
    var cuotas = res.cuotas, ret = cuotas > 0 ? res.cobrado / cuotas : null;
    h += '<section class="card"><p class="t">Retorno sobre lo pagado en cuentas</p><p class="gran">' + (ret != null ? cnt(Math.round(ret * 100), 0) + "%" : "Sin cuotas") + '</p><p class="p">' +
      (ret != null ? "Cobraste " + M.usd(res.cobrado) + " de los " + M.usd(cuotas) + " que pagaste en cuentas de fondeo. " + (res.cobrado >= cuotas ? "Ya recuperaste todo." : "Te faltan " + M.usd(cuotas - res.cobrado) + " para quedar a mano.") : "Todavía no pagaste cuentas de fondeo.") + "</p>" +
      (ret != null ? barra(Math.min(ret, 1), ret >= 1 ? "ok" : "", "Recuperado de lo pagado") : "") + "</section>";
    h += '<h2 class="sec">Cobros y gastos por mes</h2><section class="card"><div class="leyenda"><span><i style="background:var(--c-cobro)"></i>Cobrado</span><span><i style="background:var(--c-gasto)"></i>Gastado</span></div><div class="grafico" id="graf-meses">' + chartMeses(res) + "</div><p class=\"p\" style=\"margin-top:10px;font-size:13px\">Tocá un mes para ver los montos.</p></section>";
    var meses = M.porMes(res.movs);
    if (meses.length) {
      h += '<h2 class="sec">Totales por mes</h2><section class="card"><table class="tabla"><thead><tr><th scope="col">Mes</th><th scope="col">Cobrado</th><th scope="col">Gastado</th><th scope="col">Neto</th></tr></thead><tbody>' +
        meses.map(function (m) { var n = m.cobro - m.gasto; return "<tr><td>" + M.mesTxt(m.k) .replace(/ \d{4}$/, function (a) { return " '" + a.slice(3); }) + "</td><td>" + M.num(m.cobro) + "</td><td>" + M.num(m.gasto) + '</td><td class="' + (n > 0 ? "gana" : n < 0 ? "pierde" : "") + '">' + (n > 0 ? "+" : "") + M.num(n) + "</td></tr>"; }).join("") + "</tbody></table></section>";
      var cats = M.porCategoria(res.movs, "gasto"), tot = cats.reduce(function (a, c) { return a + c.total; }, 0);
      if (cats.length) h += '<h2 class="sec">Gastos por categoría</h2><section class="card">' + cats.map(function (c) { return '<div class="cat"><div class="cat-top"><span>' + esc(c.cat) + "</span><span>" + M.usd(c.total) + " · " + M.pct(c.total / tot * 100, 0) + "</span></div>" + barra(c.total / tot, "", c.cat) + "</div>"; }).join("") + "</section>";
      var cc = M.porCategoria(res.movs, "cobro");
      if (cc.length) h += '<h2 class="sec">Cobros por categoría</h2><section class="card">' + cc.map(function (c) { return '<div class="cat"><div class="cat-top"><span>' + esc(c.cat) + "</span><span>" + M.usd(c.total) + "</span></div></div>"; }).join("") + "</section>";
    }
    var cats2 = {}; res.movs.forEach(function (m) { cats2[m.categoria || ""] = 1; });
    h += '<h2 class="sec">Libro de movimientos</h2><div class="seg" id="seg-tipo" role="group" aria-label="Tipo de movimiento">' +
      [["todos", "Todo"], ["gastos", "Gastos"], ["cobros", "Cobros"]].map(function (t) { return '<button type="button" data-act="tipo" data-v="' + t[0] + '" aria-pressed="' + (S.f.tipo === t[0]) + '">' + t[1] + "</button>"; }).join("") + "</div>" +
      '<div class="filtros"><select data-f="cat" aria-label="Categoría"><option value="">Categoría</option>' + Object.keys(cats2).filter(Boolean).map(function (c) { return '<option value="' + esc(c) + '"' + (S.f.cat === c ? " selected" : "") + ">" + esc(c) + "</option>"; }).join("") + '</select>' +
      '<select data-f="mes" aria-label="Mes"><option value="">Mes</option>' + opcionesMes(res.movs).map(function (k) { return '<option value="' + k + '"' + (S.f.mes === k ? " selected" : "") + ">" + M.mesTxt(k) + "</option>"; }).join("") + "</select></div>" +
      '<div id="libro">' + libro(res) + "</div>";
    return h;
  }

  function vSubs(res) {
    var h = titulo(res.subs.length + (res.subs.length === 1 ? " servicio" : " servicios"), "Suscripciones");
    h += '<section class="card dos"><div><span class="etq">Por mes</span><p class="gran"><small>US$</small>' + cnt(res.gastoMes, 2) + '</p></div><div><span class="etq">Por año</span><p class="gran"><small>US$</small>' + cnt(res.gastoMes * 12, 2) + "</p></div></section>";
    if (res.sinMonto.length) h += '<p class="p alerta" style="margin:-4px 4px 16px;font-weight:700">Falta confirmar el monto de ' + res.sinMonto.map(function (s) { return esc(s.servicio); }).join(" y ") + ". No está sumado.</p>";
    if (!res.subs.length) return h + vacio("Todavía no hay suscripciones cargadas.");
    var orden = res.subs.slice().sort(function (a, b) { return (a.prox ? a.prox.getTime() : 9e15) - (b.prox ? b.prox.getTime() : 9e15); });
    orden.forEach(function (s) {
      h += '<article class="card"><div class="sub"><div class="sub-ini" aria-hidden="true">' + esc(s.servicio.charAt(0)) + '</div><div class="sub-cuerpo"><h3>' + esc(s.servicio) + '</h3><p class="p" style="margin-top:3px">' + esc(s.para_que || "") + "</p></div>" +
        '<div class="sub-monto">' + (s.monto != null ? M.usd(s.monto) + "<small>" + (M.FREC_TXT[s.frecuencia] || "") + "</small>" : '<span class="alerta">A confirmar</span>') + '</div></div><div class="sub-pie">' +
        (s.prox ? '<span class="pill' + (s.dias <= 3 ? " warn" : "") + '">Próximo pago ' + M.fecha(s.prox) + " · " + M.enDias(s.dias) + "</span>" : '<span class="pill warn">Fecha de pago a confirmar</span>') +
        (s.monto != null && s.frecuencia !== "mensual" ? '<span class="pill">' + M.usd(s.mensual) + " por mes</span>" : "") + "</div></article>";
    });
    return h;
  }

  function relativo(iso) {
    if (!iso) return "nunca";
    var m = Math.round((Date.now() - new Date(iso).getTime()) / 6e4);
    if (m < 1) return "hace un momento"; if (m < 60) return "hace " + m + (m === 1 ? " minuto" : " minutos");
    var hh = Math.round(m / 60); if (hh < 24) return "hace " + hh + (hh === 1 ? " hora" : " horas");
    return "el " + M.fecha(new Date(iso));
  }
  function relCorto(iso) {
    if (!iso) return "Sin actualizar";
    var m = Math.round((Date.now() - new Date(iso).getTime()) / 6e4);
    if (m < 1) return "Recién"; if (m < 60) return "Hace " + m + " min";
    var hh = Math.round(m / 60); return hh < 24 ? "Hace " + hh + " h" : M.fecha(new Date(iso)).slice(0, 5);
  }
  function vAjustes() {
    var tema = ls("mesa.tema") || "auto", url = ls("mesa.url") || "", k = ls("mesa.clave") || "";
    var h = titulo("Conexión y apariencia", "Ajustes");
    h += '<section class="card"><p class="t" style="margin-bottom:14px">De dónde salen los datos</p>' +
      '<label class="campo"><span>URL del endpoint</span><input id="in-url" type="url" inputmode="url" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="https://script.google.com/…/exec" value="' + esc(url) + '"><span class="ayuda">La que te da Apps Script al publicar. Si la dejás vacía, se ven datos de ejemplo.</span></label>' +
      '<label class="campo"><span>Clave</span><span class="clave-wrap"><input id="in-clave" type="password" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="La misma que pusiste en CLAVE" value="' + esc(k) + '"><button type="button" data-act="clave" aria-label="Mostrar u ocultar la clave">Ver</button></span></label>' +
      '<button class="btn block" data-act="guardar" type="button">Guardar y actualizar</button></section>';
    h += '<section class="card"><p class="t">Estado</p>' + fila("Datos", S.fuente === "demo" ? "De ejemplo" : "Tuyos (endpoint)") + fila("Última actualización", S.ultima ? relativo(S.ultima) : "nunca", S.ultima ? new Date(S.ultima).toLocaleString("es-AR") : "") +
      (S.data && S.data.generado ? fila("Datos generados", new Date(S.data.generado).toLocaleString("es-AR")) : "") +
      (S.error ? fila("Último error", '<span class="pierde">' + esc(S.error) + "</span>") : "") +
      '<div style="margin-top:12px"><button class="btn sec block" data-act="actualizar" type="button"' + (S.cargando ? " disabled" : "") + '><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 12a8 8 0 1 1-2.6-5.9M20 4v5h-5"/></svg>Actualizar ahora</button></div><p class="p" style="margin-top:10px;font-size:13px">Se actualiza solo al abrir y cada 15 minutos. También podés tirar hacia abajo en cualquier pantalla.</p></section>';
    h += '<section class="card"><p class="t" style="margin-bottom:12px">Tema</p><div class="seg" role="group" aria-label="Tema">' + [["auto", "Automático"], ["claro", "Claro"], ["oscuro", "Oscuro"]].map(function (t) { return '<button type="button" data-act="tema" data-v="' + t[0] + '" aria-pressed="' + (tema === t[0]) + '">' + t[1] + "</button>"; }).join("") + "</div></section>";
    h += '<section class="card"><p class="t">Avisos en el celular</p><p class="p" style="margin:6px 0 14px">Te avisamos cuando el semáforo pasa a rojo, cuando hay un retiro disponible y 3 días antes de cada pago.</p><button class="btn sec block" data-act="avisos" id="btn-avisos" type="button">Activar avisos</button></section>';
    return h + '<p class="p" style="text-align:center;margin:8px 0 0;font-size:13px">Mesa PRO 1.0 · ar.lucas.mesapro</p>';
  }

  /* ---------- render ---------- */
  function vError(msg) { return titulo("Sin datos", "Ups") + vacio("No pude mostrar los datos. " + esc(msg) + " Si cambiaste la URL o la clave, revisalas en Ajustes.", '<div style="display:grid;gap:10px;justify-items:center"><button class="btn" data-act="actualizar" type="button">Reintentar</button><button class="btn sec" data-act="tab" data-i="4" type="button">Ir a Ajustes</button></div>'); }
  function banner() { return S.fuente === "demo" ? '<button class="banner-demo" data-act="tab" data-i="4" type="button">Estos son datos de ejemplo. Conectá los tuyos en Ajustes.</button>' : ""; }
  function render() {
    try { pintar(); }
    catch (e) {
      S.res = null; S.error = "El archivo tiene un dato mal formado.";
      try { ["inicio", "cuentas", "plata", "subs"].forEach(function (k) { $("#p-" + k + " .contenido").innerHTML = vError(S.error); }); $("#p-ajustes .contenido").innerHTML = vAjustes(); document.body.setAttribute("data-nivel", "bad"); } catch (e2) {}
      estadoChip();
    }
  }
  function pintar() {
    var panels = { inicio: $("#p-inicio .contenido"), cuentas: $("#p-cuentas .contenido"), plata: $("#p-plata .contenido"), subs: $("#p-subs .contenido"), ajustes: $("#p-ajustes .contenido") };
    if (S.data) {
      S.res = M.resumen(S.data, M.hoy(), S.fuente === "demo");
      var bn = banner(); panels.inicio.innerHTML = bn + vInicio(S.res); panels.cuentas.innerHTML = bn + vCuentas(S.res); panels.plata.innerHTML = bn + vPlata(S.res); panels.subs.innerHTML = bn + vSubs(S.res);
      document.body.setAttribute("data-nivel", S.res.nivel);
    } else {
      document.body.setAttribute("data-nivel", S.error ? "bad" : "none");
      ["inicio", "cuentas", "plata", "subs"].forEach(function (k) { panels[k].innerHTML = S.error ? vError(S.error) : skeleton(); });
    }
    panels.ajustes.innerHTML = vAjustes();
    estadoChip(); pintarAvisosBtn();
    $$(".panel").forEach(function (p, i) { if (S.listo && (p.classList.contains("vivo") || i === S.tab)) p.classList.add("vivo"); });
  }
  function estadoChip() {
    var chip = $("#chip"), tx = $("#chip-txt"), c = "chip-estado", t;
    if (S.cargando) { c += " cargando"; t = "Actualizando…"; }
    else if (S.error && !S.data) { c += " error"; t = "Sin datos"; }
    else if (S.fuente === "demo") { c += " ejemplo"; t = "Datos de ejemplo"; }
    else if (S.error) { c += " error"; t = "Sin conexión · " + relativo(S.ultima); }
    else t = relCorto(S.ultima);
    chip.className = c; tx.textContent = t;
    chip.setAttribute("aria-label", (S.fuente === "demo" || S.error || S.cargando ? t : "Actualizado " + relativo(S.ultima)) + (S.fuente === "demo" ? ". Tocá para conectar tus datos." : ". Tocá para actualizar."));
  }

  /* ---------- animaciones ---------- */
  function animar(raiz) {
    $$("[data-c]", raiz).forEach(function (el) {
      var to = +el.getAttribute("data-c"), dec = +el.getAttribute("data-d"), sg = el.hasAttribute("data-s");
      if (reducido || !isFinite(to) || to === 0) return;
      var t0 = null, dur = 1000;
      (function paso(t) {
        if (t0 == null) t0 = t;
        var p = M.clamp((t - t0) / dur, 0, 1), e = 1 - Math.pow(1 - p, 4), v = to * e;
        el.textContent = (sg && to > 0 ? "+" : "") + M.num(p === 1 ? to : v, dec);
        if (p < 1) requestAnimationFrame(paso);
      })(performance.now());
    });
  }
  function activarPanel(i) {
    var p = $$(".panel")[i];
    if (p.dataset.visto) return;
    p.dataset.visto = "1";
    animar(p);
    requestAnimationFrame(function () { requestAnimationFrame(function () { p.classList.add("vivo"); }); });
  }

  /* ---------- pager / tabs ---------- */
  var pager = $("#pager"), pista = $("#pista"), tabsEl = $("#tabs"), ind;
  function W() { return pager.clientWidth; }
  function setX(px) { pista.style.transform = "translate3d(" + px + "px,0,0)"; }
  function setInd(frac) { if (ind) ind.style.transform = "translate3d(" + (frac * 100) + "%,0,0)"; }
  function irA(i, quieto) {
    i = M.clamp(i, 0, 4);
    var cambio = i !== S.tab;
    S.tab = i;
    pista.classList.remove("arrastrando");
    setX(-i * W()); setInd(i);
    $$(".tab").forEach(function (b, j) { if (j === i) b.setAttribute("aria-current", "page"); else b.removeAttribute("aria-current"); });
    $$(".panel").forEach(function (p, j) { if (j === i) { p.removeAttribute("inert"); p.removeAttribute("aria-hidden"); } else { p.setAttribute("inert", ""); p.setAttribute("aria-hidden", "true"); } });
    if (cambio && !quieto) M.hap("s");
    if (S.listo) activarPanel(i);
  }
  tabsEl.innerHTML = '<div class="tab-ind" id="tab-ind"><i></i></div>' + TABS.map(function (t, i) { return '<button class="tab" type="button" data-act="tab" data-i="' + i + '"><svg viewBox="0 0 24 24" aria-hidden="true">' + t.i + "</svg><span>" + t.t + "</span></button>"; }).join("");
  ind = $("#tab-ind");

  var g = null, ptr = $("#ptr"), refrescando = false;
  function panelAct() { return $$(".panel")[S.tab]; }
  pager.addEventListener("touchstart", function (e) {
    if (sheetAbierto || e.touches.length > 1 || refrescando) { g = null; return; }
    var t = e.touches[0]; g = { x: t.clientX, y: t.clientY, t0: Date.now(), eje: null, dx: 0, pull: 0, top: panelAct().scrollTop <= 0 };
  }, { passive: true });
  pager.addEventListener("touchmove", function (e) {
    if (!g) return;
    var t = e.touches[0], dx = t.clientX - g.x, dy = t.clientY - g.y;
    if (!g.eje) {
      if (Math.abs(dx) > 10 && Math.abs(dx) > Math.abs(dy) * 1.3) { g.eje = "h"; pista.classList.add("arrastrando"); }
      else if (Math.abs(dy) > 10) g.eje = "v";
      else return;
    }
    if (g.eje === "h") {
      var off = dx; if ((S.tab === 0 && dx > 0) || (S.tab === 4 && dx < 0)) off = dx / 3;
      g.dx = off; setX(-S.tab * W() + off); setInd(S.tab - off / W());
    } else if (g.top && dy > 0 && panelAct().scrollTop <= 0) {
      var pull = Math.min(dy * 0.5, 110), c = $(".contenido", panelAct());
      g.pull = pull; c.classList.remove("vuelve"); c.style.transform = "translate3d(0," + pull + "px,0)";
      ptr.style.opacity = Math.min(pull / 56, 1); ptr.style.transform = "translate3d(0," + (pull - 52) + "px,0) rotate(" + (pull * 4) + "deg)";
    }
  }, { passive: true });
  function finGesto() {
    if (!g) return;
    var q = g; g = null;
    if (q.eje === "h") {
      var v = q.dx / Math.max(1, Date.now() - q.t0), n = S.tab;
      if (q.dx < -W() * 0.2 || v < -0.45) n++; else if (q.dx > W() * 0.2 || v > 0.45) n--;
      irA(n, true); if (n !== S.tab || true) { if (Math.abs(q.dx) > 30) M.hap("s"); }
    } else if (q.eje === "v" && q.pull) {
      var c = $(".contenido", panelAct()); c.classList.add("vuelve");
      if (q.pull >= 62) { M.hap("m"); c.style.transform = "translate3d(0,58px,0)"; ptr.style.transform = "translate3d(0,6px,0)"; ptr.classList.add("girando"); refrescando = true; actualizar(true).then(function () { refrescando = false; ptr.classList.remove("girando"); c.style.transform = ""; ptr.style.opacity = 0; ptr.style.transform = "translate3d(0,-60px,0)"; }); }
      else { c.style.transform = ""; ptr.style.opacity = 0; ptr.style.transform = "translate3d(0,-60px,0)"; }
    }
  }
  pager.addEventListener("touchend", finGesto, { passive: true });
  pager.addEventListener("touchcancel", finGesto, { passive: true });
  window.addEventListener("resize", function () { pista.classList.add("arrastrando"); setX(-S.tab * W()); requestAnimationFrame(function () { pista.classList.remove("arrastrando"); }); });

  /* ---------- sheet ---------- */
  var sheet = $("#sheet"), velo = $("#velo"), sCuerpo = $("#sheet-b"), sheetAbierto = false, foco = null, histPush = false;
  function abrirSheet(titulo, html, opts) {
    foco = document.activeElement; $("#sheet-t").textContent = titulo; sCuerpo.innerHTML = html; sCuerpo.scrollTop = 0; sCuerpo.classList.remove("vivo");
    sheet.style.transform = ""; sheet.classList.remove("arrastrando"); sheetAbierto = true;
    requestAnimationFrame(function () { sheet.classList.add("on"); velo.classList.add("on"); requestAnimationFrame(function () { sCuerpo.classList.add("vivo"); animar(sCuerpo); }); });
    try { history.pushState({ sheet: 1 }, ""); histPush = true; } catch (e) {}
    pager.setAttribute("inert", ""); M.hap("l");
    setTimeout(function () { $("#sheet-x").focus({ preventScroll: true }); }, 60);
    if (opts && opts.alAbrir) opts.alAbrir(sCuerpo);
  }
  function cerrarSheet(desdeHistoria) {
    if (!sheetAbierto) return;
    sheetAbierto = false; sheet.classList.remove("arrastrando"); sheet.style.transform = ""; sheet.classList.remove("on"); velo.classList.remove("on"); velo.style.opacity = "";
    pager.removeAttribute("inert");
    if (histPush && !desdeHistoria) { histPush = false; try { history.back(); } catch (e) {} } else histPush = false;
    if (foco && foco.focus) try { foco.focus({ preventScroll: true }); } catch (e) {}
    M.hap("l");
  }
  window.addEventListener("popstate", function () { if (sheetAbierto) { histPush = false; cerrarSheet(true); } });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") cerrarSheet(); });
  velo.addEventListener("click", function () { cerrarSheet(); });
  $("#sheet-x").addEventListener("click", function () { cerrarSheet(); });
  (function () {
    var d = null;
    sheet.addEventListener("touchstart", function (e) {
      var t = e.touches[0], enCab = !!e.target.closest("#sheet-cab");
      d = { y: t.clientY, t0: Date.now(), cab: enCab, arr: false, dy: 0 };
    }, { passive: true });
    sheet.addEventListener("touchmove", function (e) {
      if (!d) return;
      var dy = e.touches[0].clientY - d.y;
      if (!d.arr) { if (dy > 8 && (d.cab || sCuerpo.scrollTop <= 0)) { d.arr = true; d.y = e.touches[0].clientY; dy = 0; sheet.classList.add("arrastrando"); } else return; }
      dy = Math.max(0, dy); d.dy = dy; sheet.style.transform = "translate3d(0," + dy + "px,0)"; velo.style.opacity = String(Math.max(0, 1 - dy / 420));
    }, { passive: true });
    function fin() {
      if (!d) return; var q = d; d = null;
      if (!q.arr) return;
      var v = q.dy / Math.max(1, Date.now() - q.t0);
      if (q.dy > 110 || v > 0.6) cerrarSheet();
      else { sheet.classList.remove("arrastrando"); sheet.style.transform = ""; velo.style.opacity = ""; }
    }
    sheet.addEventListener("touchend", fin, { passive: true }); sheet.addEventListener("touchcancel", fin, { passive: true });
  })();

  function sheetCuenta(id) {
    var c = S.res.cuentas.filter(function (x) { return x.id === id; })[0]; if (!c) return;
    var cons = consistencia(c), d = c.raw.dias_operados, dm = c.raw.dias_minimos;
    var h = '<div class="cuenta-top">' + ringSvg(c.progreso, "", false) + '<div class="cuenta-id">' + insignia(c) + '<p class="etq" style="margin-top:14px">Resultado</p><p class="num ' + (c.resultado > 0 ? "gana" : c.resultado < 0 ? "pierde" : "") + '" style="font-size:21px">' + M.usdSigno(c.resultado) + '</p></div></div><p class="saldo"><small>Saldo</small>' + M.usd(c.raw.saldo) + '</p><p class="login" style="margin-top:6px">Cuenta ' + esc(c.login) + "</p>";
    h += '<h2 class="sec">Cómo vas con las reglas</h2><div>' +
      '<div class="check">' + (c.margen > 0 ? OK : MAL) + "<div><b>Piso de " + M.usd(c.raw.piso, 0) + "</b><br><span class=\"suave\">" + (c.margen > 0 ? "Estás " + M.usd(c.margen) + " arriba. Te queda el " + M.pct((c.pctMargen || 0) * 100, 0) + " del colchón." : "Tocaste el piso: la cuenta se pierde.") + "</span></div></div>" +
      '<div class="check">' + (c.llegoObjetivo ? OK : NO) + "<div><b>Objetivo de " + M.usd(c.objSaldo, 0) + "</b><br><span class=\"suave\">" + (c.llegoObjetivo ? "Lo alcanzaste." : "Faltan " + M.usd(c.falta) + " para aprobar.") + "</span></div></div>" +
      '<div class="check">' + (cons.ok === true ? OK : cons.ok === false ? MAL : NO) + "<div><b>Consistencia</b><br><span class=\"suave\">" + cons.txt + "</span></div></div>" +
      (dm != null ? '<div class="check">' + (d != null && d >= dm ? OK : NO) + "<div><b>Días operados</b><br><span class=\"suave\">" + (d != null ? d : "Sin dato") + " de " + dm + " mínimos.</span></div></div>" : "") + "</div>";
    if (c.raw.historial_saldo && c.raw.historial_saldo.length > 1) h += '<h2 class="sec">Saldo día a día</h2><div class="grafico" id="graf-saldo">' + lineaSaldo(c) + "</div>";
    h += '<h2 class="sec">Qué significa cada cosa</h2><div class="glosario">' +
      fila("Saldo", "La plata que hay hoy en la cuenta.") + fila("Piso", "El saldo mínimo. Si bajás de ahí, se pierde la cuenta (se llama pérdida máxima).") + fila("Margen", "Cuánto te queda por perder antes de llegar al piso.") +
      fila("Objetivo", "El saldo que hay que alcanzar para aprobar la evaluación.") + fila("Consistencia", "Regla que evita que un solo día explique casi toda la ganancia.") + fila("Días operados", "Días en que hiciste al menos una operación.") + "</div>";
    abrirSheet(c.nombre, h, { alAbrir: function (b) { var gr = $("#graf-saldo", b); if (gr) tooltipLinea(gr, c); } });
  }
  function lineaSaldo(c) {
    var pts = c.raw.historial_saldo.map(function (p) { return { f: p.fecha, v: p.saldo }; }), W = 340, H = 170, L = 46, R = 8, T = 12, B = 22;
    var vs = pts.map(function (p) { return p.v; }).concat([c.raw.piso, c.objSaldo].filter(function (x) { return x != null; }));
    var mn = Math.min.apply(null, vs), mx = Math.max.apply(null, vs), pad = (mx - mn) * 0.08 || 1; mn -= pad; mx += pad;
    function X(i) { return L + (W - L - R) * (pts.length === 1 ? 0.5 : i / (pts.length - 1)); } function Y(v) { return T + (H - T - B) * (1 - (v - mn) / (mx - mn)); }
    var d = pts.map(function (p, i) { return (i ? "L" : "M") + X(i).toFixed(1) + " " + Y(p.v).toFixed(1); }).join(" ");
    var s = '<svg viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="Evolución del saldo">';
    [[c.raw.piso, "Piso", "var(--l-bad)"], [c.objSaldo, "Objetivo", "var(--l-ok)"]].forEach(function (l) { if (l[0] != null) s += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + Y(l[0]) + '" y2="' + Y(l[0]) + '" stroke="' + l[2] + '" stroke-dasharray="4 4" opacity=".7"/><text x="' + (L - 6) + '" y="' + (Y(l[0]) + 4) + '" text-anchor="end">' + M.num(l[0], 0) + "</text>"; });
    s += '<path d="' + d + '" fill="none" stroke="var(--acento)" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round"/><circle id="punto" r="5" cx="' + X(pts.length - 1) + '" cy="' + Y(pts[pts.length - 1].v) + '" fill="var(--acento)" stroke="var(--panel)" stroke-width="2"/>';
    s += '<rect id="area" x="' + L + '" y="0" width="' + (W - L - R) + '" height="' + H + '" fill="transparent"/><text x="' + L + '" y="' + (H - 4) + '">' + M.fecha(pts[0].f).slice(0, 5) + '</text><text x="' + (W - R) + '" y="' + (H - 4) + '" text-anchor="end">' + M.fecha(pts[pts.length - 1].f).slice(0, 5) + "</text></svg><div class=\"tip\" id=\"tip2\"></div>";
    c._pts = pts; c._geo = { W: W, H: H, L: L, R: R, X: X, Y: Y };
    return s;
  }
  function tooltipLinea(cont, c) {
    var area = $("#area", cont), tip = $("#tip2", cont), pt = $("#punto", cont), pts = c._pts, geo = c._geo;
    function mover(ev) {
      var r = cont.getBoundingClientRect(), x = (ev.clientX - r.left) / r.width * geo.W, best = 0, bd = 1e9;
      pts.forEach(function (p, i) { var dd = Math.abs(geo.X(i) - x); if (dd < bd) { bd = dd; best = i; } });
      var p = pts[best]; pt.setAttribute("cx", geo.X(best)); pt.setAttribute("cy", geo.Y(p.v));
      tip.innerHTML = "<b>" + M.fecha(p.f) + "</b>" + M.usd(p.v); tip.classList.add("on");
      var px = geo.X(best) / geo.W * r.width; tip.style.left = M.clamp(px - 66, 0, r.width - 140) + "px"; tip.style.top = "0px";
    }
    area.addEventListener("pointerdown", mover); area.addEventListener("pointermove", function (e) { if (e.buttons || e.pointerType === "touch") mover(e); });
  }
  function sheetMov(id) {
    var m = S.res.movs.filter(function (x) { return x.id === id; })[0]; if (!m) return;
    var cobro = m.tipo === "cobro", d = m.detalle || {}, cu = S.res.cuentas.filter(function (c) { return c.id === m.cuenta_id; })[0];
    var h = '<p class="etq">' + (cobro ? "Cobraste" : "Pagaste") + '</p><p class="gran ' + (cobro ? "gana" : "") + '" style="font-size:40px">' + (cobro ? "+" : "−") + M.usd(m.monto) + "</p>" +
      '<div style="margin-top:8px">' + fila("Fecha", M.fecha(m.fecha)) + fila("Tipo", cobro ? "Cobro" : "Gasto") + fila("Categoría", esc(m.categoria || "Sin categoría")) + (cu ? fila("Cuenta", esc(cu.nombre), esc(cu.login)) : "") +
      (d.precio_lista != null ? fila("Precio de lista", M.usd(d.precio_lista)) : "") + (d.descuento != null ? fila("Descuento", M.usd(d.descuento), d.precio_lista ? "Ahorraste el " + M.pct(d.descuento / d.precio_lista * 100, 0) : "") : "") +
      (d.medio_pago ? fila("Medio de pago", esc(d.medio_pago)) : "") + (d.nota ? fila("Nota", esc(d.nota)) : "") + "</div>";
    abrirSheet(m.descripcion, h);
  }
  function sheetAlertas() {
    var h = S.res.alertas.map(function (a) { var n = a.nivel; return '<div class="check">' + (n === "bad" ? MAL : n === "warn" ? '<svg class="no" style="stroke:var(--alerta)" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4 3 20h18z"/><path d="M12 10v4M12 17v.5"/></svg>' : OK) + "<div><b>" + ESTADO_TXT[n] + "</b><br><span class=\"suave\">" + esc(a.texto) + "</span></div></div>"; }).join("");
    abrirSheet("Avisos", h || vacio("No hay avisos."));
  }
  function sheetExportar() {
    var n = S.movsVista.length;
    abrirSheet("Exportar a planilla", '<p class="p" style="margin-bottom:18px">Se exportan los ' + n + (n === 1 ? " movimiento" : " movimientos") + ' que ves ahora. Es un archivo CSV: se abre en Google Sheets y en Excel, con coma para los decimales.</p><div style="display:grid;gap:12px"><button class="btn block" data-act="compartir" type="button">Guardar o compartir el archivo</button><button class="btn sec block" data-act="copiar" type="button">Copiar para pegar en la planilla</button></div>');
  }
  function csvActual() { return M.csv(S.movsVista, S.res.cuentas); }
  function compartir() {
    var csv = csvActual(), nombre = "mesa-movimientos-" + M.iso(M.hoy()) + ".csv", P = window.Capacitor && Capacitor.Plugins;
    if (P && P.Filesystem && P.Share) {
      P.Filesystem.writeFile({ path: nombre, data: csv, directory: "CACHE", encoding: "utf8" }).then(function (r) { return P.Share.share({ title: "Movimientos Mesa PRO", url: r.uri, dialogTitle: "Guardar o enviar" }); }).catch(function (e) { if (!/cancel/i.test(String(e && e.message))) toast("No pude armar el archivo. Probá con Copiar."); });
      return;
    }
    var a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" })); a.download = nombre; document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); toast("Archivo listo"); M.hap("ok");
  }
  function copiar() {
    var csv = csvActual().replace(/^﻿/, "");
    function listo() { toast("Copiado. Pegalo en tu planilla."); M.hap("ok"); }
    function viejo() { var t = document.createElement("textarea"); t.value = csv; t.style.cssText = "position:fixed;opacity:0"; document.body.appendChild(t); t.select(); try { document.execCommand("copy"); listo(); } catch (e) { toast("No pude copiar."); } t.remove(); }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(csv).then(listo, viejo); else viejo();
  }

  /* tooltip del grafico de barras */
  function tooltipMeses() {
    var cont = $("#graf-meses"); if (!cont) return;
    var tip = $("#tip", cont);
    function mostrar(col) {
      $$("g.col", cont).forEach(function (x) { x.classList.toggle("sel", x === col); });
      var r = cont.getBoundingClientRect(), b = col.querySelector(".hit").getBoundingClientRect();
      tip.innerHTML = "<b>" + M.mesTxt(col.dataset.k) + '</b><i style="background:var(--c-cobro)"></i>Cobrado ' + M.usd(+col.dataset.co) + '<br><i style="background:var(--c-gasto)"></i>Gastado ' + M.usd(+col.dataset.ga);
      tip.classList.add("on"); M.hap("s");
      var x = b.left - r.left + b.width / 2 - 70; tip.style.left = M.clamp(x, 0, r.width - 150) + "px"; tip.style.top = "0px";
    }
    cont.addEventListener("click", function (e) { var c = e.target.closest("g.col"); if (c) mostrar(c); else { tip.classList.remove("on"); $$("g.col.sel", cont).forEach(function (x) { x.classList.remove("sel"); }); } });
    cont.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { var c = e.target.closest("g.col"); if (c) { e.preventDefault(); mostrar(c); } } });
  }

  var toastT;
  function toast(t) { var el = $("#toast"); el.textContent = t; el.classList.add("on"); clearTimeout(toastT); toastT = setTimeout(function () { el.classList.remove("on"); }, 2600); }

  /* ---------- datos ---------- */
  function actualizar(manual) {
    if (S.cargando) return Promise.resolve();
    S.cargando = true; estadoChip();
    var url = (ls("mesa.url") || "").trim(), k = ls("mesa.clave") || "", ctrl = window.AbortController ? new AbortController() : null, to = setTimeout(function () { if (ctrl) ctrl.abort(); }, 8000);
    var p;
    if (!url) p = fetch("data/demo.json", { cache: "no-store", signal: ctrl && ctrl.signal }).then(function (r) { if (!r.ok) throw new Error("No encontré los datos de ejemplo."); return r.json(); }).then(function (d) { S.fuente = "demo"; return d; });
    else p = fetch(url + (url.indexOf("?") > -1 ? "&" : "?") + "k=" + encodeURIComponent(k), { cache: "no-store", signal: ctrl && ctrl.signal }).then(function (r) { if (!r.ok) throw new Error("El servidor contestó " + r.status + "."); return r.json(); }).then(function (j) {
      if (j && j.ok === false) throw new Error(j.error === "clave" ? "La clave no coincide con la del script." : j.error === "no_archivo" ? "No encuentro mesa-datos.json en tu Drive." : "El script devolvió un error.");
      if (!j || !Array.isArray(j.cuentas)) throw new Error("El archivo no tiene el formato esperado.");
      S.fuente = "endpoint"; ls("mesa.cache", JSON.stringify(j)); return j;
    });
    return p.then(function (d) {
      S.data = d; S.error = null; S.ultima = new Date().toISOString(); ls("mesa.ultima", S.ultima);
      if (manual) { toast("Datos actualizados"); M.hap("ok"); }
    }).catch(function (e) {
      var m = e && e.name === "AbortError" ? "Tardó más de 8 segundos en responder. Revisá tu conexión." : e instanceof SyntaxError ? "La URL no devuelve datos. Revisá que la implementación sea para \"Cualquier persona\"." : e instanceof TypeError ? "No hay conexión o la URL no es correcta." : (e && e.message) || "Falló la actualización.";
      S.error = m; if (manual) { toast(m); M.hap("mal"); }
    }).then(function () {
      clearTimeout(to); S.cargando = false; var y = scrollSave(), primera = S.listo && S.data && !S.tuvoDatos; if (S.data) S.tuvoDatos = true;
      render(); scrollRestore(y); tooltipMeses();
      if (primera) { $$(".panel").forEach(function (pn) { delete pn.dataset.visto; pn.classList.remove("vivo"); }); activarPanel(S.tab); }
      if (S.res) M.avisar(S.res, S.fuente === "demo");
    });
  }
  function scrollSave() { return $$(".panel").map(function (p) { return p.scrollTop; }); }
  function scrollRestore(a) { $$(".panel").forEach(function (p, i) { p.scrollTop = a[i] || 0; }); }

  /* ---------- tema, avisos ---------- */
  function aplicarTema() { var t = ls("mesa.tema") || "auto", r = document.documentElement; if (t === "auto") r.removeAttribute("data-tema"); else r.setAttribute("data-tema", t); }
  function pintarAvisosBtn() {
    var b = $("#btn-avisos"); if (!b) return;
    M.avisosEstado().then(function (e) { b.textContent = e === "granted" ? "Avisos activados" : e === "denied" ? "Bloqueados: activalos en los ajustes del celular" : e === "unsupported" ? "Este navegador no permite avisos" : "Activar avisos"; b.disabled = e === "granted" || e === "unsupported"; });
  }

  /* ---------- eventos ---------- */
  document.addEventListener("click", function (e) {
    var el = e.target.closest("[data-act]"); if (!el) return;
    var a = el.dataset.act;
    if (a === "tab") { irA(+el.dataset.i); }
    else if (a === "chip") { if (S.fuente === "demo") irA(4); else { M.hap("l"); actualizar(true); } }
    else if (a === "cuenta") sheetCuenta(el.dataset.id);
    else if (a === "mov") sheetMov(el.dataset.id);
    else if (a === "alertas") sheetAlertas();
    else if (a === "exportar") sheetExportar();
    else if (a === "compartir") compartir();
    else if (a === "copiar") copiar();
    else if (a === "tipo") { S.f.tipo = el.dataset.v; $$("#seg-tipo button").forEach(function (b) { b.setAttribute("aria-pressed", String(b === el)); }); $("#libro").innerHTML = libro(S.res); M.hap("s"); }
    else if (a === "limpiar") { S.f = { tipo: "todos", cat: "", mes: "" }; render(); }
    else if (a === "actualizar") { M.hap("l"); actualizar(true); }
    else if (a === "guardar") {
      var nu = $("#in-url").value.trim(), viejo = (ls("mesa.url") || "").trim();
      ls("mesa.url", nu); ls("mesa.clave", $("#in-clave").value.trim());
      if (!nu) { ls("mesa.cache", null); S.fuente = "demo"; }
      else if (S.fuente === "demo" || nu !== viejo) { S.data = null; S.res = null; S.error = null; S.tuvoDatos = false; S.fuente = "endpoint"; ls("mesa.cache", null); render(); }
      M.hap("m"); actualizar(true);
    }
    else if (a === "clave") { var i = $("#in-clave"); i.type = i.type === "password" ? "text" : "password"; el.textContent = i.type === "password" ? "Ver" : "Ocultar"; }
    else if (a === "tema") { ls("mesa.tema", el.dataset.v); aplicarTema(); $$("[data-act=tema]").forEach(function (b) { b.setAttribute("aria-pressed", String(b === el)); }); M.hap("s"); }
    else if (a === "avisos") { M.avisosPedir().then(function (r) { pintarAvisosBtn(); if (r === "granted") { toast("Avisos activados"); M.hap("ok"); if (S.res) M.avisar(S.res, S.fuente === "demo"); } }); }
  });
  document.addEventListener("change", function (e) {
    var f = e.target.dataset && e.target.dataset.f; if (!f) return;
    S.f[f] = e.target.value; $("#libro").innerHTML = libro(S.res); M.hap("s");
  });
  document.addEventListener("visibilitychange", function () { if (!document.hidden && (!S.ultima || Date.now() - new Date(S.ultima).getTime() > INTERVALO)) actualizar(false); });

  /* ---------- arranque ---------- */
  aplicarTema();
  irA(0, true);
  var cache = null; try { cache = JSON.parse(ls("mesa.cache")); } catch (e) {}
  if ((ls("mesa.url") || "").trim() && cache && cache.cuentas) { S.data = cache; S.fuente = "endpoint"; S.ultima = ls("mesa.ultima"); }
  render();
  var t0 = Date.now();
  function revelar() {
    var espera = Math.max(0, (reducido ? 200 : 1100) - (Date.now() - t0));
    setTimeout(function () {
      S.listo = true; $("#splash").classList.add("fuera"); setTimeout(function () { $("#splash").remove(); }, 600);
      activarPanel(S.tab); tooltipMeses();
    }, espera);
  }
  if (S.data) S.tuvoDatos = true;
  actualizar(false); revelar();
  setInterval(function () { actualizar(false); }, INTERVALO);
  setInterval(estadoChip, 30000);
})();
