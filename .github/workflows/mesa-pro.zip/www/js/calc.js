/* Mesa PRO - formato y cuentas. Sin dependencias. */
(function (g) {
  var M = g.Mesa = g.Mesa || {};
  var CAT_CUENTAS = "Cuentas de fondeo";
  var MESES = ["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];
  var DIAS = ["domingo","lunes","martes","miércoles","jueves","viernes","sábado"];
  var FREC = { semanal: 12 / 52, mensual: 1, bimestral: 2, trimestral: 3, semestral: 6, anual: 12 };
  var FREC_TXT = { semanal: "por semana", mensual: "por mes", bimestral: "cada 2 meses", trimestral: "cada 3 meses", semestral: "cada 6 meses", anual: "por año" };
  M.CAT_CUENTAS = CAT_CUENTAS; M.MESES = MESES; M.FREC_TXT = FREC_TXT;

  function parseISO(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || "");
    return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
  }
  function iso(d) { return d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate()); }
  function p2(n) { return (n < 10 ? "0" : "") + n; }
  M.parseISO = parseISO; M.iso = iso;
  M.hoy = function () {
    var q = null;
    try { if (!(g.Capacitor && g.Capacitor.isNativePlatform && g.Capacitor.isNativePlatform())) q = new URLSearchParams(location.search).get("hoy"); } catch (e) {}
    var d = q ? parseISO(q) : null;
    if (d) return d;
    var n = new Date(); return new Date(n.getFullYear(), n.getMonth(), n.getDate());
  };
  M.fecha = function (s) { var d = typeof s === "string" ? parseISO(s) : s; return d ? p2(d.getDate()) + "/" + p2(d.getMonth() + 1) + "/" + d.getFullYear() : "—"; };
  M.fechaCorta = function (s) { var d = parseISO(s); if (!d) return "—"; return d.getDate() + " " + MESES[d.getMonth()].slice(0, 3) + (d.getFullYear() !== M.hoy().getFullYear() ? " " + d.getFullYear() : ""); };
  M.fechaLarga = function (d) { return DIAS[d.getDay()] + " " + d.getDate() + " de " + MESES[d.getMonth()]; };
  M.diasEntre = function (a, b) { return Math.round((b - a) / 864e5); };
  M.enDias = function (n) { return n === 0 ? "hoy" : n === 1 ? "mañana" : n > 1 ? "en " + n + " días" : "hace " + (-n) + (n === -1 ? " día" : " días"); };

  M.num = function (n, dec) {
    if (n == null || isNaN(n)) return "—";
    dec = dec == null ? 2 : dec;
    var neg = n < 0 && Math.round(Math.abs(n) * Math.pow(10, dec)) > 0;
    var s = Math.abs(n).toFixed(dec).split(".");
    s[0] = s[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    return (neg ? "−" : "") + s.join(",");
  };
  M.usd = function (n, dec) { if (n == null || isNaN(n)) return "—"; var t = M.num(Math.abs(n), dec); return (n < 0 && t !== M.num(0, dec) ? "−" : "") + "US$ " + t; };
  M.usdSigno = function (n) { return (n > 0 ? "+" : "") + M.usd(n); };
  M.pct = function (n, dec) { return M.num(n, dec == null ? 0 : dec) + "%"; };
  M.esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  M.clamp = function (x, a, b) { return Math.max(a, Math.min(b, x)); };

  M.esManual = function (e) { return !!e && (e.origen === "manual" || /^man-/.test(String(e.id || ""))); };
  M.ESTADOS = { evaluacion: "En evaluación", fondeada: "Fondeada", aprobada: "Aprobada", perdida: "Perdida", pausada: "Pausada" };

  M.cuenta = function (c) {
    var inicial = c.saldo_inicial != null ? c.saldo_inicial : (c.objetivo_saldo != null && c.objetivo_ganancia != null ? c.objetivo_saldo - c.objetivo_ganancia : c.saldo);
    var objSaldo = c.objetivo_saldo != null ? c.objetivo_saldo : (c.objetivo_ganancia != null ? inicial + c.objetivo_ganancia : null);
    var objGan = c.objetivo_ganancia != null ? c.objetivo_ganancia : (objSaldo != null ? objSaldo - inicial : null);
    var perdidaMax = c.piso != null ? inicial - c.piso : null;
    var margen = c.piso != null ? c.saldo - c.piso : null;
    var pctMargen = perdidaMax > 0 ? M.clamp(margen / perdidaMax, 0, 1) : null;
    var resultado = c.saldo - inicial;
    var progreso = objGan > 0 ? M.clamp(resultado / objGan, 0, 1) : 0;
    var activa = c.estado === "evaluacion" || c.estado === "fondeada" || c.estado === "aprobada" || !c.estado;
    var nivel = "ok";
    if (c.estado === "perdida" || (margen != null && margen <= 0)) nivel = "bad";
    else if (pctMargen != null && activa) nivel = pctMargen < 0.25 ? "bad" : pctMargen < 0.5 ? "warn" : "ok";
    return {
      raw: c, id: c.id, nombre: c.nombre || c.tipo || "Cuenta", tipo: c.tipo || c.nombre, login: c.id, inicial: inicial, objSaldo: objSaldo, objGan: objGan,
      perdidaMax: perdidaMax, margen: margen, pctMargen: pctMargen, resultado: resultado, progreso: progreso,
      falta: objSaldo != null ? Math.max(0, objSaldo - c.saldo) : null,
      llegoObjetivo: objSaldo != null && c.saldo >= objSaldo, activa: activa, nivel: nivel,
      retirable: c.retirable > 0 ? c.retirable : 0, estado: c.estado || "evaluacion",
      manual: M.esManual(c), nota: c.nota || "", payout: c.payout && typeof c.payout === "object" ? c.payout : null
    };
  };

  function ultimoDia(y, m) { return new Date(y, m + 1, 0).getDate(); }
  /* Próxima fecha >= hoy, siempre calculada desde la fecha ancla (sin arrastrar el corrimiento de fin de mes). */
  M.proximoPago = function (s, hoy) {
    var a = parseISO(s.proximo_pago);
    if (!a) return null;
    if (a >= hoy) return a;
    if (s.frecuencia === "semanal") return new Date(a.getFullYear(), a.getMonth(), a.getDate() + 7 * Math.ceil(M.diasEntre(a, hoy) / 7));
    var paso = FREC[s.frecuencia] || 1, dif = (hoy.getFullYear() - a.getFullYear()) * 12 + (hoy.getMonth() - a.getMonth());
    var k = Math.max(1, Math.floor(dif / paso)), guard = 0;
    function cand(n) { var t = new Date(a.getFullYear(), a.getMonth() + n * paso, 1); return new Date(t.getFullYear(), t.getMonth(), Math.min(a.getDate(), ultimoDia(t.getFullYear(), t.getMonth()))); }
    while (cand(k) < hoy && guard++ < 600) k++;
    return cand(k);
  };
  M.mensual = function (s) { return s.monto == null ? null : s.monto / (FREC[s.frecuencia] || 1); };

  function numero(x) { if (typeof x === "string" && x.trim() !== "") x = Number(x.replace(",", ".")); return typeof x === "number" && isFinite(x) ? x : null; }
  /* Descarta lo que no se puede mostrar y cuenta cuánto se descartó, para avisarlo. */
  M.normalizar = function (data) {
    var malos = 0, o = data && typeof data === "object" ? data : {};
    function lista(x) { return Array.isArray(x) ? x.filter(function (e) { return e && typeof e === "object"; }) : []; }
    var cuentas = lista(o.cuentas).map(function (c) { var n = Object.assign({}, c); n.saldo = numero(c.saldo); ["saldo_inicial", "piso", "objetivo_ganancia", "objetivo_saldo", "retirable"].forEach(function (k) { n[k] = numero(c[k]); }); n.id = String(c.id == null ? "" : c.id); return n; })
      .filter(function (c) { if (c.saldo == null) { malos++; return false; } return true; });
    var movs = lista(o.movimientos).map(function (m) { var n = Object.assign({}, m); n.monto = numero(m.monto); n.tipo = m.tipo === "cobro" ? "cobro" : "gasto"; n.id = String(m.id == null ? m.fecha + "|" + m.descripcion : m.id); n.descripcion = m.descripcion == null ? "Sin descripción" : String(m.descripcion); n.detalle = m.detalle && typeof m.detalle === "object" ? m.detalle : {}; return n; })
      .filter(function (m) { if (!parseISO(m.fecha) || m.monto == null) { malos++; return false; } m.fecha = String(m.fecha).slice(0, 10); return true; });
    var subs = lista(o.suscripciones).map(function (s) { var n = Object.assign({}, s); n.monto = numero(s.monto); n.servicio = s.servicio == null ? "" : String(s.servicio); n.id = String(s.id == null ? s.servicio : s.id); n.pausada = s.pausada === true || s.pausada === "true"; return n; })
      .filter(function (s) { if (!s.servicio) { malos++; return false; } return true; });
    var alertas = lista(o.alertas).filter(function (a) { return typeof a.texto === "string" && a.texto; }).map(function (a) { var o = { nivel: a.nivel === "bad" || a.nivel === "ok" ? a.nivel : "warn", texto: a.texto }; ["id", "codigo", "cuenta_id", "accion"].forEach(function (k) { if (a[k] != null && a[k] !== "") o[k] = String(a[k]); }); return o; });
    return { generado: o.generado, cuentas: cuentas, movimientos: movs, suscripciones: subs, alertas: alertas, malos: malos };
  };

  M.resumen = function (data, hoy, esDemo) {
    data = M.normalizar(data);
    var cuentas = data.cuentas.map(M.cuenta);
    var movs = data.movimientos.slice().sort(function (a, b) { return a.fecha < b.fecha ? 1 : a.fecha > b.fecha ? -1 : 0; });
    var puesto = 0, cobrado = 0, cuotas = 0;
    movs.forEach(function (m) {
      if (m.tipo === "cobro") cobrado += m.monto || 0;
      else { puesto += m.monto || 0; if (m.categoria === CAT_CUENTAS) cuotas += m.monto || 0; }
    });
    var subs = (data.suscripciones || []).map(function (s) {
      var prox = M.proximoPago(s, hoy), pausada = s.pausada === true;
      return { raw: s, id: s.id, servicio: s.servicio, monto: s.monto, frecuencia: s.frecuencia || "mensual", para_que: s.para_que, prox: prox, dias: prox ? M.diasEntre(hoy, prox) : null, mensual: M.mensual(s), pausada: pausada, manual: M.esManual(s) };
    });
    var subsActivas = subs.filter(function (s) { return !s.pausada; });
    var gastoMes = 0, sinMonto = [];
    subsActivas.forEach(function (s) { if (s.mensual == null) sinMonto.push(s); else gastoMes += s.mensual; });
    var proximo = subsActivas.filter(function (s) { return s.prox; }).sort(function (a, b) { return a.prox - b.prox; })[0] || null;
    var vencimientos = subsActivas.filter(function (s) { return s.prox && s.dias >= 0 && s.dias <= 30; }).sort(function (a, b) { return a.prox - b.prox; });
    var retirable = cuentas.reduce(function (a, c) { return a + c.retirable; }, 0);

    var al = M.construirAlertas({ data: data, cuentas: cuentas, subs: subsActivas, hoy: hoy, esDemo: esDemo });
    var orden = { bad: 0, warn: 1, ok: 2 };
    al.sort(function (a, b) { return (orden[a.nivel] - orden[b.nivel]) || (a.prio - b.prio); });
    var peor = "ok";
    al.forEach(function (a) { if (orden[a.nivel] < orden[peor]) peor = a.nivel; });
    var principal = al[0] || null;
    var frase = principal && (principal.nivel !== "ok" || principal.accion) ? principal.texto : "Todo en orden. No hace falta que hagas nada.";
    var activas = cuentas.filter(function (c) { return c.activa && c.margen != null; });
    var tight = activas.slice().sort(function (a, b) { return a.pctMargen - b.pctMargen; })[0] || null;
    var enEval = cuentas.filter(function (c) { return c.estado === "evaluacion" && !c.llegoObjetivo && c.falta != null; }).sort(function (a, b) { return a.falta - b.falta; })[0] || null;
    return {
      cuentas: cuentas, movs: movs, subs: subs, puesto: puesto, cobrado: cobrado, neto: cobrado - puesto, cuotas: cuotas,
      gastoMes: gastoMes, sinMonto: sinMonto, proximo: proximo, vencimientos: vencimientos, pausadas: subs.length - subsActivas.length, retirable: retirable, alertas: al, nivel: peor, frase: frase, masAlertas: Math.max(0, al.filter(function (a) { return a.nivel !== "ok" || a.accion; }).length - 1),
      tight: tight, enEval: enEval
    };
  };

  /* agrupaciones para Plata */
  M.porMes = function (movs) {
    var o = {};
    movs.forEach(function (m) {
      var k = m.fecha.slice(0, 7); o[k] = o[k] || { k: k, cobro: 0, gasto: 0 };
      o[k][m.tipo === "cobro" ? "cobro" : "gasto"] += m.monto || 0;
    });
    return Object.keys(o).sort().reverse().map(function (k) { return o[k]; });
  };
  M.porCategoria = function (movs, tipo) {
    var o = {};
    movs.filter(function (m) { return (m.tipo === "cobro") === (tipo === "cobro"); }).forEach(function (m) {
      var k = m.categoria || "Sin categoría"; o[k] = (o[k] || 0) + (m.monto || 0);
    });
    return Object.keys(o).map(function (k) { return { cat: k, total: o[k] }; }).sort(function (a, b) { return b.total - a.total; });
  };
  M.mesTxt = function (k, corto) { var p = k.split("-"); var n = MESES[+p[1] - 1]; return corto ? n.slice(0, 3) : n.charAt(0).toUpperCase() + n.slice(1) + " " + p[0]; };

  /* CSV simple: separador ; y coma decimal (abre bien en Excel y Sheets en espanol) */
  M.csv = function (movs, cuentas) {
    var nom = {}; (cuentas || []).forEach(function (c) { nom[c.id] = c.nombre; });
    function n(x) { return x == null ? "" : String(x.toFixed ? x.toFixed(2) : x).replace(".", ","); }
    function fx(s) { s = s == null ? "" : String(s); return /^[=+\-@\t\r]/.test(s) ? "'" + s : s; }
    function q(s) { s = s == null ? "" : String(s); return /[;"\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }
    var rows = [["Fecha", "Tipo", "Categoría", "Descripción", "Cuenta", "Monto USD", "Precio de lista USD", "Descuento USD", "Medio de pago", "Nota"]];
    movs.forEach(function (m) {
      var d = m.detalle || {};
      rows.push([M.fecha(m.fecha), m.tipo === "cobro" ? "Cobro" : "Gasto", fx(m.categoria), fx(m.descripcion), fx(nom[m.cuenta_id] || m.cuenta_id),
        n(m.tipo === "cobro" ? m.monto : -m.monto), n(d.precio_lista), n(d.descuento), fx(d.medio_pago), fx(d.nota)]);
    });
    return "﻿" + rows.map(function (r) { return r.map(q).join(";"); }).join("\r\n");
  };
})(window);
