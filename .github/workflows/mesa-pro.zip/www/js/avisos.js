/* Mesa PRO - avisos (notificaciones), recordatorios de pagos, chequeo en segundo plano y respuesta háptica.
   Nunca lanza errores: en el navegador casi nada de esto hace efecto. */
(function (g) {
  var M = g.Mesa = g.Mesa || {};
  var APP_ID = "ar.lucas.mesapro", RUNNER = APP_ID + ".check";
  function plug(n) { try { return (g.Capacitor && g.Capacitor.Plugins && g.Capacitor.Plugins[n]) || null; } catch (e) { return null; } }
  function nativa() { try { return !!(g.Capacitor && g.Capacitor.isNativePlatform && g.Capacitor.isNativePlatform()); } catch (e) { return false; } }
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) {} return null; }
  M.nativa = nativa;

  /* Háptica: l = toque suave, m = medio, s = selección, ok / mal = resultado */
  var reducido = g.matchMedia && g.matchMedia("(prefers-reduced-motion: reduce)").matches;
  M.hap = function (t) {
    try {
      var H = plug("Haptics");
      if (H) {
        if (t === "s") H.selectionChanged(); else if (t === "ok") H.notification({ type: "SUCCESS" });
        else if (t === "mal") H.notification({ type: "ERROR" });
        else H.impact({ style: t === "m" ? "MEDIUM" : "LIGHT" });
      } else if (!nativa() && navigator.vibrate && !reducido && t !== "s") navigator.vibrate(t === "m" ? 14 : 8);
    } catch (e) {}
  };

  /* ---------- permisos ---------- */
  M.avisosEstado = function () {
    var LN = plug("LocalNotifications");
    if (LN) return LN.checkPermissions().then(function (p) { return p.display; }).catch(function () { return "denied"; });
    if ("Notification" in g) return Promise.resolve(Notification.permission === "default" ? "prompt" : Notification.permission);
    return Promise.resolve("unsupported");
  };
  M.avisosPedir = function () {
    var LN = plug("LocalNotifications"), BR = plug("BackgroundRunner");
    if (BR) try { BR.requestPermissions({ apis: ["notifications"] }).catch(function () {}); } catch (e) {}
    if (LN) return LN.requestPermissions().then(function (p) { return p.display; }).catch(function () { return "denied"; });
    if ("Notification" in g) return Notification.requestPermission().catch(function () { return "denied"; });
    return Promise.resolve("unsupported");
  };

  /* ---------- preferencias por categoría ---------- */
  M.prefsAviso = function () { try { var p = JSON.parse(ls("mesa.notif") || "{}"); return p && typeof p === "object" ? p : {}; } catch (e) { return {}; } };
  M.prefAvisoSet = function (cat, on) { var p = M.prefsAviso(); if (on) delete p[cat]; else p[cat] = false; ls("mesa.notif", JSON.stringify(p)); };

  /* ---------- chequeo en segundo plano (runners/check.js) ---------- */
  M.runner = function (evento, detalles) {
    var BR = plug("BackgroundRunner");
    if (!BR) return Promise.resolve(null);
    return new Promise(function (ok) {
      var t = setTimeout(function () { ok(null); }, 4000);
      try { BR.dispatchEvent({ label: RUNNER, event: evento, details: detalles || {} }).then(function (r) { clearTimeout(t); ok(r || null); }, function () { clearTimeout(t); ok(null); }); }
      catch (e) { clearTimeout(t); ok(null); }
    });
  };
  /* Le pasa al chequeo la URL, la clave y qué categorías están prendidas. Se llama al abrir, al guardar y al cambiar un interruptor. */
  M.runnerConfig = function () {
    var url = (ls("mesa.url") || "").trim(), k = ls("mesa.clave") || "";
    if (!BRok()) return Promise.resolve(null);
    return M.runner("config", { url: url, clave: k, prefs: M.prefsAviso(), recordatorios: ls("mesa.recordatorios") === "1" });
  };
  function BRok() { return !!plug("BackgroundRunner"); }
  M.runnerEstado = function () { return M.runner("estado"); };

  /* ---------- enviar ---------- */
  function enviar(n) {
    var LN = plug("LocalNotifications");
    try {
      if (LN) return LN.schedule({ notifications: [{ id: n.id, title: n.titulo, body: n.texto, extra: { mesa: "aviso" } }] }).catch(function () {});
      if ("Notification" in g && Notification.permission === "granted") new Notification(n.titulo, { body: n.texto });
    } catch (e) {}
    return Promise.resolve();
  }
  function leerMapa() { try { var m = JSON.parse(ls("mesa.avisos2") || "{}"); return m && typeof m === "object" ? m : {}; } catch (e) { return {}; } }

  /* Se llama con el resumen después de cada actualización: avisa lo nuevo, una sola vez. */
  M.avisar = function (r, esDemo) {
    if (esDemo) return Promise.resolve();
    return M.avisosEstado().then(function (perm) {
      if (perm !== "granted") return;
      return M.runner("estado").then(function (est) {
        var prev = leerMapa(), rm = (est && est.notificadas) || {};
        Object.keys(rm).forEach(function (k) { if (!prev[k]) prev[k] = rm[k]; });
        var out = M.alertasNuevas(r.alertas, prev, M.iso(M.hoy()), M.prefsAviso(), { sinPagos: ls("mesa.recordatorios") === "1" });
        ls("mesa.avisos2", JSON.stringify(out.mapa));
        out.nuevas.forEach(enviar);
        if (BRok()) M.runner("marcar", { mapa: out.mapa });
      });
    });
  };

  /* ---------- recordatorios de pagos: 3 días antes, 1 día antes y el mismo día, a las 10:00 ---------- */
  M.recordatoriosPlan = function (subs, ahora) {
    var plan = [];
    subs.forEach(function (s) {
      if (s.pausada || !s.prox) return;
      var vistos = {}, base = s;
      [s.prox, null].forEach(function (f, i) {
        var prox = f;
        if (i === 1) { var sig = new Date(s.prox.getFullYear(), s.prox.getMonth(), s.prox.getDate() + 1); prox = M.proximoPago(s.raw, sig); }
        if (!prox || vistos[M.iso(prox)]) return; vistos[M.iso(prox)] = 1;
        [3, 1, 0].forEach(function (d) {
          var cuando = new Date(prox.getFullYear(), prox.getMonth(), prox.getDate() - d, 10, 0, 0);
          if (cuando.getTime() < ahora + 30000) return;
          var pa = M.pagoAviso({ servicio: base.servicio, monto: base.monto, prox: prox }, d);
          plan.push({ id: -M.hash("rem|" + base.id + "|" + M.iso(prox) + "|" + d), title: pa.titulo, body: pa.texto, schedule: { at: cuando, allowWhileIdle: true }, extra: { mesa: "rem" } });
        });
      });
    });
    plan.sort(function (a, b) { return a.schedule.at - b.schedule.at; });
    return plan.slice(0, 60);
  };
  /* Cancela los recordatorios anteriores (ids negativos) y programa los nuevos. Se llama cada vez que cambian los datos. */
  M.recordatorios = function (r, esDemo) {
    var LN = plug("LocalNotifications");
    if (!LN || esDemo || !r) return Promise.resolve(null);
    var activo = M.prefsAviso().pagos !== false;
    return M.avisosEstado().then(function (perm) {
      if (perm !== "granted") return null;
      return LN.getPending().then(function (p) {
        var ids = (p.notifications || []).filter(function (n) { return n.id < 0; }).map(function (n) { return { id: n.id }; });
        return ids.length ? LN.cancel({ notifications: ids }) : null;
      }).then(function () {
        var plan = activo ? M.recordatoriosPlan(r.subs, Date.now()) : [];
        ls("mesa.recordatorios", activo ? "1" : "0");
        return plan.length ? LN.schedule({ notifications: plan }).then(function () { return plan.length; }) : 0;
      }).catch(function () { ls("mesa.recordatorios", "0"); return null; });
    });
  };

  /* Botón "Probar notificación": manda una de prueba y le pregunta al chequeo en segundo plano cuándo corrió por última vez. */
  M.probar = function () {
    return M.avisosEstado().then(function (perm) {
      if (perm !== "granted") return { permiso: perm };
      return enviar({ id: 1, titulo: "Prueba de Mesa PRO", texto: "Si ves esto, los avisos funcionan." }).then(function () { return M.runner("estado"); }).then(function (est) { return { permiso: perm, runner: est }; });
    });
  };
})(window);
