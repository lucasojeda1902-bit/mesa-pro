/* Mesa PRO - avisos locales y respuesta háptica. Nunca lanza errores: en el navegador no hace nada. */
(function (g) {
  var M = g.Mesa = g.Mesa || {};
  function plug(n) { try { return (g.Capacitor && g.Capacitor.Plugins && g.Capacitor.Plugins[n]) || null; } catch (e) { return null; } }
  function nativa() { try { return !!(g.Capacitor && g.Capacitor.isNativePlatform && g.Capacitor.isNativePlatform()); } catch (e) { return false; } }
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) {} return null; }

  /* Háptica: l = toque suave, m = medio, s = selección, ok / mal = resultado */
  var reducido = g.matchMedia && g.matchMedia("(prefers-reduced-motion: reduce)").matches;
  M.hap = function (t) {
    try {
      var H = plug("Haptics");
      if (H) {
        if (t === "s") H.selectionChanged(); else if (t === "ok") H.notification({ type: "SUCCESS" });
        else if (t === "mal") H.notification({ type: "ERROR" });
        else H.impact({ style: t === "m" ? "MEDIUM" : "LIGHT" });
      } else if (!nativa() && navigator.vibrate && !reducido && t !== "s") navigator.vibrate(t === "m" ? 14 : 8);
    } catch (e) {}
  };

  M.avisosEstado = function () {
    var LN = plug("LocalNotifications");
    if (LN) return LN.checkPermissions().then(function (p) { return p.display; }).catch(function () { return "denied"; });
    if ("Notification" in g) return Promise.resolve(Notification.permission === "default" ? "prompt" : Notification.permission);
    return Promise.resolve("unsupported");
  };
  M.avisosPedir = function () {
    var LN = plug("LocalNotifications");
    if (LN) return LN.requestPermissions().then(function (p) { return p.display; }).catch(function () { return "denied"; });
    if ("Notification" in g) return Notification.requestPermission().catch(function () { return "denied"; });
    return Promise.resolve("unsupported");
  };

  function enviar(id, titulo, cuerpo) {
    var LN = plug("LocalNotifications");
    try {
      if (LN) return LN.schedule({ notifications: [{ id: id, title: titulo, body: cuerpo }] }).catch(function () {});
      if ("Notification" in g && Notification.permission === "granted") new Notification(titulo, { body: cuerpo });
    } catch (e) {}
    return Promise.resolve();
  }
  function hash(s) { var h = 7; for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 2000000000; return h + 1; }

  /* Se llama con el resumen después de cada actualización. */
  M.avisar = function (r, esDemo) {
    if (esDemo) return;
    M.avisosEstado().then(function (perm) {
      if (perm !== "granted") return;
      var prev = {}; try { prev = JSON.parse(ls("mesa.avisos") || "{}"); } catch (e) {}
      var ya = prev.pagos || {};
      if (r.nivel === "bad" && prev.nivel !== "bad") enviar(hash("rojo" + Date.now()), "Mesa PRO: hacé esto ahora", r.frase);
      if (r.retirable > 0 && !(prev.retirable > 0)) enviar(hash("retiro" + Date.now()), "Tenés un retiro disponible", "Podés retirar " + M.usd(r.retirable) + ". Pedilo en FundedNext.");
      var hoy = M.hoy(), futuros = [];
      r.subs.forEach(function (s) {
        if (!s.prox) return;
        var key = s.id + "|" + M.iso(s.prox);
        if (s.dias >= 0 && s.dias <= 3 && !ya[key]) {
          ya[key] = 1;
          enviar(hash(key), "Se viene un pago", s.servicio + (s.monto != null ? " (" + M.usd(s.monto) + ")" : "") + " vence " + M.enDias(s.dias) + ", el " + M.fecha(s.prox) + ".");
        } else if (s.dias > 3) {
          var cuando = new Date(s.prox.getFullYear(), s.prox.getMonth(), s.prox.getDate() - 3, 10, 0, 0);
          futuros.push({ id: hash("prog" + key), title: "Se viene un pago", body: s.servicio + (s.monto != null ? " (" + M.usd(s.monto) + ")" : "") + " vence en 3 días, el " + M.fecha(s.prox) + ".", schedule: { at: cuando } });
        }
      });
      var LN = plug("LocalNotifications");
      if (LN) {
        LN.getPending().then(function (p) {
          var ids = (p.notifications || []).filter(function (n) { return (n.title || "") === "Se viene un pago"; }).map(function (n) { return { id: n.id }; });
          return ids.length ? LN.cancel({ notifications: ids }) : null;
        }).then(function () { return futuros.length ? LN.schedule({ notifications: futuros }) : null; }).catch(function () {});
      }
      ls("mesa.avisos", JSON.stringify({ nivel: r.nivel, retirable: r.retirable, pagos: ya }));
    });
  };
})(window);
