# Formato de `mesa-datos.json`

Es el archivo que lee la app (por el endpoint de Apps Script) y el mismo formato de `demo.json` (datos inventados, sin nada real).
Todos los montos son números en dólares (USD), con punto decimal y sin símbolos. Las fechas van como `AAAA-MM-DD`.
Un campo que no se conoce va en `null` (la app muestra "Sin dato" o "A confirmar"; nunca inventa un valor).

## Raíz

| Campo | Tipo | Para qué |
|---|---|---|
| `generado` | texto ISO 8601, ej. `2026-10-28T12:00:00-03:00` | Cuándo se armó el archivo. Si pasan más de 48 h, la app avisa. |
| `moneda` | texto | Informativo. Hoy `USD`. |
| `cuentas` | lista | Una por cuenta de fondeo. |
| `movimientos` | lista | Libro de plata: gastos y cobros. |
| `suscripciones` | lista | Pagos fijos recurrentes. |
| `alertas` | lista | Avisos extra para el semáforo y las notificaciones (opcional, puede ir vacía). |
| `ediciones_version` | número | **Lo agrega el servidor (Apps Script), no lo escribe el contador.** Versión del archivo `mesa-ediciones.json` que ya está aplicada en estos datos. |

Todos los campos nuevos de la versión 2 son **opcionales**: un archivo viejo sigue funcionando igual.

## `cuentas[]`

| Campo | Tipo | Notas |
|---|---|---|
| `id` | texto | Número/código de la cuenta (ej. `DEMO-0001`). |
| `nombre`, `firma`, `tipo` | texto | Ej. `Cuenta 50K`, `Firma`, `Flex 50K`. |
| `estado` | `evaluacion`, `fondeada`, `aprobada`, `pausada`, `perdida` | |
| `inicio` | fecha | Día que empezó. |
| `saldo_inicial` | número | Saldo con el que arrancó (ej. 50000). |
| `saldo` | número | Saldo actual. |
| `piso` | número | Saldo mínimo (pérdida máxima). Si el saldo baja de acá, se pierde la cuenta. |
| `margen` | número | Informativo. La app lo recalcula como `saldo - piso`. |
| `objetivo_ganancia` | número | Ganancia necesaria para aprobar (ej. 2500). |
| `objetivo_saldo` | número | Saldo que hay que alcanzar (ej. 52500). Si falta, se calcula. |
| `consistencia_max_pct` | número | Límite de la regla de consistencia (ej. 40). |
| `mejor_dia_pct` | número o `null` | Cuánto pesa el mejor día sobre la ganancia total, en %. |
| `dias_operados` | número o `null` | |
| `dias_minimos` | número o `null` | Días mínimos exigidos, si los hay. |
| `retirable` | número | Monto disponible para retirar ahora (0 si nada). |
| `historial_saldo` | lista opcional de `{ "fecha", "saldo" }` | Si tiene 2 o más puntos, se dibuja la curva en el detalle de la cuenta. |
| `origen` | `auto` o `manual` | `auto`: la escribe el contador (FundedNext). `manual`: la cargó Lucas a mano en la app (el servidor la agrega solo, con id `man-…`). Si falta, se toma como automática. El contador **no** debe escribir cuentas `manual` ni tocarlas. |
| `nota` | texto | Nota libre de Lucas (lo único que se puede editar de una cuenta automática). El contador la conserva si la lee, pero no la necesita escribir. |
| `payout` | objeto opcional | Avance del retiro, ver abajo. |

### `cuentas[].payout` (todo opcional; lo que no se sabe va en `null`)

| Campo | Tipo | Significado exacto |
|---|---|---|
| `dias_ok` | número | Días ya cumplidos para poder retirar (días con ganancia mínima, "días de payout"). |
| `dias_req` | número | Días que exige la regla para habilitar el retiro. |
| `minimo_dia` | número (US$) | Ganancia mínima de un día para que cuente como día de payout. |
| `pct_retiro` | número (0 a 100) | Porcentaje de la ganancia que se retira (reparto). |
| `max_retiro` | número (US$) | Lo máximo que se puede retirar hoy según las reglas. |
| `elegible` | `true` / `false` | `true` = cumple TODAS las condiciones y puede pedir el retiro ya. Dispara "Listo para retirar". |
| `bloqueo` | texto o `null` | Motivo por el que NO puede retirar y tiene arreglo, en una frase (ej. `tu mejor día pesa el 52% de la ganancia y el límite es 40%`, `falta aprobar el KYC (verificación de identidad)`, `faltan 2 días mínimos de operación`). Con `elegible: false` y este campo, la app avisa "Retiro frenado, tiene arreglo". |
| `solucion` | texto o `null` | Qué hacer para arreglarlo, en una frase corta con verbo (ej. `operá varios días chicos hasta que el mejor día baje del 40%`). |
| `proximo_ciclo` | fecha o `null` | Cuándo empieza el próximo ciclo de retiro. |

Reglas que usa la app con esto (iguales en la pantalla y en el chequeo en segundo plano):
- **Listo para retirar**: `retirable > 0` o `payout.elegible == true`.
- **Muy cerca de retirar**: `dias_req >= 2` y `dias_ok == dias_req - 1`, o ganancia (saldo − saldo inicial) ≥ 85 % de `objetivo_ganancia` (cuenta no en evaluación). En evaluación dice "muy cerca de aprobar".
- **Retiro frenado, tiene arreglo**: `payout.bloqueo` con texto (y no hay retiro disponible).

## `movimientos[]`

| Campo | Tipo | Notas |
|---|---|---|
| `id` | texto único | |
| `fecha` | fecha | |
| `tipo` | `gasto` o `cobro` | El `monto` va siempre positivo; el tipo define el signo. |
| `categoria` | texto libre | Para el retorno sobre lo pagado, las cuotas de cuentas deben usar exactamente `Cuentas de fondeo`. |
| `descripcion` | texto | |
| `monto` | número | |
| `moneda` | texto | `USD`. |
| `cuenta_id` | texto opcional | Enlaza con `cuentas[].id`. |
| `detalle` | objeto opcional | `precio_lista`, `descuento` (en US$), `medio_pago`, `nota`. |
| `origen` | `manual` / `editado` | **Lo pone el servidor**, no el contador: `manual` = lo cargó Lucas; `editado` = Lucas cambió algo de lo que escribió el contador. |

## `suscripciones[]`

| Campo | Tipo | Notas |
|---|---|---|
| `id`, `servicio` | texto | |
| `monto` | número o `null` | `null` = monto a confirmar (no se suma a los totales y se avisa). |
| `moneda` | texto | |
| `frecuencia` | `semanal`, `mensual`, `bimestral`, `trimestral`, `semestral`, `anual` | |
| `proximo_pago` | fecha o `null` | Si la fecha ya pasó, la app la corre sola según la frecuencia. |
| `para_que` | texto | Una frase simple. |
| `pausada` | `true` / `false` | `true` = pausada: no suma a los totales, no sale en vencimientos y no avisa. Normalmente la cambia Lucas desde la app; el contador no tiene que escribirla. |
| `origen` | `manual` / `editado` | Igual que en `movimientos[]`: lo pone el servidor. |

## `alertas[]`

`{ "nivel": "ok" | "warn" | "bad", "texto": "Frase corta que diga qué hacer", "id": "…", "codigo": "…", "cuenta_id": "…", "accion": "…" }`

Los 4 campos nuevos son opcionales:

| Campo | Para qué |
|---|---|
| `id` | Identificador estable de la alerta (ej. `ret-bloq-1234-2026-10`). Sirve para avisar **una sola vez**: si el `id` no cambia, no se vuelve a notificar. Si falta, la app usa un hash del texto. |
| `codigo` | Tipo de alerta. Los que la app entiende: `listo_retiro` (cuenta lista para retirar; categoría Retiros), `retiro_bloqueado` (retiro frenado por algo que tiene arreglo; `texto` = motivo, `accion` = solución), `retiro_cerca`, `margen_bajo`, `cuenta_perdida`, `datos_viejos`. Cualquier otro valor (o ninguno) cae en "Avisos del contador". |
| `cuenta_id` | `cuentas[].id` a la que se refiere. Si la cuenta ya genera la misma alerta por sus propios números, no se duplica. |
| `accion` | Qué hacer, en una frase. Se agrega al final del texto de la notificación. |

**Cuáles llegan como notificación (también con la app cerrada):** toda alerta `bad` o `warn`, y las `ok` con `codigo: "listo_retiro"`. Las `ok` comunes solo se ven en la pantalla.

La app suma sus propias alertas (margen bajo, retiro disponible, muy cerca de retirar, retiro frenado, objetivo alcanzado, pago en 3 días / mañana / hoy, datos viejos). El semáforo toma el peor nivel y muestra la frase más urgente. Las suscripciones pausadas no generan avisos de pago.

## Regla del semáforo (sobre el colchón = saldo inicial menos piso)

- Rojo: queda menos del 25 % del colchón, o la cuenta está perdida.
- Amarillo: queda menos del 50 %, o hay un pago en 3 días, o una alerta `warn`.
- Verde: todo lo demás.

## Ediciones de Lucas (`mesa-ediciones.json`) y campos `origen`

Lucas puede agregar, editar, borrar y pausar movimientos, suscripciones y cuentas manuales desde la app. Esos cambios se guardan en **otro archivo** de Drive, `mesa-ediciones.json`, que el Apps Script mezcla con `mesa-datos.json` al responder. **El contador sigue escribiendo solo `mesa-datos.json`** (no hace falta que lo mezcle) y puede leer `mesa-ediciones.json` si quiere saber qué cambió Lucas:

```json
{ "version": 7, "items": [ { "col": "movimientos", "op": "upsert", "id": "man-lq3x9a1b2", "data": { "fecha": "2026-10-27", "tipo": "gasto", "monto": 12, "categoria": "Comisiones", "descripcion": "…" }, "ts": "2026-10-28T15:04:05.000Z" } ] }
```

- `col`: `movimientos`, `suscripciones` o `cuentas`. `op`: `upsert` (crear o cambiar) o `delete` (borrar). `id`: el del elemento (los creados a mano empiezan con `man-`). `ts`: fecha ISO UTC.
- Hay **un solo item por (col, id)**: el más nuevo. Dos `upsert` seguidos se suman campo a campo.
- Sobre un elemento del servidor, el `upsert` **mezcla campos** sobre el original (la app manda solo lo que cambió) y el elemento queda con `"origen": "editado"`. Un `upsert` con id nuevo crea el elemento con `"origen": "manual"`. `delete` lo saca de lo que ve la app (si el contador lo vuelve a escribir en `mesa-datos.json`, sigue oculto).
- Las **cuentas automáticas** solo aceptan el campo `nota` (lo demás se ignora). Las manuales aceptan todos los campos de `cuentas[]`.
- Suscripciones: `"pausada": true` = pausada (no suma a los totales y no avisa).
- Si el contador necesita saber en qué estado quedó todo, lo más simple es pedir `GET ?k=CLAVE` al Apps Script (ya viene mezclado) o leer `mesa-ediciones.json` y aplicar la misma regla.

## Exportar CSV

Separador `;`, coma decimal y codificación UTF-8 con BOM (abre bien en Excel y Google Sheets en español). Gastos con signo negativo.

## Novedades de la versión 3 (todo opcional)

### `cuentas[].curva` (recomendado) o `cuentas[].historial_saldo`
La app acepta los dos. **Un cierre por día** (si hay dos el mismo día, queda el último). Con 2 o más días dibuja la curva, el drawdown y el calendario; con menos, muestra un aviso y no inventa puntos.

- `curva`: lista de filas `[fecha, saldo, piso, resultado_dia, ops_dia]`, por ejemplo `["2026-10-27", 50340, 48840, 340, 3]`.
  `piso` = piso vigente al cierre (con arrastre), `resultado_dia` = neto del día en US$, `ops_dia` = cantidad de operaciones. Lo que no se sepa va en `null`.
- `historial_saldo`: lista de `{ "fecha", "saldo" }` (formato v2). El resultado de cada día se **estima** con la diferencia entre cierres y la app lo rotula "estimado".

Con esto la app calcula sola el mejor día, la consistencia, el drawdown y "cuánto podés ganar hoy". `mejor_dia_pct` y `dias_operados` pasan a ser opcionales.

### `cuentas[].reglas` (opcional)
`{ "perdida_max": 1500 }`: pérdida máxima de la cuenta. Si no viene, se usa `saldo_inicial − piso`.

### `diario[]` (lo escribe la app, no el contador)
`{ "id", "fecha": "AAAA-MM-DD", "texto", "etiquetas": ["Con plan", …], "cuenta_id" }`. Viaja con las ediciones (colección `diario` de `mesa-ediciones.json`), igual que movimientos y suscripciones.

### `infra.alertas_tv` (opcional)
`[{ "id", "nombre", "vence": "2026-12-08T22:44" }]` (hora de Argentina). Si no viene, la app usa los vencimientos conocidos (08/12 22:44 y 09/12). El contrato vigente y el cambio de contrato (roll) se calculan en el celular.

### Lo que la app calcula sola (no hace falta escribirlo)
Hora de apertura de Nueva York (09:30 NY, con la zona horaria de Nueva York, así el cambio de horario no la desfasa), cuánto podés perder hoy (el menor entre el margen hasta el piso y el tope diario de 1.000 de los scripts), cuánto podés ganar sin romper la consistencia del 40 %, contrato vigente y roll, y estado de infraestructura.
