# Formato de `mesa-datos.json`

Es el archivo que lee la app (por el endpoint de Apps Script) y el mismo formato de `demo.json` (datos inventados, sin nada real).
Todos los montos son números en dólares (USD), con punto decimal y sin símbolos. Las fechas van como `AAAA-MM-DD`.
Un campo que no se conoce va en `null` (la app muestra "Sin dato" o "A confirmar"; nunca inventa un valor).

## Raíz

| Campo | Tipo | Para qué |
|---|---|---|
| `generado` | texto ISO 8601, ej. `2026-10-28T12:00:00-03:00` | Cuándo se armó el archivo. Si pasan más de 48 h, la app avisa. |
| `moneda` | texto | Informativo. Hoy `USD`. |
| `cuentas` | lista | Una por cuenta de fondeo. |
| `movimientos` | lista | Libro de plata: gastos y cobros. |
| `suscripciones` | lista | Pagos fijos recurrentes. |
| `alertas` | lista | Avisos extra para el semáforo (opcional, puede ir vacía). |

## `cuentas[]`

| Campo | Tipo | Notas |
|---|---|---|
| `id` | texto | Número/código de la cuenta (ej. `DEMO-0001`). |
| `nombre`, `firma`, `tipo` | texto | Ej. `Cuenta 50K`, `Firma`, `Flex 50K`. |
| `estado` | `evaluacion`, `fondeada`, `aprobada`, `pausada`, `perdida` | |
| `inicio` | fecha | Día que empezó. |
| `saldo_inicial` | número | Saldo con el que arrancó (ej. 50000). |
| `saldo` | número | Saldo actual. |
| `piso` | número | Saldo mínimo (pérdida máxima). Si el saldo baja de acá, se pierde la cuenta. |
| `margen` | número | Informativo. La app lo recalcula como `saldo - piso`. |
| `objetivo_ganancia` | número | Ganancia necesaria para aprobar (ej. 2500). |
| `objetivo_saldo` | número | Saldo que hay que alcanzar (ej. 52500). Si falta, se calcula. |
| `consistencia_max_pct` | número | Límite de la regla de consistencia (ej. 40). |
| `mejor_dia_pct` | número o `null` | Cuánto pesa el mejor día sobre la ganancia total, en %. |
| `dias_operados` | número o `null` | |
| `dias_minimos` | número o `null` | Días mínimos exigidos, si los hay. |
| `retirable` | número | Monto disponible para retirar ahora (0 si nada). |
| `historial_saldo` | lista opcional de `{ "fecha", "saldo" }` | Si tiene 2 o más puntos, se dibuja la curva en el detalle de la cuenta. |

## `movimientos[]`

| Campo | Tipo | Notas |
|---|---|---|
| `id` | texto único | |
| `fecha` | fecha | |
| `tipo` | `gasto` o `cobro` | El `monto` va siempre positivo; el tipo define el signo. |
| `categoria` | texto libre | Para el retorno sobre lo pagado, las cuotas de cuentas deben usar exactamente `Cuentas de fondeo`. |
| `descripcion` | texto | |
| `monto` | número | |
| `moneda` | texto | `USD`. |
| `cuenta_id` | texto opcional | Enlaza con `cuentas[].id`. |
| `detalle` | objeto opcional | `precio_lista`, `descuento` (en US$), `medio_pago`, `nota`. |

## `suscripciones[]`

| Campo | Tipo | Notas |
|---|---|---|
| `id`, `servicio` | texto | |
| `monto` | número o `null` | `null` = monto a confirmar (no se suma a los totales y se avisa). |
| `moneda` | texto | |
| `frecuencia` | `semanal`, `mensual`, `bimestral`, `trimestral`, `semestral`, `anual` | |
| `proximo_pago` | fecha o `null` | Si la fecha ya pasó, la app la corre sola según la frecuencia. |
| `para_que` | texto | Una frase simple. |

## `alertas[]`

`{ "nivel": "ok" | "warn" | "bad", "texto": "Frase corta que diga qué hacer" }`

La app suma sus propias alertas (margen bajo, retiro disponible, objetivo alcanzado, pago en 3 días, datos viejos). El semáforo toma el peor nivel y muestra la frase más urgente.

## Regla del semáforo (sobre el colchón = saldo inicial menos piso)

- Rojo: queda menos del 25 % del colchón, o la cuenta está perdida.
- Amarillo: queda menos del 50 %, o hay un pago en 3 días, o una alerta `warn`.
- Verde: todo lo demás.

## Exportar CSV

Separador `;`, coma decimal y codificación UTF-8 con BOM (abre bien en Excel y Google Sheets en español). Gastos con signo negativo.
