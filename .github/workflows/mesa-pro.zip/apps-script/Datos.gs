/**
 * Mesa PRO - endpoint de datos.
 * Devuelve el archivo "mesa-datos.json" de tu Drive, solo si la clave coincide.
 * La clave se guarda en Propiedades del script con el nombre CLAVE (no va escrita en el código).
 */
function doGet(e) {
  var clave = PropertiesService.getScriptProperties().getProperty('CLAVE');
  var k = e && e.parameter ? e.parameter.k : '';
  if (!clave || k !== clave) return salida_({ ok: false, error: 'clave' });

  var archivos = DriveApp.getFilesByName('mesa-datos.json');
  var elegido = null;
  while (archivos.hasNext()) {            // si hay varios con el mismo nombre, usa el más nuevo
    var f = archivos.next();
    if (!elegido || f.getLastUpdated() > elegido.getLastUpdated()) elegido = f;
  }
  if (!elegido) return salida_({ ok: false, error: 'no_archivo' });

  return ContentService
    .createTextOutput(elegido.getBlob().getDataAsString('UTF-8'))
    .setMimeType(ContentService.MimeType.JSON);
}

function salida_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
