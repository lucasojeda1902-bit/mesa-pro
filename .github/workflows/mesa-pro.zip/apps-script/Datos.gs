/**
 * Mesa PRO - endpoint de datos y ediciones (v2).
 *
 *  GET  ?k=CLAVE              -> mesa-datos.json (el más nuevo) con las ediciones de mesa-ediciones.json ya aplicadas,
 *                                más el campo "ediciones_version".
 *  GET  ?k=CLAVE&solo=ediciones -> el archivo mesa-ediciones.json tal cual (lo lee también el contador automático).
 *  POST (texto) {"k":"CLAVE","items":[{col,op,id,data,ts}]} -> guarda las ediciones. Responde {ok:true,version}.
 *
 * La clave se guarda en Propiedades del script con el nombre CLAVE (no va escrita en el código).
 * Las funciones que terminan en "_" son puras y las prueba test/merge.test.js (comparadas con www/js/ediciones.js).
 */
var ARCHIVO_DATOS = 'mesa-datos.json';
var ARCHIVO_EDICIONES = 'mesa-ediciones.json';
var COLS_ = ['movimientos', 'suscripciones', 'cuentas'];
var OPS_ = ['upsert', 'delete'];
var MAX_CUERPO_ = 200 * 1024;
var MAX_ITEMS_POST_ = 200;
var MAX_ITEMS_ARCHIVO_ = 5000;

function doGet(e) {
  var p = (e && e.parameter) || {};
  if (!claveOk_(p.k)) return salida_({ ok: false, error: 'clave' });

  if (p.solo === 'ediciones') return salida_(leerEdiciones_());

  var elegido = archivoMasNuevo_(ARCHIVO_DATOS);
  if (!elegido) return salida_({ ok: false, error: 'no_archivo' });
  var datos;
  try { datos = JSON.parse(elegido.getBlob().getDataAsString('UTF-8')); }
  catch (err) { return salida_({ ok: false, error: 'datos_invalidos' }); }
  var ed = leerEdiciones_();
  var res = aplicarEdiciones_(datos, ed.items);
  res.ediciones_version = ed.version;
  return salida_(res);
}

function doPost(e) {
  var texto = e && e.postData ? e.postData.contents : '';
  if (!texto || texto.length > MAX_CUERPO_) return salida_({ ok: false, error: 'cuerpo' });
  var cuerpo;
  try { cuerpo = JSON.parse(texto); } catch (err) { return salida_({ ok: false, error: 'json' }); }
  if (!cuerpo || !claveOk_(cuerpo.k)) return salida_({ ok: false, error: 'clave' });
  var v = validarItems_(cuerpo.items);
  if (!v.ok) return salida_(v);

  var lock = LockService.getScriptLock();
  try { lock.waitLock(20000); } catch (err) { return salida_({ ok: false, error: 'ocupado' }); }
  try {
    var ed;
    try { ed = leerEdiciones_(true); } catch (err) { return salida_({ ok: false, error: 'ediciones_corruptas' }); }   // no pisa un archivo que no se pudo leer
    var nuevo = unirEdiciones_(ed, v.items, new Date().toISOString());
    guardarEdiciones_(nuevo);
    return salida_({ ok: true, version: nuevo.version });
  } finally { lock.releaseLock(); }
}

/* ---------- Drive ---------- */
function claveOk_(k) {
  var clave = PropertiesService.getScriptProperties().getProperty('CLAVE');
  return !!clave && typeof k === 'string' && k === clave;
}
function archivoMasNuevo_(nombre) {
  var archivos = DriveApp.getFilesByName(nombre), elegido = null;
  while (archivos.hasNext()) {            // si hay varios con el mismo nombre, usa el más nuevo
    var f = archivos.next();
    if (!elegido || f.getLastUpdated() > elegido.getLastUpdated()) elegido = f;
  }
  return elegido;
}
function leerEdiciones_(estricto) {
  var f = archivoMasNuevo_(ARCHIVO_EDICIONES), o = null;
  if (f) { try { o = JSON.parse(f.getBlob().getDataAsString('UTF-8')); } catch (err) { o = null; if (estricto) throw new Error('ediciones_corruptas'); } }
  if (!o || !Array.isArray(o.items)) o = { version: (o && o.version) || 0, items: [] };
  if (typeof o.version !== 'number') o.version = 0;
  return o;
}
function guardarEdiciones_(o) {
  var f = archivoMasNuevo_(ARCHIVO_EDICIONES), txt = JSON.stringify(o);
  if (f) f.setContent(txt); else DriveApp.createFile(ARCHIVO_EDICIONES, txt, 'application/json');
}
function salida_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/* ---------- lógica pura (se prueba en node) ---------- */
function asig_(o) {
  for (var i = 1; i < arguments.length; i++) { var s = arguments[i]; if (s) for (var k in s) if (Object.prototype.hasOwnProperty.call(s, k)) o[k] = s[k]; }
  return o;
}
function esManual_(e) { return !!e && (e.origen === 'manual' || /^man-/.test(String(e.id || ''))); }
function esNum_(x) {
  if (typeof x === 'string' && x.trim() !== '') x = Number(x.replace(',', '.'));
  return typeof x === 'number' && isFinite(x);
}

/* Valida los items de un POST. Devuelve {ok:true, items:[...limpios]} o {ok:false, error, indice}. */
function validarItems_(items) {
  if (!Array.isArray(items) || !items.length) return { ok: false, error: 'sin_items' };
  if (items.length > MAX_ITEMS_POST_) return { ok: false, error: 'demasiados_items' };
  var limpios = [];
  for (var i = 0; i < items.length; i++) {
    var it = items[i];
    if (!it || typeof it !== 'object') return { ok: false, error: 'item_invalido', indice: i };
    if (COLS_.indexOf(it.col) < 0) return { ok: false, error: 'col_invalida', indice: i };
    if (OPS_.indexOf(it.op) < 0) return { ok: false, error: 'op_invalida', indice: i };
    if (typeof it.id !== 'string' || !it.id || it.id.length > 80) return { ok: false, error: 'id_invalido', indice: i };
    if (it.op === 'upsert' && (!it.data || typeof it.data !== 'object' || Array.isArray(it.data))) return { ok: false, error: 'data_invalida', indice: i };
    var limpio = { col: it.col, op: it.op, id: it.id, ts: it.ts };
    if (it.op === 'upsert') limpio.data = it.data;
    limpios.push(limpio);
  }
  return { ok: true, items: limpios };
}

/* ts siempre en ISO UTC; si falta, está mal o está en el futuro, usa la hora del servidor. */
function tsOk_(ts, ahora) {
  var t = ts ? new Date(ts) : null;
  if (!t || isNaN(t.getTime())) return ahora;
  var tope = new Date(ahora).getTime() + 5 * 60 * 1000;   // un reloj adelantado no puede ganarle a todo lo demás
  return t.getTime() > tope ? ahora : t.toISOString();
}

/* Deja un solo item por (col,id): el de ts más nuevo. Dos upsert seguidos se suman campo a campo. */
function reducir_(items) {
  var ord = items.map(function (it, i) { return { it: it, i: i }; }).sort(function (a, b) {
    var x = String(a.it.ts || ''), y = String(b.it.ts || '');
    return x < y ? -1 : x > y ? 1 : a.i - b.i;
  });
  var mapa = {}, orden = [];
  ord.forEach(function (o) {
    var it = o.it, k = it.col + '|' + it.id, prev = mapa[k];
    if (it.op === 'upsert' && prev && prev.op === 'upsert') it = { col: it.col, op: 'upsert', id: it.id, ts: it.ts, data: asig_({}, prev.data, it.data) };
    if (!prev) orden.push(k);
    mapa[k] = it;
  });
  return orden.map(function (k) { return mapa[k]; });
}

/* Suma items nuevos al archivo de ediciones: {version, items}. Sube la versión en 1. */
function unirEdiciones_(actual, nuevos, ahoraISO) {
  var lista = (actual.items || []).concat(nuevos.map(function (it) {
    var o = { col: it.col, op: it.op, id: it.id, ts: tsOk_(it.ts, ahoraISO) };
    if (it.op === 'upsert') o.data = it.data;
    return o;
  }));
  var items = reducir_(lista);
  if (items.length > MAX_ITEMS_ARCHIVO_) items = items.slice(items.length - MAX_ITEMS_ARCHIVO_);
  return { version: (actual.version || 0) + 1, items: items };
}

function minimo_(col, d) {
  if (col === 'movimientos') return !!d.fecha && esNum_(d.monto);
  if (col === 'suscripciones') return typeof d.servicio === 'string' && d.servicio !== '';
  if (col === 'cuentas') return esNum_(d.saldo);
  return false;
}

/* Aplica las ediciones a los datos. Devuelve datos nuevos. upsert: crea o mezcla; delete: saca.
   Lo creado a mano lleva origen "manual"; lo del servidor que se tocó, "editado".
   Las cuentas automáticas (del servidor) solo aceptan el campo "nota". */
function aplicarEdiciones_(datos, items) {
  var out = asig_({}, datos || {});
  COLS_.forEach(function (c) { out[c] = Array.isArray(out[c]) ? out[c].slice() : []; });
  reducir_(items || []).forEach(function (it) {
    if (COLS_.indexOf(it.col) < 0) return;
    var lista = out[it.col], idx = -1, i;
    for (i = 0; i < lista.length; i++) if (lista[i] && String(lista[i].id) === String(it.id)) { idx = i; break; }
    if (it.op === 'delete') { if (idx > -1) lista.splice(idx, 1); return; }
    if (it.op !== 'upsert' || !it.data || typeof it.data !== 'object') return;
    var d = asig_({}, it.data); delete d.id; delete d.origen;
    if (idx > -1) {
      var orig = lista[idx], man = esManual_(orig);
      if (it.col === 'cuentas' && !man) { d = Object.prototype.hasOwnProperty.call(d, 'nota') ? { nota: d.nota } : null; if (!d) return; }
      var el = asig_({}, orig, d); el.id = orig.id; el.origen = man ? 'manual' : 'editado'; lista[idx] = el;
    } else {
      if (!minimo_(it.col, d)) return;
      var nuevo = asig_({}, d); nuevo.id = String(it.id); nuevo.origen = 'manual'; lista.push(nuevo);
    }
  });
  return out;
}
