# Endpoint de datos (Apps Script) en 5 pasos

Sirve para que la app lea tu archivo `mesa-datos.json` de Google Drive. Se puede hacer desde el celular o la PC; en el celular, abrí script.google.com en el navegador y elegí "Versión para computadora".

1. Entrá a https://script.google.com con la misma cuenta de Google donde está el archivo y tocá **Nuevo proyecto**.
2. Borrá lo que haya, pegá todo el contenido de `Datos.gs` y guardá.
3. Poné la clave: **Configuración del proyecto** (la rueda) > **Propiedades de la secuencia de comandos** > **Agregar propiedad**. Nombre: `CLAVE`. Valor: una clave larga que inventes (ej. 24 letras y números). Guardá.
4. **Implementar** > **Nueva implementación** > tipo **Aplicación web**. Ejecutar como: **Yo**. Quién tiene acceso: **Cualquier persona**. Tocá **Implementar** y aceptá los permisos de Drive (la primera vez aparece "Google no verificó esta app": **Avanzado** > **Ir a (nombre del proyecto)**).
5. Copiá la **URL de la aplicación web** (termina en `/exec`). En la app: **Ajustes**, pegá la URL y la clave, y tocá **Guardar y actualizar**.

Probar sin la app: abrí `LA_URL?k=TU_CLAVE` en el navegador. Tiene que mostrar el contenido del archivo. Con una clave mala muestra `{"ok":false,"error":"clave"}`.

Notas
- El archivo tiene que llamarse exactamente `mesa-datos.json` y estar en tu Drive. Si hay varios con ese nombre, se usa el más nuevo.
- Si cambiás el código `Datos.gs`, hay que hacer **Implementar > Administrar implementaciones > editar > Nueva versión** para que la URL use el cambio.
- Quien tenga la URL y la clave puede leer tus datos. No las compartas.
- Quién deja `mesa-datos.json` en Drive (el proceso automático) es aparte: tiene que respetar el formato de `www/data/schema.md`.
