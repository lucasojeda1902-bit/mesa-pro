# Endpoint de datos (Apps Script) en 5 pasos

Sirve para que la app lea tu archivo `mesa-datos.json` de Google Drive y para que guarde ahí tus cambios (agregar, editar, borrar, pausar) en `mesa-ediciones.json`. Se puede hacer desde el celular o la PC; en el celular, abrí script.google.com en el navegador y elegí "Versión para computadora".

1. Entrá a https://script.google.com con la misma cuenta de Google donde está el archivo y tocá **Nuevo proyecto**.
2. Borrá lo que haya, pegá todo el contenido de `Datos.gs` y guardá.
3. Poné la clave: **Configuración del proyecto** (la rueda) > **Propiedades de la secuencia de comandos** > **Agregar propiedad**. Nombre: `CLAVE`. Valor: una clave larga que inventes (ej. 24 letras y números). Guardá.
4. **Implementar** > **Nueva implementación** > tipo **Aplicación web**. Ejecutar como: **Yo**. Quién tiene acceso: **Cualquier persona**. Tocá **Implementar** y aceptá los permisos de Drive (la primera vez aparece "Google no verificó esta app": **Avanzado** > **Ir a (nombre del proyecto)**).
5. Copiá la **URL de la aplicación web** (termina en `/exec`). En la app: **Ajustes**, pegá la URL y la clave, y tocá **Guardar y actualizar**.

Probar sin la app: abrí `LA_URL?k=TU_CLAVE` en el navegador. Tiene que mostrar el contenido del archivo. Con una clave mala muestra `{"ok":false,"error":"clave"}`.

Notas
- El archivo tiene que llamarse exactamente `mesa-datos.json` y estar en tu Drive. Si hay varios con ese nombre, se usa el más nuevo.
- Si cambiás el código `Datos.gs`, hay que hacer **Implementar > Administrar implementaciones > editar > Nueva versión** para que la URL use el cambio.
- Quien tenga la URL y la clave puede leer tus datos. No las compartas.
- Quién deja `mesa-datos.json` en Drive (el proceso automático) es aparte: tiene que respetar el formato de `www/data/schema.md`.

## Actualizar a la versión 2 (si ya tenías el script de la versión 1)

1. Abrí tu proyecto en script.google.com, borrá el código viejo y pegá todo el `Datos.gs` nuevo. Guardá.
2. **Implementar > Administrar implementaciones > editar (lápiz) > Versión: Nueva versión > Implementar.** La URL no cambia.
3. Si Google pide permisos nuevos (ahora también escribe en Drive), aceptalos como la primera vez.
4. Probá `LA_URL?k=TU_CLAVE`: tiene que mostrar tus datos con un campo `ediciones_version`. `LA_URL?k=TU_CLAVE&solo=ediciones` muestra el archivo de ediciones.

### Cómo funciona

- `GET ?k=CLAVE`: devuelve el `mesa-datos.json` más nuevo con las ediciones de `mesa-ediciones.json` ya aplicadas, más `ediciones_version`.
- `GET ?k=CLAVE&solo=ediciones`: devuelve el archivo de ediciones tal cual (`{version, items}`). El contador automático puede leer el archivo directo desde Drive.
- `POST`: la app manda `{"k":"CLAVE","items":[…]}` como texto. El script valida la clave y cada item (col, op, id, tamaño máximo 200 KB), guarda con un candado para que dos envíos no se pisen, sube la `version` y responde `{"ok":true,"version":n}`. Con un error responde `{"ok":false,"error":"…"}` (`clave`, `cuerpo`, `json`, `sin_items`, `col_invalida`, `op_invalida`, `id_invalido`, `data_invalida`, `ocupado`).
- `mesa-ediciones.json` se crea solo la primera vez, en la raíz de tu Drive. Los formatos están en `www/data/schema.md`.
