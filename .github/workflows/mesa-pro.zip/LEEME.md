# Mesa PRO: cómo tenerla en el celular

Mesa PRO es una app para Android que muestra la contabilidad y el control de tus cuentas de fondeo. No hay que cargar nada a mano: lee un archivo que se actualiza solo.

## 1. Subir la carpeta a GitHub

Necesitás una cuenta gratis en github.com.

**Desde la PC (lo más fácil)**
1. En GitHub tocá **New repository**, ponele de nombre `mesa-pro` y creálo (dejalo **privado**: el repositorio no debería ser público).
2. Tocá **uploading an existing file** y arrastrá TODO el contenido de la carpeta `mesa-app` (incluida la carpeta oculta `.github`; si no la ves, activá "mostrar archivos ocultos").
3. Abajo tocá **Commit changes**.

**Desde el celular**
1. Con GitHub en el navegador (modo "Versión para computadora"), creá el repositorio igual.
2. La web del celular no sube carpetas enteras y a veces se saltea `.github`. Lo más seguro: usá la app GitHub Desktop en una PC, o subí un .zip a la PC y repetí el paso anterior. Si `.github/workflows/apk.yml` no quedó subido, el APK no se arma: creálo con **Add file > Create new file**, escribí `.github/workflows/apk.yml` como nombre y pegá el contenido.

La rama tiene que llamarse `main`.

## 2. Bajar el APK

1. En el repositorio entrá a la pestaña **Actions** y esperá a que "Compilar APK" termine con el tilde verde (tarda unos 5 a 10 minutos la primera vez).
2. Desde el celular, abrí el repositorio y tocá **Releases** (a la derecha) > **Mesa PRO (última versión)** > **app-debug.apk**. Se descarga.
3. Cada vez que cambies algo y lo subas a `main`, se arma uno nuevo en el mismo lugar.
4. Si Android no te deja instalar encima de la versión anterior (las apps de prueba se firman distinto en cada armado), desinstalá la vieja primero. Ojo: se pierden los cambios que no estaban sincronizados.

## 3. Instalarlo

1. Abrí el archivo descargado. Android te va a decir que no puede instalar apps de esta fuente: tocá **Ajustes** y activá **Permitir de esta fuente** (orígenes desconocidos) para tu navegador o el administrador de archivos.
2. Volvé y tocá **Instalar**. Si aparece "Play Protect", elegí **Instalar de todos modos** (es una app tuya, sin firma de Google Play).
3. Abrila. Al principio muestra "Datos de ejemplo".

## 4. Conectar tus datos

1. Seguí los pasos de `apps-script/LEEME.md` (5 pasos). Al final tenés una URL y una clave.
2. En la app: pestaña **Ajustes**, pegá la URL y la clave, tocá **Guardar y actualizar**.
3. Desde ahí se actualiza sola al abrir y cada 15 minutos. También podés tirar hacia abajo en cualquier pantalla.
4. Tocá **Activar avisos** en Ajustes para recibir notificaciones (semáforo en rojo, retiro disponible y pagos que vencen en 3 días).

## Qué hace cada pestaña

- **Inicio**: el semáforo (verde: todo bien, amarillo: mirá esto, rojo: hacé esto ahora), lo que pusiste, lo que cobraste y el resultado, cuánto falta para aprobar o cuánto podés retirar, y el gasto fijo.
- **Cuentas**: una tarjeta por cuenta. Tocala para ver el detalle y qué significa cada término.
- **Plata**: libro de movimientos con filtros, totales y gráfico por mes, y exportar a planilla (CSV). El botón **+** agrega un movimiento; tocá uno para editarlo o eliminarlo.
- **Suscripciones**: servicios, cuánto cuestan por mes y por año y cuándo se paga el próximo. El botón **+** agrega una; tocá una para editarla, **pausarla** (no suma ni avisa) o eliminarla.
- **Cuentas**: además de las de FundedNext (automáticas), con **Agregar cuenta manual** cargás cuentas de otras firmas.
- **Ajustes**: conexión, tema claro u oscuro, y qué avisos querés recibir.

## Novedades de la versión 2

- **Agregar, editar, borrar y pausar** movimientos, suscripciones y cuentas manuales. Al borrar tenés 5 segundos para deshacer.
- **Tus cambios se guardan en tu Drive** (archivo `mesa-ediciones.json`) y los ve el contador automático. Si no hay conexión, quedan en el celular ("Sin sincronizar") y se mandan solos después. Con los datos de ejemplo, quedan solo en el celular.
- **Recordatorios de pagos**: 3 días antes, 1 día antes y el mismo día, a las 10:00. Y en Inicio, **Próximos vencimientos** (30 días).
- **Notificaciones con la app cerrada**: la app revisa tus cuentas cada ~30 minutos (retiro listo, muy cerca de retirar, retiro frenado con solución, poco margen, objetivo, pagos, datos viejos, avisos del contador). Se eligen en **Ajustes > Notificaciones**. Para que Android no las atrase, poné la batería de Mesa PRO en **Sin restricciones**.
- Para que lo anterior funcione, **actualizá el Apps Script** con el `Datos.gs` nuevo (ver `apps-script/LEEME.md`, sección "Actualizar a la versión 2").

## Límites que conviene saber

- Los recordatorios de pago se programan en el celular y llegan aunque la app esté cerrada. El resto de los avisos los detecta un chequeo en segundo plano que Android corre cada 30 minutos más o menos; puede atrasarse si el celular ahorra batería (ver Ajustes > Para que los avisos lleguen a tiempo).
- El APK es de prueba (debug), no está en Play Store.
- Los formatos de los datos están en `www/data/schema.md`.
